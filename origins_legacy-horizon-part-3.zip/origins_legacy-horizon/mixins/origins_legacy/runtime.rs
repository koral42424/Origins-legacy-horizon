// Origins: Legacy, ported to Horizon by horizon-port from Origins-Legacy-1.12.20+26.3.jar.
// This file is both the bundle's Cargo library (its tests) and the module the bundle adds to
// the game (crate::game::port_origins_legacy). Put the mod's own logic here, in plain Rust
// that doesn't need the game, and call it from the helpers. No `//!` comments: module payloads
// can't hold inner attributes.

/// The mod's id (its settings folder), name, version and description.
pub const ID: &str = "origins_legacy";
pub const NAME: &str = "Origins: Legacy";
pub const VERSION: &str = "1.12.20+26.3";
pub const DESCRIPTION: &str = "This mod adds several origins with passive abilities to the game, which you can choose from at the beginning of the game. Unofficial forward port beginning from Minecraft 1.20.1, which includes backwards-compatible support for Origins built for MC 1.20.1 and prior.";

/// The mod's keys for Options > Mods: name, label, default key.
pub const KEYS: &[[&str; 3]] = &[
    ["primary_active", "Primary active", "key.keyboard.unknown"],
    ["secondary_active", "Secondary active", "key.keyboard.unknown"],
    ["primary_active", "Active Power (Primary)", "key.keyboard.unknown"],
    ["secondary_active", "Active Power (Secondary)", "key.keyboard.unknown"],
    ["view_origin", "View Origin", "key.keyboard.unknown"],
];

/// The mod's own Java that doesn't need the game, translated to Rust by horizon-port.
/// Each Java method is here whole or not at all; the ones left out say why.
#[allow(dead_code, unused_variables, unused_mut, unused_parens, unused_imports, unreachable_code,
    non_snake_case, non_upper_case_globals, non_camel_case_types, clippy::all)]
pub mod java {
    use std::sync::{LazyLock, Mutex};

    /// A Java static that changes: one value behind a lock.
    pub struct JCell<T>(Mutex<T>);
    impl<T: Clone> JCell<T> {
        pub const fn new(v: T) -> Self {
            Self(Mutex::new(v))
        }
        pub fn get(&self) -> T {
            self.0.lock().unwrap_or_else(|e| e.into_inner()).clone()
        }
        pub fn set(&self, v: T) {
            *self.0.lock().unwrap_or_else(|e| e.into_inner()) = v;
        }
        pub fn with<R>(&self, f: impl FnOnce(&mut T) -> R) -> R {
            f(&mut self.0.lock().unwrap_or_else(|e| e.into_inner()))
        }
    }

    /// Java's HashMap, LinkedHashMap and TreeMap. Keeps insertion order (LinkedHashMap's; HashMap's
    /// order is unspecified), or key order when made with `new_sorted` (TreeMap's).
    #[derive(Clone, Debug)]
    pub struct JMap<K, V> {
        index: std::collections::HashMap<K, usize>,
        entries: Vec<(K, V)>,
        sorted: bool,
    }
    /// Java's Map.equals: the same keys with equal values, in any order.
    impl<K: std::hash::Hash + Eq, V: PartialEq> PartialEq for JMap<K, V> {
        fn eq(&self, o: &Self) -> bool {
            self.entries.len() == o.entries.len()
                && self.entries.iter().all(|(k, v)| o.index.get(k).is_some_and(|&i| o.entries[i].1 == *v))
        }
    }
    impl<K, V> Default for JMap<K, V> {
        fn default() -> Self {
            Self { index: std::collections::HashMap::new(), entries: Vec::new(), sorted: false }
        }
    }
    impl<K: std::hash::Hash + Ord + Clone, V> JMap<K, V> {
        pub fn new() -> Self {
            Self::default()
        }
        pub fn new_sorted() -> Self {
            Self { sorted: true, ..Self::default() }
        }
        pub fn from_iter(pairs: impl IntoIterator<Item = (K, V)>) -> Self {
            let mut m = Self::new();
            for (k, v) in pairs {
                m.insert(k, v);
            }
            m
        }
        pub fn from_iter_sorted(pairs: impl IntoIterator<Item = (K, V)>) -> Self {
            let mut m = Self::new_sorted();
            for (k, v) in pairs {
                m.insert(k, v);
            }
            m
        }
        pub fn len(&self) -> usize {
            self.entries.len()
        }
        pub fn is_empty(&self) -> bool {
            self.entries.is_empty()
        }
        pub fn clear(&mut self) {
            self.index.clear();
            self.entries.clear();
        }
        pub fn contains_key<Q: std::hash::Hash + Eq + ?Sized>(&self, k: &Q) -> bool
        where
            K: std::borrow::Borrow<Q>,
        {
            self.index.contains_key(k)
        }
        pub fn get<Q: std::hash::Hash + Eq + ?Sized>(&self, k: &Q) -> Option<&V>
        where
            K: std::borrow::Borrow<Q>,
        {
            self.index.get(k).map(|&i| &self.entries[i].1)
        }
        fn reindex(&mut self) {
            self.index.clear();
            for (i, (k, _)) in self.entries.iter().enumerate() {
                self.index.insert(k.clone(), i);
            }
        }
        fn slot(&mut self, k: K, v: V) -> usize {
            if self.sorted {
                let at = self.entries.partition_point(|e| e.0 < k);
                self.entries.insert(at, (k, v));
                self.reindex();
                at
            } else {
                self.index.insert(k.clone(), self.entries.len());
                self.entries.push((k, v));
                self.entries.len() - 1
            }
        }
        pub fn insert(&mut self, k: K, v: V) -> Option<V> {
            if let Some(&i) = self.index.get(&k) {
                return Some(std::mem::replace(&mut self.entries[i].1, v));
            }
            self.slot(k, v);
            None
        }
        pub fn remove<Q: std::hash::Hash + Eq + ?Sized>(&mut self, k: &Q) -> Option<V>
        where
            K: std::borrow::Borrow<Q>,
        {
            let i = *self.index.get(k)?;
            let (_, v) = self.entries.remove(i);
            self.reindex();
            Some(v)
        }
        /// computeIfAbsent and putIfAbsent: the value, made first when the key is missing.
        pub fn or_insert_with(&mut self, k: K, f: impl FnOnce() -> V) -> &mut V {
            let i = match self.index.get(&k) {
                Some(&i) => i,
                None => self.slot(k, f()),
            };
            &mut self.entries[i].1
        }
        pub fn iter(&self) -> impl Iterator<Item = (&K, &V)> {
            self.entries.iter().map(|(k, v)| (k, v))
        }
        pub fn keys(&self) -> impl Iterator<Item = &K> {
            self.entries.iter().map(|e| &e.0)
        }
        pub fn values(&self) -> impl Iterator<Item = &V> {
            self.entries.iter().map(|e| &e.1)
        }
        pub fn clone_pairs(&self) -> Vec<(K, V)>
        where
            V: Clone,
        {
            self.entries.clone()
        }
    }

    /// Java's HashSet, LinkedHashSet and TreeSet, kept like JMap's keys.
    #[derive(Clone, Debug)]
    pub struct JSet<T>(JMap<T, ()>);
    impl<T: std::hash::Hash + Eq> PartialEq for JSet<T> {
        fn eq(&self, o: &Self) -> bool {
            self.0 == o.0
        }
    }
    impl<T> Default for JSet<T> {
        fn default() -> Self {
            Self(JMap::default())
        }
    }
    impl<T: std::hash::Hash + Ord + Clone> JSet<T> {
        pub fn new() -> Self {
            Self::default()
        }
        pub fn new_sorted() -> Self {
            Self(JMap::new_sorted())
        }
        pub fn from_iter(items: impl IntoIterator<Item = T>) -> Self {
            let mut s = Self::new();
            for v in items {
                s.insert(v);
            }
            s
        }
        pub fn from_iter_sorted(items: impl IntoIterator<Item = T>) -> Self {
            let mut s = Self::new_sorted();
            for v in items {
                s.insert(v);
            }
            s
        }
        pub fn len(&self) -> usize {
            self.0.len()
        }
        pub fn is_empty(&self) -> bool {
            self.0.is_empty()
        }
        pub fn clear(&mut self) {
            self.0.clear();
        }
        /// True when it wasn't there yet, as Java's add.
        pub fn insert(&mut self, v: T) -> bool {
            self.0.insert(v, ()).is_none()
        }
        pub fn contains<Q: std::hash::Hash + Eq + ?Sized>(&self, v: &Q) -> bool
        where
            T: std::borrow::Borrow<Q>,
        {
            self.0.contains_key(v)
        }
        pub fn remove<Q: std::hash::Hash + Eq + ?Sized>(&mut self, v: &Q) -> bool
        where
            T: std::borrow::Borrow<Q>,
        {
            self.0.remove(v).is_some()
        }
        pub fn iter(&self) -> impl Iterator<Item = &T> {
            self.0.keys()
        }
        pub fn clone_pairs(&self) -> Vec<T> {
            self.0.keys().cloned().collect()
        }
    }

    /// The mod's data folder in Horizon, set by the hooks (game_side.rs `ensure_init`) before the mod's code runs.
    pub static J_DATA_DIR: JCell<Option<std::path::PathBuf>> = JCell::new(None);
    /// FabricLoader's config folder: the mod's data folder in Horizon (./config until the game sets it).
    pub fn j_config_dir() -> std::path::PathBuf {
        J_DATA_DIR.get().unwrap_or_else(|| std::path::PathBuf::from("config"))
    }

    /// Minecraft's RandomSource / java.util.Random: other numbers than Java's, the same ranges.
    #[derive(Clone, Debug)]
    pub struct JRandom(u64);
    impl JRandom {
        pub fn new() -> Self {
            let t = std::time::SystemTime::now().duration_since(std::time::UNIX_EPOCH).map(|d| d.as_nanos() as u64).unwrap_or(0x9E37_79B9);
            Self(t | 1)
        }
        fn next(&mut self) -> u64 {
            let mut v = self.0;
            v ^= v << 13;
            v ^= v >> 7;
            v ^= v << 17;
            self.0 = v;
            v
        }
        /// 0 inclusive to n exclusive; Java throws on n <= 0.
        pub fn next_int(&mut self, n: i32) -> i32 {
            assert!(n > 0, "bound must be positive");
            (self.next() % n as u64) as i32
        }
        pub fn next_int_between(&mut self, lo: i32, hi: i32) -> i32 {
            lo + self.next_int(hi - lo)
        }
        pub fn next_float(&mut self) -> f32 {
            (self.next() >> 40) as f32 / (1u64 << 24) as f32
        }
        pub fn next_double(&mut self) -> f64 {
            (self.next() >> 11) as f64 / (1u64 << 53) as f64
        }
        pub fn next_boolean(&mut self) -> bool {
            self.next() & 1 == 1
        }
        pub fn next_gaussian(&mut self) -> f64 {
            let (u, v) = (self.next_double().max(1e-12), self.next_double());
            (-2.0 * u.ln()).sqrt() * (std::f64::consts::TAU * v).cos()
        }
    }

    /// Minecraft's Identifier (`namespace:path`), which is only text.
    #[derive(Clone, Debug, PartialEq, Eq, Hash, PartialOrd, Ord)]
    pub struct JIdentifier {
        pub namespace: String,
        pub path: String,
    }
    impl JIdentifier {
        pub fn new(namespace: &str, path: &str) -> Self {
            Self { namespace: namespace.to_string(), path: path.to_string() }
        }
        /// `a:b`, or `minecraft:b` without a namespace.
        pub fn parse(s: &str) -> Self {
            match s.split_once(':') {
                Some((n, p)) => Self::new(n, p),
                None => Self::new("minecraft", s),
            }
        }
        /// Identifier.tryParse: None (null) when it has characters an identifier can't.
        pub fn try_parse(s: &str) -> Option<Self> {
            let id = Self::parse(s);
            Self::try_build(&id.namespace, &id.path)
        }
        pub fn try_build(namespace: &str, path: &str) -> Option<Self> {
            let ns_ok = namespace.chars().all(|c| matches!(c, 'a'..='z' | '0'..='9' | '_' | '.' | '-'));
            let path_ok = path.chars().all(|c| matches!(c, 'a'..='z' | '0'..='9' | '_' | '.' | '-' | '/'));
            if ns_ok && path_ok { Some(Self::new(namespace, path)) } else { None }
        }
    }
    impl std::fmt::Display for JIdentifier {
        fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
            write!(f, "{}:{}", self.namespace, self.path)
        }
    }

    /// Java's String.equals.
    pub fn j_eq(a: &str, b: &str) -> bool {
        a == b
    }
    pub fn j_eq_ignore_case(a: &str, b: &str) -> bool {
        a.to_lowercase() == b.to_lowercase()
    }
    /// Java's String.length (in chars).
    pub fn j_len(s: &str) -> i32 {
        s.chars().count() as i32
    }
    pub fn j_char_at(s: &str, i: i32) -> char {
        s.chars().nth(i as usize).expect("charAt out of range")
    }
    /// Java's substring, by char.
    pub fn j_substring(s: &str, from: i32, to: Option<i32>) -> String {
        let n = s.chars().count() as i32;
        let to = to.unwrap_or(n);
        assert!(0 <= from && from <= to && to <= n, "substring out of range");
        s.chars().skip(from as usize).take((to - from) as usize).collect()
    }
    pub fn j_index_of(s: &str, sub: &str) -> i32 {
        s.find(sub).map_or(-1, |b| s[..b].chars().count() as i32)
    }
    pub fn j_index_of_char(s: &str, c: char) -> i32 {
        s.chars().position(|x| x == c).map_or(-1, |i| i as i32)
    }
    pub fn j_last_index_of(s: &str, sub: &str) -> i32 {
        s.rfind(sub).map_or(-1, |b| s[..b].chars().count() as i32)
    }
    /// Java's String.split on plain text: trailing empty parts dropped.
    pub fn j_split(s: &str, sep: &str) -> Vec<String> {
        let mut v: Vec<String> = s.split(sep).map(str::to_string).collect();
        while v.len() > 1 && v.last().is_some_and(|p| p.is_empty()) {
            v.pop();
        }
        v
    }
    /// Java's String.split(sep, limit) on plain text.
    pub fn j_split_limit(s: &str, sep: &str, limit: i32) -> Vec<String> {
        if limit == 0 {
            return j_split(s, sep);
        }
        if limit > 0 {
            return s.splitn(limit as usize, sep).map(str::to_string).collect();
        }
        s.split(sep).map(str::to_string).collect()
    }
    /// Java's String.compareTo: by UTF-16 unit, then by length.
    pub fn j_compare(a: &str, b: &str) -> i32 {
        let (x, y): (Vec<u16>, Vec<u16>) = (a.encode_utf16().collect(), b.encode_utf16().collect());
        for (p, q) in x.iter().zip(y.iter()) {
            if p != q {
                return *p as i32 - *q as i32;
            }
        }
        x.len() as i32 - y.len() as i32
    }
    /// Java's String.regionMatches, by char.
    pub fn j_region_matches(s: &str, ignore_case: bool, from: i32, other: &str, other_from: i32, len: i32) -> bool {
        let (a, b): (Vec<char>, Vec<char>) = (s.chars().collect(), other.chars().collect());
        if from < 0 || other_from < 0 || from as i64 + len as i64 > a.len() as i64 || other_from as i64 + len as i64 > b.len() as i64 {
            return false;
        }
        (0..len.max(0) as usize).all(|i| {
            let (p, q) = (a[from as usize + i], b[other_from as usize + i]);
            p == q || ignore_case && (j_upper_char(p) == j_upper_char(q) || j_lower_char(p) == j_lower_char(q))
        })
    }
    /// Java's Character.toLowerCase / toUpperCase (one char).
    pub fn j_lower_char(c: char) -> char {
        let mut l = c.to_lowercase();
        if l.len() == 1 { l.next().unwrap_or(c) } else { c }
    }
    pub fn j_upper_char(c: char) -> char {
        let mut u = c.to_uppercase();
        if u.len() == 1 { u.next().unwrap_or(c) } else { c }
    }
    /// Java's Arrays.copyOfRange: past the end is filled with defaults.
    pub fn j_copy_of_range<T: Clone + Default>(a: &[T], from: usize, to: usize) -> Vec<T> {
        assert!(from <= to && from <= a.len(), "copyOfRange out of range");
        let mut v: Vec<T> = a[from..to.min(a.len())].to_vec();
        v.resize(to - from, T::default());
        v
    }
    pub fn j_hash(s: &str) -> i32 {
        s.encode_utf16().fold(0i32, |h, c| h.wrapping_mul(31).wrapping_add(c as i32))
    }
    /// Java's Boolean.parseBoolean.
    pub fn j_parse_bool(s: &str) -> bool {
        s.eq_ignore_ascii_case("true")
    }
    /// A float as Java prints it in "..." + x (1.0, not 1).
    pub fn j_float(x: f64) -> String {
        if x.is_finite() && x == x.trunc() && x.abs() < 1e7 { format!("{x:.1}") } else { format!("{x}") }
    }
    /// Java's Math.round.
    pub fn j_round_f(x: f32) -> i32 {
        (x + 0.5).floor() as i32
    }
    pub fn j_round_d(x: f64) -> i64 {
        (x + 0.5).floor() as i64
    }
    /// Java's Math.clamp / Mth.clamp (no panic when min > max).
    pub fn j_clamp<T: PartialOrd>(v: T, min: T, max: T) -> T {
        if v < min { min } else if v > max { max } else { v }
    }
    pub fn j_lerp<T: Copy + std::ops::Add<Output = T> + std::ops::Sub<Output = T> + std::ops::Mul<Output = T>>(d: T, a: T, b: T) -> T {
        a + d * (b - a)
    }
    pub fn j_signum_f(x: f32) -> f32 {
        if x > 0.0 { 1.0 } else if x < 0.0 { -1.0 } else { x }
    }
    pub fn j_signum_d(x: f64) -> f64 {
        if x > 0.0 { 1.0 } else if x < 0.0 { -1.0 } else { x }
    }
    pub fn j_wrap_degrees(x: f64) -> f64 {
        let mut v = x % 360.0;
        if v >= 180.0 {
            v -= 360.0;
        }
        if v < -180.0 {
            v += 360.0;
        }
        v
    }
    pub fn j_frac(x: f64) -> f64 {
        x - x.floor()
    }
    pub fn j_compare_f(a: f64, b: f64) -> i32 {
        a.partial_cmp(&b).map_or(0, |o| o as i32)
    }
    pub fn j_copy_of<T: Clone + Default>(a: &[T], n: usize) -> Vec<T> {
        let mut v: Vec<T> = a.iter().take(n).cloned().collect();
        v.resize(n, T::default());
        v
    }
    /// Java's System.currentTimeMillis.
    pub fn j_millis() -> i64 {
        std::time::SystemTime::now().duration_since(std::time::UNIX_EPOCH).map_or(0, |d| d.as_millis() as i64)
    }
    /// Java's System.nanoTime: only differences mean anything.
    pub fn j_nanos() -> i64 {
        static START: LazyLock<std::time::Instant> = LazyLock::new(std::time::Instant::now);
        START.elapsed().as_nanos() as i64
    }

    /// `Badge` (io/github/apace100/origins/badge/Badge.java)
    pub mod badge {
        use super::*;
        // The class itself isn't translated: it's an interface. Its static parts are below.
        // Badge.spriteId(0): not translated, it has no body.
        // Badge.hasTooltip(0): not translated, it has no body.
        // Badge.getTooltipComponents(4): not translated, it has no body.
        // Badge.toData(1): not translated, it has no body.
        // Badge.getBadgeFactory(0): not translated, it has no body.
        // Badge.getFactory(0): not translated, its class isn't translated (it's an interface).
        // Badge.writeBuf(1): not translated, its class isn't translated (it's an interface).
    }

    /// `BadgeFactories` (io/github/apace100/origins/badge/BadgeFactories.java)
    pub mod badge_factories {
        use super::*;
        // SPRITE: not translated, it uses BadgeFactory, which isn't translated (it implements `DataObjectFactory` (io.github.apace100.calio.registry)).
        // TOOLTIP: not translated, it uses BadgeFactory, which isn't translated (it implements `DataObjectFactory` (io.github.apace100.calio.registry)).
        // KEYBIND: not translated, it uses BadgeFactory, which isn't translated (it implements `DataObjectFactory` (io.github.apace100.calio.registry)).
        // CRAFTING_RECIPE: not translated, it uses BadgeFactory, which isn't translated (it implements `DataObjectFactory` (io.github.apace100.calio.registry)).
        #[derive(Clone, Debug)]
        pub struct BadgeFactories {
        }
        impl BadgeFactories {
            pub fn new() -> Self {
                let mut s = Self {};
                s
            }
        }
    }

    /// `BadgeFactory` (io/github/apace100/origins/badge/BadgeFactory.java)
    pub mod badge_factory {
        use super::*;
        // The class itself isn't translated: it implements `DataObjectFactory` (io.github.apace100.calio.registry). Its static parts are below.
        // BadgeFactory.BadgeFactory(3): not translated, its class isn't translated (it implements `DataObjectFactory` (io.github.apace100.calio.registry)).
        // BadgeFactory.getData(0): not translated, its class isn't translated (it implements `DataObjectFactory` (io.github.apace100.calio.registry)).
        // BadgeFactory.fromData(1): not translated, its class isn't translated (it implements `DataObjectFactory` (io.github.apace100.calio.registry)).
        // BadgeFactory.toData(1): not translated, its class isn't translated (it implements `DataObjectFactory` (io.github.apace100.calio.registry)).
        // BadgeFactory.id(0): not translated, its class isn't translated (it implements `DataObjectFactory` (io.github.apace100.calio.registry)).
        // BadgeFactory.data(0): not translated, its class isn't translated (it implements `DataObjectFactory` (io.github.apace100.calio.registry)).
        // BadgeFactory.factory(0): not translated, its class isn't translated (it implements `DataObjectFactory` (io.github.apace100.calio.registry)).
    }

    /// `BadgeManager` (io/github/apace100/origins/badge/BadgeManager.java)
    pub mod badge_manager {
        use super::*;
        // REGISTRY: not translated, it uses `DataObjectRegistry` (io.github.apace100.calio.registry).
        // BADGES: not translated, it uses Badge, which isn't translated (it's an interface).
        pub static TOGGLE_BADGE_SPRITE: LazyLock<JIdentifier> = LazyLock::new(|| origins::identifier("textures/gui/badge/toggle.png"));
        pub static ACTIVE_BADGE_SPRITE: LazyLock<JIdentifier> = LazyLock::new(|| origins::identifier("textures/gui/badge/active.png"));
        pub static RECIPE_BADGE_SPRITE: LazyLock<JIdentifier> = LazyLock::new(|| origins::identifier("textures/gui/badge/recipe.png"));
        pub static TOGGLE_BADGE_ID: LazyLock<JIdentifier> = LazyLock::new(|| origins::identifier("toggle"));
        pub static ACTIVE_BADGE_ID: LazyLock<JIdentifier> = LazyLock::new(|| origins::identifier("active"));
        #[derive(Clone, Debug)]
        pub struct BadgeManager {
        }
        impl BadgeManager {
            pub fn new() -> Self {
                let mut s = Self {};
                s
            }
        }
        // BadgeManager.init(0): not translated, it uses BadgeFactory, which isn't translated (it implements `DataObjectFactory` (io.github.apace100.calio.registry)).
        // BadgeManager.register(1): not translated, it uses BadgeFactory, which isn't translated (it implements `DataObjectFactory` (io.github.apace100.calio.registry)).
        // BadgeManager.putPowerBadge(2): not translated, it uses Badge, which isn't translated (it's an interface).
        // BadgeManager.getPowerBadges(1): not translated, it uses Badge, which isn't translated (it's an interface).
        // BadgeManager.clear(0): not translated, it uses BadgeManager.BADGES, which isn't translated (it uses Badge, which isn't translated (it's an interface)).
        // BadgeManager.sync(1): not translated, it uses Minecraft's `ServerPlayer`.
        // BadgeManager.readCustomBadges(5): not translated, it uses `PowerType` (io.github.apace100.apoli.power).
        // BadgeManager.readAutoBadges(5): not translated, it uses `PowerType` (io.github.apace100.apoli.power).
        // BadgeManager.createAutoBadges(3): not translated, it uses `PowerType` (io.github.apace100.apoli.power).
    }

    /// `CraftingRecipeBadge` (io/github/apace100/origins/badge/CraftingRecipeBadge.java)
    pub mod crafting_recipe_badge {
        use super::*;
        // The class itself isn't translated: it implements `Badge`. Its static parts are below.
        // CraftingRecipeBadge.CraftingRecipeBadge(4): not translated, its class isn't translated (it implements `Badge`).
        // CraftingRecipeBadge.CraftingRecipeBadge(1): not translated, its class isn't translated (it implements `Badge`).
        // CraftingRecipeBadge.hasTooltip(0): not translated, its class isn't translated (it implements `Badge`).
        // CraftingRecipeBadge.peekInputs(1): not translated, its class isn't translated (it implements `Badge`).
        // CraftingRecipeBadge.getTooltipComponents(4): not translated, its class isn't translated (it implements `Badge`).
        // CraftingRecipeBadge.toData(1): not translated, its class isn't translated (it implements `Badge`).
        // CraftingRecipeBadge.getBadgeFactory(0): not translated, its class isn't translated (it implements `Badge`).
        // CraftingRecipeBadge.spriteId(0): not translated, its class isn't translated (it implements `Badge`).
        // CraftingRecipeBadge.recipe(0): not translated, its class isn't translated (it implements `Badge`).
        // CraftingRecipeBadge.prefix(0): not translated, its class isn't translated (it implements `Badge`).
        // CraftingRecipeBadge.suffix(0): not translated, its class isn't translated (it implements `Badge`).
    }

    /// `KeybindBadge` (io/github/apace100/origins/badge/KeybindBadge.java)
    pub mod keybind_badge {
        use super::*;
        // The class itself isn't translated: it implements `Badge`. Its static parts are below.
        // KeybindBadge.KeybindBadge(2): not translated, its class isn't translated (it implements `Badge`).
        // KeybindBadge.KeybindBadge(1): not translated, its class isn't translated (it implements `Badge`).
        // KeybindBadge.hasTooltip(0): not translated, its class isn't translated (it implements `Badge`).
        // KeybindBadge.addLines(4): not translated, it uses Minecraft's `ClientTooltipComponent`.
        // KeybindBadge.getTooltipComponents(4): not translated, its class isn't translated (it implements `Badge`).
        // KeybindBadge.toData(1): not translated, its class isn't translated (it implements `Badge`).
        // KeybindBadge.getBadgeFactory(0): not translated, its class isn't translated (it implements `Badge`).
        // KeybindBadge.spriteId(0): not translated, its class isn't translated (it implements `Badge`).
        // KeybindBadge.text(0): not translated, its class isn't translated (it implements `Badge`).
    }

    /// `SpriteBadge` (io/github/apace100/origins/badge/SpriteBadge.java)
    pub mod sprite_badge {
        use super::*;
        // The class itself isn't translated: it implements `Badge`. Its static parts are below.
        // SpriteBadge.SpriteBadge(1): not translated, its class isn't translated (it implements `Badge`).
        // SpriteBadge.hasTooltip(0): not translated, its class isn't translated (it implements `Badge`).
        // SpriteBadge.getTooltipComponents(4): not translated, its class isn't translated (it implements `Badge`).
        // SpriteBadge.toData(1): not translated, its class isn't translated (it implements `Badge`).
        // SpriteBadge.getBadgeFactory(0): not translated, its class isn't translated (it implements `Badge`).
        // SpriteBadge.spriteId(0): not translated, its class isn't translated (it implements `Badge`).
    }

    /// `TooltipBadge` (io/github/apace100/origins/badge/TooltipBadge.java)
    pub mod tooltip_badge {
        use super::*;
        // The class itself isn't translated: it implements `Badge`. Its static parts are below.
        // TooltipBadge.TooltipBadge(2): not translated, its class isn't translated (it implements `Badge`).
        // TooltipBadge.TooltipBadge(1): not translated, its class isn't translated (it implements `Badge`).
        // TooltipBadge.hasTooltip(0): not translated, its class isn't translated (it implements `Badge`).
        // TooltipBadge.addLines(4): not translated, it uses Minecraft's `ClientTooltipComponent`.
        // TooltipBadge.getTooltipComponents(4): not translated, its class isn't translated (it implements `Badge`).
        // TooltipBadge.toData(1): not translated, its class isn't translated (it implements `Badge`).
        // TooltipBadge.getBadgeFactory(0): not translated, its class isn't translated (it implements `Badge`).
        // TooltipBadge.spriteId(0): not translated, its class isn't translated (it implements `Badge`).
        // TooltipBadge.text(0): not translated, its class isn't translated (it implements `Badge`).
    }

    /// `LayerArgumentType` (io/github/apace100/origins/command/LayerArgumentType.java)
    pub mod layer_argument_type {
        use super::*;
        // The class itself isn't translated: it implements Minecraft's `ArgumentType`. Its static parts are below.
        // LAYER_NOT_FOUND: not translated, it uses Minecraft's `DynamicCommandExceptionType`.
        // LayerArgumentType.layer(0): not translated, it uses LayerArgumentType, which isn't translated (it implements Minecraft's `ArgumentType`).
        // LayerArgumentType.parse(1): not translated, its class isn't translated (it implements Minecraft's `ArgumentType`).
        // LayerArgumentType.getLayer(2): not translated, it uses OriginLayer, which isn't translated (it implements `Comparable`).
        // LayerArgumentType.listSuggestions(2): not translated, it's generic.
    }

    /// `OriginArgumentType` (io/github/apace100/origins/command/OriginArgumentType.java)
    pub mod origin_argument_type {
        use super::*;
        // The class itself isn't translated: it implements Minecraft's `ArgumentType`. Its static parts are below.
        // ORIGIN_NOT_FOUND: not translated, it uses Minecraft's `DynamicCommandExceptionType`.
        // OriginArgumentType.origin(0): not translated, it uses OriginArgumentType, which isn't translated (it implements Minecraft's `ArgumentType`).
        // OriginArgumentType.parse(1): not translated, its class isn't translated (it implements Minecraft's `ArgumentType`).
        // OriginArgumentType.getOrigin(2): not translated, it uses Minecraft's `CommandContext`.
        // OriginArgumentType.listSuggestions(2): not translated, it's generic.
    }

    /// `OriginCommand` (io/github/apace100/origins/command/OriginCommand.java)
    pub mod origin_command {
        use super::*;
        #[derive(Clone, Debug)]
        pub struct OriginCommand {
        }
        impl OriginCommand {
            pub fn new() -> Self {
                let mut s = Self {};
                s
            }
        }
        // OriginCommand.register(1): not translated, it uses Minecraft's `CommandDispatcher`.
        // OriginCommand.setOrigin(1): not translated, it uses Minecraft's `CommandContext`.
        // OriginCommand.hasOrigin(1): not translated, it uses Minecraft's `CommandContext`.
        // OriginCommand.getOrigin(1): not translated, it uses Minecraft's `CommandContext`.
        // OriginCommand.openSingleLayerScreen(1): not translated, it uses Minecraft's `CommandContext`.
        // OriginCommand.openMultipleLayerScreens(2): not translated, it uses Minecraft's `CommandContext`.
        // OriginCommand.randomizeOrigin(1): not translated, it uses Minecraft's `CommandContext`.
        // OriginCommand.randomizeOrigins(2): not translated, it uses Minecraft's `CommandContext`.
        // OriginCommand.openLayerScreen(2): not translated, it uses Minecraft's `ServerPlayer`.
        // OriginCommand.getRandomOrigin(2): not translated, it uses Minecraft's `ServerPlayer`.
    }

    /// `OriginCommand.TargetType` (io/github/apace100/origins/command/OriginCommand.java)
    pub mod origin_command_target_type {
        use super::*;
        #[derive(Clone, Copy, PartialEq, Eq, PartialOrd, Ord, Debug, Hash)]
        pub enum TargetType {
            Invoker,
            Specify,
        }
        impl TargetType {
            pub const VALUES: [TargetType; 2] = [TargetType::Invoker, TargetType::Specify, ];
            /// Java's `name()`.
            pub fn java_name(self) -> &'static str {
                match self {
                    TargetType::Invoker => "INVOKER",
                    TargetType::Specify => "SPECIFY",
                }
            }
            /// Java's `valueOf`: panics on a name that isn't one, as Java throws.
            pub fn value_of(name: &str) -> Self {
                match name {
                    "INVOKER" => TargetType::Invoker,
                    "SPECIFY" => TargetType::Specify,
                    _ => panic!("No enum constant {name}"),
                }
            }
        }
    }

    /// `OriginComponent` (io/github/apace100/origins/component/OriginComponent.java)
    pub mod origin_component {
        use super::*;
        // The class itself isn't translated: it's an interface. Its static parts are below.
        // OriginComponent.hasOrigin(1): not translated, it has no body.
        // OriginComponent.hasAllOrigins(0): not translated, it has no body.
        // OriginComponent.getOrigins(0): not translated, it has no body.
        // OriginComponent.getOrigin(1): not translated, it has no body.
        // OriginComponent.hadOriginBefore(0): not translated, it has no body.
        // OriginComponent.setOrigin(2): not translated, it has no body.
        // OriginComponent.sync(0): not translated, it has no body.
        // OriginComponent.onPowersRead(0): not translated, it has no body.
        // OriginComponent.sync(1): not translated, it uses Minecraft's `Player`.
        // OriginComponent.onChosen(2): not translated, it uses Minecraft's `Player`.
        // OriginComponent.partialOnChosen(3): not translated, it uses Minecraft's `Player`.
        // OriginComponent.checkAutoChoosingLayers(2): not translated, its class isn't translated (it's an interface).
    }

    /// `OriginTargetsComponent` (io/github/apace100/origins/component/OriginTargetsComponent.java)
    pub mod origin_targets_component {
        use super::*;
        // CODEC: not translated, it uses Minecraft's `Codec`.
        // STREAM_CODEC: not translated, it uses Minecraft's `StreamCodec`.
        // TYPE: not translated, it uses Minecraft's `DataComponentType`.
        #[derive(Clone, Debug, PartialEq)]
        pub struct OriginTargetsComponent {
            pub targets: Vec<origin_targets_component_origin_target::OriginTarget>,
        }
        impl OriginTargetsComponent {
            pub fn new(targets: &[origin_targets_component_origin_target::OriginTarget]) -> Self {
                let mut s = Self { targets: Vec::new() };
                s.targets = targets.to_vec();
                s
            }
            pub fn targets(&self) -> Vec<origin_targets_component_origin_target::OriginTarget> {
                return self.targets.to_vec();
            }
        }
    }

    /// `OriginTargetsComponent.OriginTarget` (io/github/apace100/origins/component/OriginTargetsComponent.java)
    pub mod origin_targets_component_origin_target {
        use super::*;
        // CODEC: not translated, it uses Minecraft's `Codec`.
        // STREAM_CODEC: not translated, it uses Minecraft's `StreamCodec`.
        #[derive(Clone, Debug, PartialEq)]
        pub struct OriginTarget {
            pub layer: JIdentifier,
            pub origin: Option<JIdentifier>,
        }
        impl OriginTarget {
            // OriginTargetsComponent.OriginTarget.OriginTarget(2): not translated, an Optional parameter.
            pub fn layer(&self) -> JIdentifier {
                return self.layer.clone();
            }
            pub fn origin(&self) -> Option<JIdentifier> {
                return self.origin.clone();
            }
        }
    }

    /// `PlayerOriginComponent` (io/github/apace100/origins/component/PlayerOriginComponent.java)
    pub mod player_origin_component {
        use super::*;
        // The class itself isn't translated: it implements `OriginComponent`. Its static parts are below.
        // PlayerOriginComponent.PlayerOriginComponent(1): not translated, its class isn't translated (it implements `OriginComponent`).
        // PlayerOriginComponent.hasAllOrigins(0): not translated, its class isn't translated (it implements `OriginComponent`).
        // PlayerOriginComponent.getOrigins(0): not translated, its class isn't translated (it implements `OriginComponent`).
        // PlayerOriginComponent.hasOrigin(1): not translated, its class isn't translated (it implements `OriginComponent`).
        // PlayerOriginComponent.getOrigin(1): not translated, its class isn't translated (it implements `OriginComponent`).
        // PlayerOriginComponent.hadOriginBefore(0): not translated, its class isn't translated (it implements `OriginComponent`).
        // PlayerOriginComponent.setOrigin(2): not translated, its class isn't translated (it implements `OriginComponent`).
        // PlayerOriginComponent.grantPowersFromOrigin(2): not translated, its class isn't translated (it implements `OriginComponent`).
        // PlayerOriginComponent.revokeRemovedPowers(2): not translated, its class isn't translated (it implements `OriginComponent`).
        // PlayerOriginComponent.readData(1): not translated, its class isn't translated (it implements `OriginComponent`).
        // PlayerOriginComponent.onPowersRead(0): not translated, its class isn't translated (it implements `OriginComponent`).
        // PlayerOriginComponent.writeData(1): not translated, its class isn't translated (it implements `OriginComponent`).
        // PlayerOriginComponent.sync(0): not translated, its class isn't translated (it implements `OriginComponent`).
    }

    /// `OrbOfOriginItem` (io/github/apace100/origins/content/OrbOfOriginItem.java)
    pub mod orb_of_origin_item {
        use super::*;
        // The class itself isn't translated: it extends Minecraft's `Item`. Its static parts are below.
        // OrbOfOriginItem.OrbOfOriginItem(0): not translated, its class isn't translated (it extends Minecraft's `Item`).
        // OrbOfOriginItem.use(3): not translated, its class isn't translated (it extends Minecraft's `Item`).
        // OrbOfOriginItem.appendHoverText(5): not translated, its class isn't translated (it extends Minecraft's `Item`).
        // OrbOfOriginItem.getTargets(1): not translated, its class isn't translated (it extends Minecraft's `Item`).
    }

    /// `TemporaryCobwebBlock` (io/github/apace100/origins/content/TemporaryCobwebBlock.java)
    pub mod temporary_cobweb_block {
        use super::*;
        // The class itself isn't translated: it extends Minecraft's `WebBlock`. Its static parts are below.
        // TemporaryCobwebBlock.TemporaryCobwebBlock(1): not translated, its class isn't translated (it extends Minecraft's `WebBlock`).
        // TemporaryCobwebBlock.tick(4): not translated, its class isn't translated (it extends Minecraft's `WebBlock`).
        // TemporaryCobwebBlock.getShape(4): not translated, its class isn't translated (it extends Minecraft's `WebBlock`).
        // TemporaryCobwebBlock.getCollisionShape(4): not translated, its class isn't translated (it extends Minecraft's `WebBlock`).
        // TemporaryCobwebBlock.onPlace(5): not translated, its class isn't translated (it extends Minecraft's `WebBlock`).
        // TemporaryCobwebBlock.entityInside(6): not translated, its class isn't translated (it extends Minecraft's `WebBlock`).
    }

    /// `CompatibilityDataTypes` (io/github/apace100/origins/data/CompatibilityDataTypes.java)
    pub mod compatibility_data_types {
        use super::*;
        // ITEM_OR_ITEM_STACK_TEMPLATE: not translated, it uses `SerializableDataType` (io.github.apace100.calio.data).
        // ITEM_OR_ITEM_STACK: not translated, it uses `SerializableDataType` (io.github.apace100.calio.data).
        #[derive(Clone, Debug)]
        pub struct CompatibilityDataTypes {
        }
        impl CompatibilityDataTypes {
            pub fn new() -> Self {
                let mut s = Self {};
                s
            }
        }
    }

    /// `OriginsDataTypes` (io/github/apace100/origins/data/OriginsDataTypes.java)
    pub mod origins_data_types {
        use super::*;
        // IMPACT: not translated, it uses `SerializableDataType` (io.github.apace100.calio.data).
        // UPGRADE: not translated, it uses `SerializableDataType` (io.github.apace100.calio.data).
        // UPGRADES: not translated, it uses `SerializableDataType` (io.github.apace100.calio.data).
        #[derive(Clone, Debug)]
        pub struct OriginsDataTypes {
        }
        impl OriginsDataTypes {
            pub fn new() -> Self {
                let mut s = Self {};
                s
            }
        }
    }

    /// `EnderianPearlEntity` (io/github/apace100/origins/entity/EnderianPearlEntity.java)
    pub mod enderian_pearl_entity {
        use super::*;
        // The class itself isn't translated: it extends Minecraft's `ThrowableItemProjectile`. Its static parts are below.
        // EnderianPearlEntity.EnderianPearlEntity(2): not translated, its class isn't translated (it extends Minecraft's `ThrowableItemProjectile`).
        // EnderianPearlEntity.EnderianPearlEntity(2): not translated, its class isn't translated (it extends Minecraft's `ThrowableItemProjectile`).
        // EnderianPearlEntity.EnderianPearlEntity(4): not translated, its class isn't translated (it extends Minecraft's `ThrowableItemProjectile`).
        // EnderianPearlEntity.getDefaultItem(0): not translated, its class isn't translated (it extends Minecraft's `ThrowableItemProjectile`).
        // EnderianPearlEntity.onHit(1): not translated, its class isn't translated (it extends Minecraft's `ThrowableItemProjectile`).
        // EnderianPearlEntity.tick(0): not translated, its class isn't translated (it extends Minecraft's `ThrowableItemProjectile`).
        // EnderianPearlEntity.teleport(1): not translated, its class isn't translated (it extends Minecraft's `ThrowableItemProjectile`).
    }

    /// `AutoBadgeCallback` (io/github/apace100/origins/integration/AutoBadgeCallback.java)
    pub mod auto_badge_callback {
        use super::*;
        // The class itself isn't translated: it's an interface. Its static parts are below.
        // AutoBadgeCallback.createAutoBadge(3): not translated, it has no body.
    }

    /// `ModMenuIntegration` (io/github/apace100/origins/integration/ModMenuIntegration.java)
    pub mod mod_menu_integration {
        use super::*;
        // The class itself isn't translated: it implements `ModMenuApi` (com.terraformersmc.modmenu.api). Its static parts are below.
        // ModMenuIntegration.getModConfigScreenFactory(0): not translated, its class isn't translated (it implements `ModMenuApi` (com.terraformersmc.modmenu.api)).
    }

    /// `OriginDataLoadedCallback` (io/github/apace100/origins/integration/OriginDataLoadedCallback.java)
    pub mod origin_data_loaded_callback {
        use super::*;
        // The class itself isn't translated: it's an interface. Its static parts are below.
        // OriginDataLoadedCallback.onDataLoaded(1): not translated, it has no body.
    }

    /// `WaterBreathingMixin` (io/github/apace100/origins/mixin/WaterBreathingMixin.java)
    pub mod water_breathing_mixin {
        use super::*;
        #[derive(Clone, Debug)]
        pub struct WaterBreathingMixin {
        }
        impl WaterBreathingMixin {
            pub fn new() -> Self {
                let mut s = Self {};
                s
            }
        }
    }

    /// `BadgeListPacket` (io/github/apace100/origins/networking/BadgeListPacket.java)
    pub mod badge_list_packet {
        use super::*;
        // The class itself isn't translated: it implements Minecraft's `CustomPacketPayload`. Its static parts are below.
        // CODEC: not translated, it uses Minecraft's `StreamCodec`.
        // BadgeListPacket.BadgeListPacket(1): not translated, its class isn't translated (it implements Minecraft's `CustomPacketPayload`).
        // BadgeListPacket.type(0): not translated, its class isn't translated (it implements Minecraft's `CustomPacketPayload`).
        // BadgeListPacket.badges(0): not translated, its class isn't translated (it implements Minecraft's `CustomPacketPayload`).
    }

    /// `ChooseOriginPacket` (io/github/apace100/origins/networking/ChooseOriginPacket.java)
    pub mod choose_origin_packet {
        use super::*;
        // The class itself isn't translated: it implements Minecraft's `CustomPacketPayload`. Its static parts are below.
        // CODEC: not translated, it uses Minecraft's `StreamCodec`.
        // ChooseOriginPacket.ChooseOriginPacket(2): not translated, its class isn't translated (it implements Minecraft's `CustomPacketPayload`).
        // ChooseOriginPacket.type(0): not translated, its class isn't translated (it implements Minecraft's `CustomPacketPayload`).
        // ChooseOriginPacket.originId(0): not translated, its class isn't translated (it implements Minecraft's `CustomPacketPayload`).
        // ChooseOriginPacket.layerId(0): not translated, its class isn't translated (it implements Minecraft's `CustomPacketPayload`).
    }

    /// `ChooseRandomOriginPacket` (io/github/apace100/origins/networking/ChooseRandomOriginPacket.java)
    pub mod choose_random_origin_packet {
        use super::*;
        // The class itself isn't translated: it implements Minecraft's `CustomPacketPayload`. Its static parts are below.
        // CODEC: not translated, it uses Minecraft's `StreamCodec`.
        // ChooseRandomOriginPacket.ChooseRandomOriginPacket(1): not translated, its class isn't translated (it implements Minecraft's `CustomPacketPayload`).
        // ChooseRandomOriginPacket.type(0): not translated, its class isn't translated (it implements Minecraft's `CustomPacketPayload`).
        // ChooseRandomOriginPacket.layerId(0): not translated, its class isn't translated (it implements Minecraft's `CustomPacketPayload`).
    }

    /// `ConfirmOriginPacket` (io/github/apace100/origins/networking/ConfirmOriginPacket.java)
    pub mod confirm_origin_packet {
        use super::*;
        // The class itself isn't translated: it implements Minecraft's `CustomPacketPayload`. Its static parts are below.
        // CODEC: not translated, it uses Minecraft's `StreamCodec`.
        // ConfirmOriginPacket.ConfirmOriginPacket(2): not translated, its class isn't translated (it implements Minecraft's `CustomPacketPayload`).
        // ConfirmOriginPacket.type(0): not translated, its class isn't translated (it implements Minecraft's `CustomPacketPayload`).
        // ConfirmOriginPacket.layerId(0): not translated, its class isn't translated (it implements Minecraft's `CustomPacketPayload`).
        // ConfirmOriginPacket.originId(0): not translated, its class isn't translated (it implements Minecraft's `CustomPacketPayload`).
    }

    /// `LayerListPacket` (io/github/apace100/origins/networking/LayerListPacket.java)
    pub mod layer_list_packet {
        use super::*;
        // The class itself isn't translated: it implements Minecraft's `CustomPacketPayload`. Its static parts are below.
        // CODEC: not translated, it uses Minecraft's `StreamCodec`.
        // LayerListPacket.LayerListPacket(1): not translated, its class isn't translated (it implements Minecraft's `CustomPacketPayload`).
        // LayerListPacket.type(0): not translated, its class isn't translated (it implements Minecraft's `CustomPacketPayload`).
        // LayerListPacket.layers(0): not translated, its class isn't translated (it implements Minecraft's `CustomPacketPayload`).
    }

    /// `ModPackets` (io/github/apace100/origins/networking/ModPackets.java)
    pub mod mod_packets {
        use super::*;
        pub static HANDSHAKE: LazyLock<JIdentifier> = LazyLock::new(|| origins::identifier("handshake"));
        // OPEN_ORIGIN_SCREEN: not translated, it uses Minecraft's `Type`.
        // CHOOSE_ORIGIN: not translated, it uses Minecraft's `Type`.
        // ORIGIN_LIST: not translated, it uses Minecraft's `Type`.
        // LAYER_LIST: not translated, it uses Minecraft's `Type`.
        // CHOOSE_RANDOM_ORIGIN: not translated, it uses Minecraft's `Type`.
        // CONFIRM_ORIGIN: not translated, it uses Minecraft's `Type`.
        // BADGE_LIST: not translated, it uses Minecraft's `Type`.
        // POWERS_AND_ORIGINS: not translated, it uses Minecraft's `Type`.
        #[derive(Clone, Debug)]
        pub struct ModPackets {
        }
        impl ModPackets {
            pub fn new() -> Self {
                let mut s = Self {};
                s
            }
        }
        // ModPackets.init(0): not translated, it calls Fabric's `PayloadTypeRegistry`.clientboundPlay.
    }

    /// `ModPacketsC2S` (io/github/apace100/origins/networking/ModPacketsC2S.java)
    pub mod mod_packets_c2_s {
        use super::*;
        #[derive(Clone, Debug)]
        pub struct ModPacketsC2S {
        }
        impl ModPacketsC2S {
            pub fn new() -> Self {
                let mut s = Self {};
                s
            }
        }
        // ModPacketsC2S.register(0): not translated, it uses ServerConfig, which isn't translated (it implements `ConfigData` (me.shedaniel.autoconfig)).
        // ModPacketsC2S.chooseOrigin(2): not translated, it uses ChooseOriginPacket, which isn't translated (it implements Minecraft's `CustomPacketPayload`).
        // ModPacketsC2S.chooseRandomOrigin(2): not translated, it uses ChooseRandomOriginPacket, which isn't translated (it implements Minecraft's `CustomPacketPayload`).
        // ModPacketsC2S.handleHandshakeReply(6): not translated, it uses Minecraft's `MinecraftServer`.
        // ModPacketsC2S.handshake(4): not translated, it uses Minecraft's `ServerLoginPacketListenerImpl`.
        // ModPacketsC2S.confirmOrigin(3): not translated, it uses Minecraft's `ServerPlayer`.
    }

    /// `ModPacketsS2C` (io/github/apace100/origins/networking/ModPacketsS2C.java)
    pub mod mod_packets_s2_c {
        use super::*;
        #[derive(Clone, Debug)]
        pub struct ModPacketsS2C {
        }
        impl ModPacketsS2C {
            pub fn new() -> Self {
                let mut s = Self {};
                s
            }
        }
        // ModPacketsS2C.register(0): not translated, a method reference.
        // ModPacketsS2C.receiveOriginConfirmation(2): not translated, it uses ConfirmOriginPacket, which isn't translated (it implements Minecraft's `CustomPacketPayload`).
        // ModPacketsS2C.handleHandshake(4): not translated, it uses Minecraft's `FriendlyByteBuf`.
        // ModPacketsS2C.openOriginScreen(2): not translated, it uses OpenOriginScreenPacket, which isn't translated (it implements Minecraft's `CustomPacketPayload`).
        // ModPacketsS2C.receiveOriginList(2): not translated, it uses OriginListPacket, which isn't translated (it implements Minecraft's `CustomPacketPayload`).
        // ModPacketsS2C.receiveLayerList(2): not translated, it uses LayerListPacket, which isn't translated (it implements Minecraft's `CustomPacketPayload`).
        // ModPacketsS2C.receiveBadgeList(2): not translated, it uses BadgeListPacket, which isn't translated (it implements Minecraft's `CustomPacketPayload`).
    }

    /// `OpenOriginScreenPacket` (io/github/apace100/origins/networking/OpenOriginScreenPacket.java)
    pub mod open_origin_screen_packet {
        use super::*;
        // The class itself isn't translated: it implements Minecraft's `CustomPacketPayload`. Its static parts are below.
        // CODEC: not translated, it uses Minecraft's `StreamCodec`.
        // OpenOriginScreenPacket.OpenOriginScreenPacket(1): not translated, its class isn't translated (it implements Minecraft's `CustomPacketPayload`).
        // OpenOriginScreenPacket.type(0): not translated, its class isn't translated (it implements Minecraft's `CustomPacketPayload`).
        // OpenOriginScreenPacket.showDirtBackground(0): not translated, its class isn't translated (it implements Minecraft's `CustomPacketPayload`).
    }

    /// `OriginListPacket` (io/github/apace100/origins/networking/OriginListPacket.java)
    pub mod origin_list_packet {
        use super::*;
        // The class itself isn't translated: it implements Minecraft's `CustomPacketPayload`. Its static parts are below.
        // CODEC: not translated, it uses Minecraft's `StreamCodec`.
        // OriginListPacket.OriginListPacket(1): not translated, its class isn't translated (it implements Minecraft's `CustomPacketPayload`).
        // OriginListPacket.fromOriginsMap(1): not translated, it uses OriginListPacket, which isn't translated (it implements Minecraft's `CustomPacketPayload`).
        // OriginListPacket.type(0): not translated, its class isn't translated (it implements Minecraft's `CustomPacketPayload`).
        // OriginListPacket.origins(0): not translated, its class isn't translated (it implements Minecraft's `CustomPacketPayload`).
    }

    /// `PowersAndOriginsPacket` (io/github/apace100/origins/networking/PowersAndOriginsPacket.java)
    pub mod powers_and_origins_packet {
        use super::*;
        // The class itself isn't translated: it implements Minecraft's `CustomPacketPayload`. Its static parts are below.
        // CODEC: not translated, it uses Minecraft's `StreamCodec`.
        // PowersAndOriginsPacket.PowersAndOriginsPacket(2): not translated, its class isn't translated (it implements Minecraft's `CustomPacketPayload`).
        // PowersAndOriginsPacket.type(0): not translated, its class isn't translated (it implements Minecraft's `CustomPacketPayload`).
        // PowersAndOriginsPacket.powers(0): not translated, its class isn't translated (it implements Minecraft's `CustomPacketPayload`).
        // PowersAndOriginsPacket.origins(0): not translated, its class isn't translated (it implements Minecraft's `CustomPacketPayload`).
    }

    /// `Origins` (io/github/apace100/origins/Origins.java)
    pub mod origins {
        use super::*;
        // The class itself isn't translated: it implements Fabric's `ModInitializer`. Its static parts are below.
        pub const MODID: &str = "origins";
        pub const LEGACY_MODID: &str = "origins_legacy";
        pub static VERSION: LazyLock<JCell<String>> = LazyLock::new(|| JCell::new("".to_string()));
        pub static SEMVER: LazyLock<JCell<Option<Vec<i32>>>> = LazyLock::new(|| JCell::new(None));
        // LOGGER: the logger. Log calls become comments.
        // config: not translated, it uses ServerConfig, which isn't translated (it implements `ConfigData` (me.shedaniel.autoconfig)).
        // configSerializer: not translated, it uses `ConfigSerializer` (me.shedaniel.autoconfig.serializer).
        // Origins.onInitialize(0): not translated, its class isn't translated (it implements Fabric's `ModInitializer`).
        // Origins.serializeConfig(0): not translated, a try/catch (SerializationException).
        pub fn identifier(path: &str) -> JIdentifier {
            return JIdentifier::new("origins", &path);
        }
        pub fn legacy(path: &str) -> JIdentifier {
            return JIdentifier::new("origins_legacy", &path);
        }
        // Origins.registerResourceListeners(1): not translated, its class isn't translated (it implements Fabric's `ModInitializer`).
    }

    /// `Origins.ServerConfig` (io/github/apace100/origins/Origins.java)
    pub mod origins_server_config {
        use super::*;
        // The class itself isn't translated: it implements `ConfigData` (me.shedaniel.autoconfig). Its static parts are below.
        // Origins.ServerConfig.isOriginDisabled(1): not translated, its class isn't translated (it implements `ConfigData` (me.shedaniel.autoconfig)).
        // Origins.ServerConfig.isPowerDisabled(2): not translated, its class isn't translated (it implements `ConfigData` (me.shedaniel.autoconfig)).
        // Origins.ServerConfig.addToConfig(1): not translated, its class isn't translated (it implements `ConfigData` (me.shedaniel.autoconfig)).
    }

    /// `OriginsClient` (io/github/apace100/origins/OriginsClient.java)
    pub mod origins_client {
        use super::*;
        // The class itself isn't translated: it implements Fabric's `ClientModInitializer`. Its static parts are below.
        // ORIGINS_CATEGORY: not translated, it uses Minecraft's `Category`.
        // usePrimaryActivePowerKeybind: not translated, it uses Minecraft's `KeyMapping`.
        // useSecondaryActivePowerKeybind: not translated, it uses Minecraft's `KeyMapping`.
        // viewCurrentOriginKeybind: not translated, it uses Minecraft's `KeyMapping`.
        pub static IS_SERVER_RUNNING_ORIGINS: JCell<bool> = JCell::new(false);
        // OriginsClient.onInitializeClient(0): not translated, its class isn't translated (it implements Fabric's `ClientModInitializer`).
    }

    /// `Impact` (io/github/apace100/origins/origin/Impact.java)
    pub mod impact {
        use super::*;
        // The class itself isn't translated: its constants carry values. Its static parts are below.
        // STREAM_CODEC: not translated, it uses Minecraft's `StreamCodec`.
        // Impact.Impact(3): not translated, its class isn't translated (its constants carry values).
        // Impact.getImpactValue(0): not translated, its class isn't translated (its constants carry values).
        // Impact.getTranslationKey(0): not translated, its class isn't translated (its constants carry values).
        // Impact.getTextStyle(0): not translated, its class isn't translated (its constants carry values).
        // Impact.getTextComponent(0): not translated, its class isn't translated (its constants carry values).
        // Impact.getByValue(1): not translated, it uses Impact, which isn't translated (its constants carry values).
    }

    /// `Origin` (io/github/apace100/origins/origin/Origin.java)
    pub mod origin {
        use super::*;
        // The class itself isn't translated: it uses `PowerType` (io.github.apace100.apoli.power). Its static parts are below.
        // STREAM_CODEC: not translated, it uses Minecraft's `StreamCodec`.
        // DATA: not translated, it uses `SerializableData` (io.github.apace100.calio.data).
        // EMPTY: not translated, it uses Origin, which isn't translated (it uses `PowerType` (io.github.apace100.apoli.power)).
        pub fn init() {
        }
        // Origin.register(1): not translated, it uses Origin, which isn't translated (it uses `PowerType` (io.github.apace100.apoli.power)).
        // Origin.get(1): not translated, it uses OriginLayer, which isn't translated (it implements `Comparable`).
        // Origin.get(1): not translated, it uses OriginLayer, which isn't translated (it implements `Comparable`).
        // Origin.Origin(5): not translated, its class isn't translated (it uses `PowerType` (io.github.apace100.apoli.power)).
        // Origin.Origin(5): not translated, its class isn't translated (it uses `PowerType` (io.github.apace100.apoli.power)).
        // Origin.Origin(10): not translated, its class isn't translated (it uses `PowerType` (io.github.apace100.apoli.power)).
        // Origin.Origin(10): not translated, its class isn't translated (it uses `PowerType` (io.github.apace100.apoli.power)).
        // Origin.addUpgrade(1): not translated, its class isn't translated (it uses `PowerType` (io.github.apace100.apoli.power)).
        // Origin.hasUpgrade(0): not translated, its class isn't translated (it uses `PowerType` (io.github.apace100.apoli.power)).
        // Origin.getUpgrade(1): not translated, its class isn't translated (it uses `PowerType` (io.github.apace100.apoli.power)).
        // Origin.getIdentifier(0): not translated, its class isn't translated (it uses `PowerType` (io.github.apace100.apoli.power)).
        // Origin.add(1): not translated, its class isn't translated (it uses `PowerType` (io.github.apace100.apoli.power)).
        // Origin.removePowerType(1): not translated, its class isn't translated (it uses `PowerType` (io.github.apace100.apoli.power)).
        // Origin.setUnchoosable(0): not translated, its class isn't translated (it uses `PowerType` (io.github.apace100.apoli.power)).
        // Origin.setSpecial(0): not translated, its class isn't translated (it uses `PowerType` (io.github.apace100.apoli.power)).
        // Origin.setName(1): not translated, its class isn't translated (it uses `PowerType` (io.github.apace100.apoli.power)).
        // Origin.setDescription(1): not translated, its class isn't translated (it uses `PowerType` (io.github.apace100.apoli.power)).
        // Origin.hasPowerType(1): not translated, its class isn't translated (it uses `PowerType` (io.github.apace100.apoli.power)).
        // Origin.getLoadingPriority(0): not translated, its class isn't translated (it uses `PowerType` (io.github.apace100.apoli.power)).
        // Origin.isSpecial(0): not translated, its class isn't translated (it uses `PowerType` (io.github.apace100.apoli.power)).
        // Origin.isChoosable(0): not translated, its class isn't translated (it uses `PowerType` (io.github.apace100.apoli.power)).
        // Origin.getPowerTypes(0): not translated, its class isn't translated (it uses `PowerType` (io.github.apace100.apoli.power)).
        // Origin.getPowerIds(0): not translated, its class isn't translated (it uses `PowerType` (io.github.apace100.apoli.power)).
        // Origin.getUpgrades(0): not translated, its class isn't translated (it uses `PowerType` (io.github.apace100.apoli.power)).
        // Origin.getImpact(0): not translated, its class isn't translated (it uses `PowerType` (io.github.apace100.apoli.power)).
        // Origin.getDisplayItem(0): not translated, its class isn't translated (it uses `PowerType` (io.github.apace100.apoli.power)).
        // Origin.getOrCreateNameTranslationKey(0): not translated, its class isn't translated (it uses `PowerType` (io.github.apace100.apoli.power)).
        // Origin.getName(0): not translated, its class isn't translated (it uses `PowerType` (io.github.apace100.apoli.power)).
        // Origin.getOrCreateDescriptionTranslationKey(0): not translated, its class isn't translated (it uses `PowerType` (io.github.apace100.apoli.power)).
        // Origin.getDescription(0): not translated, its class isn't translated (it uses `PowerType` (io.github.apace100.apoli.power)).
        // Origin.getOrder(0): not translated, its class isn't translated (it uses `PowerType` (io.github.apace100.apoli.power)).
        // Origin.write(1): not translated, its class isn't translated (it uses `PowerType` (io.github.apace100.apoli.power)).
        // Origin.createFromData(2): not translated, it uses Origin, which isn't translated (it uses `PowerType` (io.github.apace100.apoli.power)).
        // Origin.read(1): not translated, it uses Origin, which isn't translated (it uses `PowerType` (io.github.apace100.apoli.power)).
        // Origin.fromJson(3): not translated, it uses Origin, which isn't translated (it uses `PowerType` (io.github.apace100.apoli.power)).
        // Origin.toString(0): not translated, its class isn't translated (it uses `PowerType` (io.github.apace100.apoli.power)).
        // Origin.hashCode(0): not translated, its class isn't translated (it uses `PowerType` (io.github.apace100.apoli.power)).
        // Origin.equals(1): not translated, its class isn't translated (it uses `PowerType` (io.github.apace100.apoli.power)).
    }

    /// `OriginHolder` (io/github/apace100/origins/origin/OriginHolder.java)
    pub mod origin_holder {
        use super::*;
        // The class itself isn't translated: it uses Minecraft's `ItemStack`. Its static parts are below.
        // STREAM_CODEC: not translated, it uses Minecraft's `StreamCodec`.
        // OriginHolder.OriginHolder(10): not translated, its class isn't translated (it uses Minecraft's `ItemStack`).
        // OriginHolder.asOrigin(0): not translated, its class isn't translated (it uses Minecraft's `ItemStack`).
        // OriginHolder.id(0): not translated, its class isn't translated (it uses Minecraft's `ItemStack`).
        // OriginHolder.icon(0): not translated, its class isn't translated (it uses Minecraft's `ItemStack`).
        // OriginHolder.impact(0): not translated, its class isn't translated (it uses Minecraft's `ItemStack`).
        // OriginHolder.order(0): not translated, its class isn't translated (it uses Minecraft's `ItemStack`).
        // OriginHolder.loadingPriority(0): not translated, its class isn't translated (it uses Minecraft's `ItemStack`).
        // OriginHolder.choosable(0): not translated, its class isn't translated (it uses Minecraft's `ItemStack`).
        // OriginHolder.powerIds(0): not translated, its class isn't translated (it uses Minecraft's `ItemStack`).
        // OriginHolder.name(0): not translated, its class isn't translated (it uses Minecraft's `ItemStack`).
        // OriginHolder.description(0): not translated, its class isn't translated (it uses Minecraft's `ItemStack`).
        // OriginHolder.upgrades(0): not translated, its class isn't translated (it uses Minecraft's `ItemStack`).
    }

    /// `OriginLayer` (io/github/apace100/origins/origin/OriginLayer.java)
    pub mod origin_layer {
        use super::*;
        // The class itself isn't translated: it implements `Comparable`. Its static parts are below.
        // STREAM_CODEC: not translated, it uses Minecraft's `StreamCodec`.
        // OriginLayer.getOrCreateTranslationKey(0): not translated, its class isn't translated (it implements `Comparable`).
        // OriginLayer.getTranslationKey(0): not translated, its class isn't translated (it implements `Comparable`).
        // OriginLayer.getMissingOriginNameTranslationKey(0): not translated, its class isn't translated (it implements `Comparable`).
        // OriginLayer.getTitleViewOriginTranslationKey(0): not translated, its class isn't translated (it implements `Comparable`).
        // OriginLayer.shouldOverrideViewOriginTitle(0): not translated, its class isn't translated (it implements `Comparable`).
        // OriginLayer.getTitleChooseOriginTranslationKey(0): not translated, its class isn't translated (it implements `Comparable`).
        // OriginLayer.shouldOverrideChooseOriginTitle(0): not translated, its class isn't translated (it implements `Comparable`).
        // OriginLayer.getMissingOriginDescriptionTranslationKey(0): not translated, its class isn't translated (it implements `Comparable`).
        // OriginLayer.getIdentifier(0): not translated, its class isn't translated (it implements `Comparable`).
        // OriginLayer.isEnabled(0): not translated, its class isn't translated (it implements `Comparable`).
        // OriginLayer.hasDefaultOrigin(0): not translated, its class isn't translated (it implements `Comparable`).
        // OriginLayer.getDefaultOrigin(0): not translated, its class isn't translated (it implements `Comparable`).
        // OriginLayer.shouldAutoChoose(0): not translated, its class isn't translated (it implements `Comparable`).
        // OriginLayer.getOrigins(0): not translated, its class isn't translated (it implements `Comparable`).
        // OriginLayer.getOrigins(1): not translated, its class isn't translated (it implements `Comparable`).
        // OriginLayer.getOriginOptionCount(1): not translated, its class isn't translated (it implements `Comparable`).
        // OriginLayer.contains(1): not translated, its class isn't translated (it implements `Comparable`).
        // OriginLayer.contains(2): not translated, its class isn't translated (it implements `Comparable`).
        // OriginLayer.isRandomAllowed(0): not translated, its class isn't translated (it implements `Comparable`).
        // OriginLayer.isHidden(0): not translated, its class isn't translated (it implements `Comparable`).
        // OriginLayer.getRandomOrigins(1): not translated, its class isn't translated (it implements `Comparable`).
        // OriginLayer.merge(2): not translated, its class isn't translated (it implements `Comparable`).
        // OriginLayer.hashCode(0): not translated, its class isn't translated (it implements `Comparable`).
        // OriginLayer.equals(1): not translated, its class isn't translated (it implements `Comparable`).
        // OriginLayer.compareTo(1): not translated, its class isn't translated (it implements `Comparable`).
        // OriginLayer.write(1): not translated, its class isn't translated (it implements `Comparable`).
        // OriginLayer.read(1): not translated, it uses OriginLayer, which isn't translated (it implements `Comparable`).
        // OriginLayer.fromJson(3): not translated, it uses OriginLayer, which isn't translated (it implements `Comparable`).
    }

    /// `OriginLayer.ConditionedOrigin` (io/github/apace100/origins/origin/OriginLayer.java)
    pub mod origin_layer_conditioned_origin {
        use super::*;
        // The class itself isn't translated: it uses `Instance` (io.github.apace100.calio.data.SerializableData). Its static parts are below.
        // conditionedOriginObjectData: not translated, it uses `SerializableData` (io.github.apace100.calio.data).
        // OriginLayer.ConditionedOrigin.ConditionedOrigin(2): not translated, its class isn't translated (it uses `Instance` (io.github.apace100.calio.data.SerializableData)).
        // OriginLayer.ConditionedOrigin.isConditionFulfilled(1): not translated, its class isn't translated (it uses `Instance` (io.github.apace100.calio.data.SerializableData)).
        // OriginLayer.ConditionedOrigin.getOrigins(0): not translated, its class isn't translated (it uses `Instance` (io.github.apace100.calio.data.SerializableData)).
        // OriginLayer.ConditionedOrigin.write(1): not translated, its class isn't translated (it uses `Instance` (io.github.apace100.calio.data.SerializableData)).
        // OriginLayer.ConditionedOrigin.read(1): not translated, it uses ConditionedOrigin, which isn't translated (it uses `Instance` (io.github.apace100.calio.data.SerializableData)).
        // OriginLayer.ConditionedOrigin.read(2): not translated, it uses ConditionedOrigin, which isn't translated (it uses `Instance` (io.github.apace100.calio.data.SerializableData)).
    }

    /// `OriginLayers` (io/github/apace100/origins/origin/OriginLayers.java)
    pub mod origin_layers {
        use super::*;
        // The class itself isn't translated: it extends `MultiJsonDataLoader` (io.github.apace100.calio.data). Its static parts are below.
        // layers: not translated, it uses OriginLayer, which isn't translated (it implements `Comparable`).
        pub static MIN_LAYER_PRIORITY: JCell<i32> = JCell::new(i32::MIN);
        pub static GSON: LazyLock<JGson> = LazyLock::new(|| JGson { html: false, ..(JGson { pretty: true, ..JGson::default() }) });
        // OriginLayers.OriginLayers(0): not translated, its class isn't translated (it extends `MultiJsonDataLoader` (io.github.apace100.calio.data)).
        // OriginLayers.prepareSharedState(1): not translated, its class isn't translated (it extends `MultiJsonDataLoader` (io.github.apace100.calio.data)).
        // OriginLayers.apply(3): not translated, its class isn't translated (it extends `MultiJsonDataLoader` (io.github.apace100.calio.data)).
        // OriginLayers.getLayer(1): not translated, it uses OriginLayer, which isn't translated (it implements `Comparable`).
        // OriginLayers.getLayers(0): not translated, it uses OriginLayer, which isn't translated (it implements `Comparable`).
        // OriginLayers.size(0): not translated, it uses OriginLayers.layers, which isn't translated (it uses OriginLayer, which isn't translated (it implements `Comparable`)).
        // OriginLayers.clear(0): not translated, it uses OriginLayers.layers, which isn't translated (it uses OriginLayer, which isn't translated (it implements `Comparable`)).
        // OriginLayers.add(1): not translated, it uses OriginLayer, which isn't translated (it implements `Comparable`).
    }

    /// `OriginManager` (io/github/apace100/origins/origin/OriginManager.java)
    pub mod origin_manager {
        use super::*;
        // The class itself isn't translated: it extends `MultiJsonDataLoader` (io.github.apace100.calio.data). Its static parts are below.
        pub static GSON: LazyLock<JGson> = LazyLock::new(|| JGson { html: false, ..(JGson { pretty: true, ..JGson::default() }) });
        // OriginManager.OriginManager(0): not translated, its class isn't translated (it extends `MultiJsonDataLoader` (io.github.apace100.calio.data)).
        // OriginManager.prepareSharedState(1): not translated, its class isn't translated (it extends `MultiJsonDataLoader` (io.github.apace100.calio.data)).
        // OriginManager.apply(3): not translated, its class isn't translated (it extends `MultiJsonDataLoader` (io.github.apace100.calio.data)).
    }

    /// `OriginRegistry` (io/github/apace100/origins/origin/OriginRegistry.java)
    pub mod origin_registry {
        use super::*;
        // idToOrigin: not translated, it uses Origin, which isn't translated (it uses `PowerType` (io.github.apace100.apoli.power)).
        #[derive(Clone, Debug)]
        pub struct OriginRegistry {
        }
        impl OriginRegistry {
            pub fn new() -> Self {
                let mut s = Self {};
                s
            }
        }
        // OriginRegistry.register(1): not translated, it uses Origin, which isn't translated (it uses `PowerType` (io.github.apace100.apoli.power)).
        // OriginRegistry.register(2): not translated, it uses Origin, which isn't translated (it uses `PowerType` (io.github.apace100.apoli.power)).
        // OriginRegistry.register(2): not translated, it uses Origin, which isn't translated (it uses `PowerType` (io.github.apace100.apoli.power)).
        // OriginRegistry.update(2): not translated, it uses Origin, which isn't translated (it uses `PowerType` (io.github.apace100.apoli.power)).
        // OriginRegistry.size(0): not translated, it uses OriginRegistry.idToOrigin, which isn't translated (it uses Origin, which isn't translated (it uses `PowerType` (io.github.apace100.apoli.power))).
        // OriginRegistry.identifiers(0): not translated, it uses `Stream` (java.util.stream).
        // OriginRegistry.entries(0): not translated, it uses Origin, which isn't translated (it uses `PowerType` (io.github.apace100.apoli.power)).
        // OriginRegistry.values(0): not translated, it uses Origin, which isn't translated (it uses `PowerType` (io.github.apace100.apoli.power)).
        // OriginRegistry.get(0): not translated, it uses Origin, which isn't translated (it uses `PowerType` (io.github.apace100.apoli.power)).
        // OriginRegistry.get(1): not translated, it uses Origin, which isn't translated (it uses `PowerType` (io.github.apace100.apoli.power)).
        // OriginRegistry.contains(1): not translated, it's overloaded with the same number of parameters.
        // OriginRegistry.contains(1): not translated, it's overloaded with the same number of parameters.
        // OriginRegistry.clear(0): not translated, it uses OriginRegistry.idToOrigin, which isn't translated (it uses Origin, which isn't translated (it uses `PowerType` (io.github.apace100.apoli.power))).
        // OriginRegistry.reset(0): not translated, it calls OriginRegistry.clear, which isn't translated.
        // OriginRegistry.remove(1): not translated, it uses OriginRegistry.idToOrigin, which isn't translated (it uses Origin, which isn't translated (it uses `PowerType` (io.github.apace100.apoli.power))).
    }

    /// `OriginUpgrade` (io/github/apace100/origins/origin/OriginUpgrade.java)
    pub mod origin_upgrade {
        use super::*;
        #[derive(Clone, Debug)]
        pub struct OriginUpgrade {
            pub advancement_condition: JIdentifier,
            pub upgrade_to_origin: JIdentifier,
            pub announcement: String,
        }
        impl OriginUpgrade {
            pub fn new(advancement_condition: &JIdentifier, upgrade_to_origin: &JIdentifier, announcement: &str) -> Self {
                let mut s = Self { advancement_condition: advancement_condition.clone(), upgrade_to_origin: upgrade_to_origin.clone(), announcement: String::new() };
                s.advancement_condition = advancement_condition.clone();
                s.upgrade_to_origin = upgrade_to_origin.clone();
                s.announcement = announcement.to_string();
                s
            }
            pub fn get_advancement_condition(&self) -> JIdentifier {
                return self.advancement_condition.clone();
            }
            pub fn get_upgrade_to_origin(&self) -> JIdentifier {
                return self.upgrade_to_origin.clone();
            }
            pub fn get_announcement(&self) -> String {
                return self.announcement.to_string();
            }
            // OriginUpgrade.write(1): not translated, it uses Minecraft's `FriendlyByteBuf`.
        }
        // OriginUpgrade.read(1): not translated, it uses Minecraft's `FriendlyByteBuf`.
        // OriginUpgrade.fromJson(1): not translated, an assignment inside an expression.
    }

    /// `OriginsCallbackPower` (io/github/apace100/origins/power/OriginsCallbackPower.java)
    pub mod origins_callback_power {
        use super::*;
        // The class itself isn't translated: it extends `ActionOnCallbackPower` (io.github.apace100.apoli.power). Its static parts are below.
        // OriginsCallbackPower.OriginsCallbackPower(9): not translated, its class isn't translated (it extends `ActionOnCallbackPower` (io.github.apace100.apoli.power)).
        // OriginsCallbackPower.onChosen(1): not translated, its class isn't translated (it extends `ActionOnCallbackPower` (io.github.apace100.apoli.power)).
    }

    /// `OriginsEntityConditions` (io/github/apace100/origins/power/OriginsEntityConditions.java)
    pub mod origins_entity_conditions {
        use super::*;
        #[derive(Clone, Debug)]
        pub struct OriginsEntityConditions {
        }
        impl OriginsEntityConditions {
            pub fn new() -> Self {
                let mut s = Self {};
                s
            }
        }
        // OriginsEntityConditions.register(0): not translated, it uses `ConditionFactory` (io.github.apace100.apoli.power.factory.condition).
        // OriginsEntityConditions.register(1): not translated, it uses `ConditionFactory` (io.github.apace100.apoli.power.factory.condition).
    }

    /// `OriginsPowerTypes` (io/github/apace100/origins/power/OriginsPowerTypes.java)
    pub mod origins_power_types {
        use super::*;
        // LIKE_WATER: not translated, it uses `PowerType` (io.github.apace100.apoli.power).
        // WATER_BREATHING: not translated, it uses `PowerType` (io.github.apace100.apoli.power).
        // SCARE_CREEPERS: not translated, it uses `PowerType` (io.github.apace100.apoli.power).
        // WATER_VISION: not translated, it uses `PowerType` (io.github.apace100.apoli.power).
        // NO_COBWEB_SLOWDOWN: not translated, it uses `PowerType` (io.github.apace100.apoli.power).
        // MASTER_OF_WEBS_NO_SLOWDOWN: not translated, it uses `PowerType` (io.github.apace100.apoli.power).
        // CONDUIT_POWER_ON_LAND: not translated, it uses `PowerType` (io.github.apace100.apoli.power).
        #[derive(Clone, Debug)]
        pub struct OriginsPowerTypes {
        }
        impl OriginsPowerTypes {
            pub fn new() -> Self {
                let mut s = Self {};
                s
            }
        }
        // OriginsPowerTypes.register(0): not translated, it uses `PowerFactory` (io.github.apace100.apoli.power.factory).
        // OriginsPowerTypes.register(1): not translated, it uses `PowerFactory` (io.github.apace100.apoli.power.factory).
    }

    /// `ModBlocks` (io/github/apace100/origins/registry/ModBlocks.java)
    pub mod mod_blocks {
        use super::*;
        // TEMPORARY_COBWEB: not translated, it uses Minecraft's `Block`.
        #[derive(Clone, Debug)]
        pub struct ModBlocks {
        }
        impl ModBlocks {
            pub fn new() -> Self {
                let mut s = Self {};
                s
            }
        }
        // ModBlocks.register(0): not translated, it uses Minecraft's `Block`.
        // ModBlocks.register(2): not translated, it uses Minecraft's `Block`.
        // ModBlocks.register(3): not translated, it uses Minecraft's `Block`.
    }

    /// `ModComponents` (io/github/apace100/origins/registry/ModComponents.java)
    pub mod mod_components {
        use super::*;
        // The class itself isn't translated: it implements `EntityComponentInitializer` (org.ladysnake.cca.api.v3.entity). Its static parts are below.
        // ORIGIN: not translated, it uses `ComponentKey` (org.ladysnake.cca.api.v3.component).
        // ModComponents.registerEntityComponentFactories(1): not translated, its class isn't translated (it implements `EntityComponentInitializer` (org.ladysnake.cca.api.v3.entity)).
    }

    /// `ModDamageSources` (io/github/apace100/origins/registry/ModDamageSources.java)
    pub mod mod_damage_sources {
        use super::*;
        // NO_WATER_FOR_GILLS: not translated, it uses Minecraft's `ResourceKey`.
        #[derive(Clone, Debug)]
        pub struct ModDamageSources {
        }
        impl ModDamageSources {
            pub fn new() -> Self {
                let mut s = Self {};
                s
            }
        }
        // ModDamageSources.getSource(2): not translated, it uses Minecraft's `DamageSource`.
    }

    /// `ModEnchantments` (io/github/apace100/origins/registry/ModEnchantments.java)
    pub mod mod_enchantments {
        use super::*;
        // WATER_PROTECTION: not translated, it uses Minecraft's `ResourceKey`.
        #[derive(Clone, Debug)]
        pub struct ModEnchantments {
        }
        impl ModEnchantments {
            pub fn new() -> Self {
                let mut s = Self {};
                s
            }
        }
        pub fn register() {
        }
    }

    /// `ModEntities` (io/github/apace100/origins/registry/ModEntities.java)
    pub mod mod_entities {
        use super::*;
        // ENDERIAN_PEARL: not translated, it uses Minecraft's `EntityType`.
        #[derive(Clone, Debug)]
        pub struct ModEntities {
        }
        impl ModEntities {
            pub fn new() -> Self {
                let mut s = Self {};
                s
            }
        }
        pub fn register() {
        }
    }

    /// `ModItems` (io/github/apace100/origins/registry/ModItems.java)
    pub mod mod_items {
        use super::*;
        // ORB_OF_ORIGIN: not translated, it uses Minecraft's `Item`.
        #[derive(Clone, Debug)]
        pub struct ModItems {
        }
        impl ModItems {
            pub fn new() -> Self {
                let mut s = Self {};
                s
            }
        }
        // ModItems.register(0): not translated, it uses Minecraft's `BuiltInRegistries`.ITEM.
    }

    /// `ModLoot` (io/github/apace100/origins/registry/ModLoot.java)
    pub mod mod_loot {
        use super::*;
        pub static DUNGEON_LOOT: LazyLock<JIdentifier> = LazyLock::new(|| JIdentifier::new("minecraft", "chests/simple_dungeon"));
        pub static STRONGHOLD_LIBRARY: LazyLock<JIdentifier> = LazyLock::new(|| JIdentifier::new("minecraft", "chests/stronghold_library"));
        pub static MINESHAFT: LazyLock<JIdentifier> = LazyLock::new(|| JIdentifier::new("minecraft", "chests/abandoned_mineshaft"));
        pub static WATER_RUIN: LazyLock<JIdentifier> = LazyLock::new(|| JIdentifier::new("minecraft", "chests/underwater_ruin_small"));
        // ORIGIN_LOOT_CONDITION: not translated, it uses Minecraft's `MapCodec`.
        #[derive(Clone, Debug)]
        pub struct ModLoot {
        }
        impl ModLoot {
            pub fn new() -> Self {
                let mut s = Self {};
                s
            }
        }
        // ModLoot.registerLootCondition(2): not translated, it uses Minecraft's `MapCodec`.
        // ModLoot.registerLootTables(0): not translated, it uses Fabric's `LootTableEvents`.MODIFY.
    }

    /// `ModTags` (io/github/apace100/origins/registry/ModTags.java)
    pub mod mod_tags {
        use super::*;
        // MEAT: not translated, it uses Minecraft's `TagKey`.
        // UNPHASABLE: not translated, it uses Minecraft's `TagKey`.
        // NATURAL_STONE: not translated, it uses Minecraft's `TagKey`.
        // RANGED_WEAPONS: not translated, it uses Minecraft's `TagKey`.
        #[derive(Clone, Debug)]
        pub struct ModTags {
        }
        impl ModTags {
            pub fn new() -> Self {
                let mut s = Self {};
                s
            }
        }
        pub fn register() {
        }
    }

    /// `ChooseOriginScreen` (io/github/apace100/origins/screen/ChooseOriginScreen.java)
    pub mod choose_origin_screen {
        use super::*;
        // The class itself isn't translated: it extends `OriginDisplayScreen`. Its static parts are below.
        // ChooseOriginScreen.ChooseOriginScreen(3): not translated, its class isn't translated (it extends `OriginDisplayScreen`).
        // ChooseOriginScreen.openNextLayerScreen(0): not translated, its class isn't translated (it extends `OriginDisplayScreen`).
        // ChooseOriginScreen.shouldCloseOnEsc(0): not translated, its class isn't translated (it extends `OriginDisplayScreen`).
        // ChooseOriginScreen.init(0): not translated, its class isn't translated (it extends `OriginDisplayScreen`).
        // ChooseOriginScreen.getTitleText(0): not translated, its class isn't translated (it extends `OriginDisplayScreen`).
        // ChooseOriginScreen.getCurrentOriginInternal(0): not translated, its class isn't translated (it extends `OriginDisplayScreen`).
        // ChooseOriginScreen.initRandomOrigin(0): not translated, its class isn't translated (it extends `OriginDisplayScreen`).
        // ChooseOriginScreen.extractRenderState(4): not translated, its class isn't translated (it extends `OriginDisplayScreen`).
    }

    /// `OriginDisplayScreen` (io/github/apace100/origins/screen/OriginDisplayScreen.java)
    pub mod origin_display_screen {
        use super::*;
        // The class itself isn't translated: it extends Minecraft's `Screen`. Its static parts are below.
        pub static WINDOW: LazyLock<JIdentifier> = LazyLock::new(|| JIdentifier::new("origins", "textures/gui/choose_origin.png"));
        pub const WINDOW_WIDTH: i32 = 176;
        pub const WINDOW_HEIGHT: i32 = 182;
        // OriginDisplayScreen.OriginDisplayScreen(2): not translated, its class isn't translated (it extends Minecraft's `Screen`).
        // OriginDisplayScreen.showOrigin(3): not translated, its class isn't translated (it extends Minecraft's `Screen`).
        // OriginDisplayScreen.setRandomOriginText(1): not translated, its class isn't translated (it extends Minecraft's `Screen`).
        // OriginDisplayScreen.init(0): not translated, its class isn't translated (it extends Minecraft's `Screen`).
        // OriginDisplayScreen.getCurrentOrigin(0): not translated, its class isn't translated (it extends Minecraft's `Screen`).
        // OriginDisplayScreen.getCurrentLayer(0): not translated, its class isn't translated (it extends Minecraft's `Screen`).
        // OriginDisplayScreen.extractBackground(4): not translated, its class isn't translated (it extends Minecraft's `Screen`).
        // OriginDisplayScreen.extractRenderState(4): not translated, its class isn't translated (it extends Minecraft's `Screen`).
        // OriginDisplayScreen.renderScrollbar(3): not translated, its class isn't translated (it extends Minecraft's `Screen`).
        // OriginDisplayScreen.canScroll(0): not translated, its class isn't translated (it extends Minecraft's `Screen`).
        // OriginDisplayScreen.mouseReleased(1): not translated, its class isn't translated (it extends Minecraft's `Screen`).
        // OriginDisplayScreen.mouseClicked(2): not translated, its class isn't translated (it extends Minecraft's `Screen`).
        // OriginDisplayScreen.mouseDragged(3): not translated, its class isn't translated (it extends Minecraft's `Screen`).
        // OriginDisplayScreen.renderBadgeTooltip(3): not translated, its class isn't translated (it extends Minecraft's `Screen`).
        // OriginDisplayScreen.getTitleText(0): not translated, its class isn't translated (it extends Minecraft's `Screen`).
        // OriginDisplayScreen.renderOriginWindow(3): not translated, its class isn't translated (it extends Minecraft's `Screen`).
        // OriginDisplayScreen.renderOriginImpact(3): not translated, its class isn't translated (it extends Minecraft's `Screen`).
        // OriginDisplayScreen.renderOriginName(1): not translated, its class isn't translated (it extends Minecraft's `Screen`).
        // OriginDisplayScreen.renderWindowBackground(3): not translated, its class isn't translated (it extends Minecraft's `Screen`).
        // OriginDisplayScreen.mouseScrolled(4): not translated, its class isn't translated (it extends Minecraft's `Screen`).
        // OriginDisplayScreen.renderOriginContent(3): not translated, its class isn't translated (it extends Minecraft's `Screen`).
    }

    /// `OriginDisplayScreen.RenderedBadge` (io/github/apace100/origins/screen/OriginDisplayScreen.java)
    pub mod origin_display_screen_rendered_badge {
        use super::*;
        // The class itself isn't translated: it uses `PowerType` (io.github.apace100.apoli.power). Its static parts are below.
        // OriginDisplayScreen.RenderedBadge.RenderedBadge(4): not translated, its class isn't translated (it uses `PowerType` (io.github.apace100.apoli.power)).
        // OriginDisplayScreen.RenderedBadge.hasTooltip(0): not translated, its class isn't translated (it uses `PowerType` (io.github.apace100.apoli.power)).
        // OriginDisplayScreen.RenderedBadge.getTooltipComponents(2): not translated, its class isn't translated (it uses `PowerType` (io.github.apace100.apoli.power)).
    }

    /// `CraftingRecipeTooltipComponent` (io/github/apace100/origins/screen/tooltip/CraftingRecipeTooltipComponent.java)
    pub mod crafting_recipe_tooltip_component {
        use super::*;
        // The class itself isn't translated: it implements Minecraft's `ClientTooltipComponent`. Its static parts are below.
        pub static TEXTURE: LazyLock<JIdentifier> = LazyLock::new(|| origins::identifier("textures/gui/tooltip/recipe_tooltip.png"));
        // CraftingRecipeTooltipComponent.CraftingRecipeTooltipComponent(3): not translated, its class isn't translated (it implements Minecraft's `ClientTooltipComponent`).
        // CraftingRecipeTooltipComponent.getHeight(1): not translated, its class isn't translated (it implements Minecraft's `ClientTooltipComponent`).
        // CraftingRecipeTooltipComponent.getWidth(1): not translated, its class isn't translated (it implements Minecraft's `ClientTooltipComponent`).
        // CraftingRecipeTooltipComponent.extractImage(6): not translated, its class isn't translated (it implements Minecraft's `ClientTooltipComponent`).
        // CraftingRecipeTooltipComponent.drawBackground(5): not translated, its class isn't translated (it implements Minecraft's `ClientTooltipComponent`).
    }

    /// `ViewOriginScreen` (io/github/apace100/origins/screen/ViewOriginScreen.java)
    pub mod view_origin_screen {
        use super::*;
        // The class itself isn't translated: it extends `OriginDisplayScreen`. Its static parts are below.
        // ViewOriginScreen.ViewOriginScreen(0): not translated, its class isn't translated (it extends `OriginDisplayScreen`).
        // ViewOriginScreen.shouldCloseOnEsc(0): not translated, its class isn't translated (it extends `OriginDisplayScreen`).
        // ViewOriginScreen.init(0): not translated, its class isn't translated (it extends `OriginDisplayScreen`).
        // ViewOriginScreen.extractRenderState(4): not translated, its class isn't translated (it extends `OriginDisplayScreen`).
        // ViewOriginScreen.getTitleText(0): not translated, its class isn't translated (it extends `OriginDisplayScreen`).
    }

    /// `WaitForNextLayerScreen` (io/github/apace100/origins/screen/WaitForNextLayerScreen.java)
    pub mod wait_for_next_layer_screen {
        use super::*;
        // The class itself isn't translated: it extends Minecraft's `Screen`. Its static parts are below.
        // WaitForNextLayerScreen.WaitForNextLayerScreen(3): not translated, its class isn't translated (it extends Minecraft's `Screen`).
        // WaitForNextLayerScreen.openSelection(0): not translated, its class isn't translated (it extends Minecraft's `Screen`).
        // WaitForNextLayerScreen.extractRenderState(4): not translated, its class isn't translated (it extends Minecraft's `Screen`).
        // WaitForNextLayerScreen.extractBackground(4): not translated, its class isn't translated (it extends Minecraft's `Screen`).
    }

    /// `ByteBufUtils` (io/github/apace100/origins/util/ByteBufUtils.java)
    pub mod byte_buf_utils {
        use super::*;
        #[derive(Clone, Debug)]
        pub struct ByteBufUtils {
        }
        impl ByteBufUtils {
            pub fn new() -> Self {
                let mut s = Self {};
                s
            }
        }
        // ByteBufUtils.composite(21): not translated, its body couldn't be read: an anonymous class.
    }

    /// `ChoseOriginCriterion` (io/github/apace100/origins/util/ChoseOriginCriterion.java)
    pub mod chose_origin_criterion {
        use super::*;
        // The class itself isn't translated: it extends Minecraft's `SimpleCriterionTrigger`. Its static parts are below.
        // CODEC: not translated, it uses Minecraft's `Codec`.
        // INSTANCE: not translated, it uses ChoseOriginCriterion, which isn't translated (it extends Minecraft's `SimpleCriterionTrigger`).
        pub static ID: LazyLock<JIdentifier> = LazyLock::new(|| JIdentifier::new("origins", "chose_origin"));
        // ChoseOriginCriterion.trigger(2): not translated, its class isn't translated (it extends Minecraft's `SimpleCriterionTrigger`).
        // ChoseOriginCriterion.codec(0): not translated, its class isn't translated (it extends Minecraft's `SimpleCriterionTrigger`).
    }

    /// `ChoseOriginCriterion.Conditions` (io/github/apace100/origins/util/ChoseOriginCriterion.java)
    pub mod chose_origin_criterion_conditions {
        use super::*;
        // The class itself isn't translated: it implements Minecraft's `SimpleInstance`. Its static parts are below.
        // ChoseOriginCriterion.Conditions.Conditions(2): not translated, its class isn't translated (it implements Minecraft's `SimpleInstance`).
        // ChoseOriginCriterion.Conditions.matches(1): not translated, its class isn't translated (it implements Minecraft's `SimpleInstance`).
        // ChoseOriginCriterion.Conditions.player(0): not translated, its class isn't translated (it implements Minecraft's `SimpleInstance`).
    }

    /// `Constants` (io/github/apace100/origins/util/Constants.java)
    pub mod constants {
        use super::*;
        pub static LIGHT_ARMOR_MAX_PROTECTION: LazyLock<Vec<i32>> = LazyLock::new(|| vec![1, 4, 5, 2]);
        #[derive(Clone, Debug)]
        pub struct Constants {
        }
        impl Constants {
            pub fn new() -> Self {
                let mut s = Self {};
                s
            }
        }
    }

    /// `DebugInfo` (io/github/apace100/origins/util/DebugInfo.java)
    pub mod debug_info {
        use super::*;
        #[derive(Clone, Debug)]
        pub struct DebugInfo {
        }
        impl DebugInfo {
            pub fn new() -> Self {
                let mut s = Self {};
                s
            }
        }
        // DebugInfo.printRegistrySizes(1): not translated, it calls OriginRegistry.size, which isn't translated.
        pub fn print_info(lines: &mut [String]) {
            let mut longest: i32 = 0;
            for i in 0..(lines.len() as i32) {
                if j_len(&lines[i as usize]) > longest {
                    longest = j_len(&lines[i as usize]);
                }
                lines[i as usize] = format!("| {}", lines[i as usize]);
            }
            let mut border: String = "+".to_string();
            for i in 0..(longest + 2) {
                border = format!("{}-", border);
            }
            border = format!("{}+", border);
            // log:
            for i in 0..(lines.len() as i32) {
                while j_len(&lines[i as usize]) < (longest + 3) {
                    lines[i as usize] = format!("{} ", lines[i as usize]);
                }
                lines[i as usize] = format!("{}|", lines[i as usize]);
                // log:
            }
            // log:
        }
    }

    /// `InventoryType` (io/github/apace100/origins/util/InventoryType.java)
    pub mod inventory_type {
        use super::*;
        // The class itself isn't translated: its constants carry values. Its static parts are below.
        // InventoryType.InventoryType(1): not translated, its class isn't translated (its constants carry values).
        // InventoryType.getType(0): not translated, its class isn't translated (its constants carry values).
    }

    /// `OriginLootCondition` (io/github/apace100/origins/util/OriginLootCondition.java)
    pub mod origin_loot_condition {
        use super::*;
        // The class itself isn't translated: it implements Minecraft's `LootItemCondition`. Its static parts are below.
        // CODEC: not translated, it uses Minecraft's `MapCodec`.
        // OriginLootCondition.OriginLootCondition(1): not translated, its class isn't translated (it implements Minecraft's `LootItemCondition`).
        // OriginLootCondition.OriginLootCondition(2): not translated, its class isn't translated (it implements Minecraft's `LootItemCondition`).
        // OriginLootCondition.codec(0): not translated, its class isn't translated (it implements Minecraft's `LootItemCondition`).
        // OriginLootCondition.test(1): not translated, its class isn't translated (it implements Minecraft's `LootItemCondition`).
        // OriginLootCondition.builder(1): not translated, it uses Minecraft's `Builder`.
        // OriginLootCondition.builder(1): not translated, it uses Minecraft's `Builder`.
        // OriginLootCondition.builder(2): not translated, it uses Minecraft's `Builder`.
        // OriginLootCondition.builder(2): not translated, it uses Minecraft's `Builder`.
    }

    /// `OriginsConfigSerializer` (io/github/apace100/origins/util/OriginsConfigSerializer.java)
    pub mod origins_config_serializer {
        use super::*;
        // The class itself isn't translated: it's generic. Its static parts are below.
        // OriginsConfigSerializer.OriginsConfigSerializer(3): not translated, its class isn't translated (it's generic).
        // OriginsConfigSerializer.OriginsConfigSerializer(2): not translated, its class isn't translated (it's generic).
        // OriginsConfigSerializer.getConfigPath(0): not translated, its class isn't translated (it's generic).
        // OriginsConfigSerializer.deserialize(0): not translated, its class isn't translated (it's generic).
    }

    /// `OriginsJsonConfigSerializer` (io/github/apace100/origins/util/OriginsJsonConfigSerializer.java)
    pub mod origins_json_config_serializer {
        use super::*;
        // The class itself isn't translated: it's generic. Its static parts are below.
        // OriginsJsonConfigSerializer.OriginsJsonConfigSerializer(3): not translated, its class isn't translated (it's generic).
        // OriginsJsonConfigSerializer.OriginsJsonConfigSerializer(2): not translated, its class isn't translated (it's generic).
        // OriginsJsonConfigSerializer.OriginsJsonConfigSerializer(3): not translated, its class isn't translated (it's generic).
        // OriginsJsonConfigSerializer.deserialize(0): not translated, its class isn't translated (it's generic).
    }

    /// `PowerKeyManager` (io/github/apace100/origins/util/PowerKeyManager.java)
    pub mod power_key_manager {
        use super::*;
        pub static KEY_CACHE: LazyLock<JCell<JMap<JIdentifier, String>>> = LazyLock::new(|| JCell::new(JMap::new()));
        #[derive(Clone, Debug)]
        pub struct PowerKeyManager {
        }
        impl PowerKeyManager {
            pub fn new() -> Self {
                let mut s = Self {};
                s
            }
        }
        pub fn clear_cache() {
            power_key_manager::KEY_CACHE.with(|o| o.clear());
        }
        // PowerKeyManager.getKeyIdentifier(1): not translated, it calls PowerKeyManager.getKeyFromPower, which isn't translated.
        // PowerKeyManager.getKeyFromPower(1): not translated, it calls `PowerTypeRegistry` (io.github.apace100.apoli.power).contains.
    }

    /// `Scheduler` (io/github/apace100/origins/util/Scheduler.java)
    pub mod scheduler {
        use super::*;
        // The class itself isn't translated: it uses `Int2ObjectMap` (it.unimi.dsi.fastutil.ints). Its static parts are below.
        // Scheduler.Scheduler(0): not translated, its class isn't translated (it uses `Int2ObjectMap` (it.unimi.dsi.fastutil.ints)).
        // Scheduler.queue(2): not translated, its class isn't translated (it uses `Int2ObjectMap` (it.unimi.dsi.fastutil.ints)).
        // Scheduler.repeating(3): not translated, its class isn't translated (it uses `Int2ObjectMap` (it.unimi.dsi.fastutil.ints)).
        // Scheduler.repeatWhile(4): not translated, its class isn't translated (it uses `Int2ObjectMap` (it.unimi.dsi.fastutil.ints)).
        // Scheduler.repeatN(4): not translated, its body couldn't be read: an anonymous class.
    }

    /// `Scheduler.Repeating` (io/github/apace100/origins/util/Scheduler.java)
    pub mod scheduler_repeating {
        use super::*;
        // The class itself isn't translated: it implements `Consumer` (java.util.function). Its static parts are below.
        // Scheduler.Repeating.Repeating(3): not translated, its class isn't translated (it implements `Consumer` (java.util.function)).
        // Scheduler.Repeating.shouldQueue(1): not translated, its class isn't translated (it implements `Consumer` (java.util.function)).
        // Scheduler.Repeating.accept(1): not translated, its class isn't translated (it implements `Consumer` (java.util.function)).
    }


    // ---- Gson (com.google.gson): JSON values, a reader and Gson's writer ----
    // JsonElement, JsonObject, JsonArray and JsonPrimitive are all one Rust type. Numbers keep their text, as
    // Gson's LazilyParsedNumber does. Objects keep their insertion order, as Gson's LinkedTreeMap does.

    #[derive(Clone, Debug, PartialEq)]
    pub enum JJson {
        Null,
        Bool(bool),
        Num(String),
        Str(String),
        Arr(Vec<JJson>),
        Obj(Vec<(String, JJson)>),
    }

    /// A float or double as Java prints it (Float.toString / Double.toString).
    pub fn j_java_num(x: f64, float: bool) -> String {
        if x.is_nan() {
            return "NaN".into();
        }
        if x.is_infinite() {
            return if x > 0.0 { "Infinity".into() } else { "-Infinity".into() };
        }
        let a = x.abs();
        if x == 0.0 {
            return if x.is_sign_negative() { "-0.0".into() } else { "0.0".into() };
        }
        let digits = if float { format!("{:e}", x as f32) } else { format!("{:e}", x) };
        let (mant, exp) = digits.split_once('e').unwrap();
        let exp: i32 = exp.parse().unwrap();
        if (1e-3..1e7).contains(&a) {
            let plain = if float { format!("{}", x as f32) } else { format!("{}", x) };
            if plain.contains('.') { plain } else { plain + ".0" }
        } else {
            let mant = if mant.contains('.') { mant.to_string() } else { format!("{mant}.0") };
            format!("{mant}E{exp}")
        }
    }

    struct JJsonReader<'a> {
        s: &'a [char],
        i: usize,
    }

    impl JJsonReader<'_> {
        fn ws(&mut self) {
            while self.i < self.s.len() && self.s[self.i].is_whitespace() {
                self.i += 1;
            }
        }
        fn fail(&self, what: &str) -> ! {
            panic!("JsonSyntaxException: {what} at {}", self.i)
        }
        fn value(&mut self) -> JJson {
            self.ws();
            match self.s.get(self.i) {
                Some('{') => {
                    self.i += 1;
                    let mut members = Vec::new();
                    self.ws();
                    if self.s.get(self.i) == Some(&'}') {
                        self.i += 1;
                        return JJson::Obj(members);
                    }
                    loop {
                        self.ws();
                        let k = match self.s.get(self.i) {
                            Some('"') | Some('\'') => self.string(),
                            _ => self.bare(),
                        };
                        self.ws();
                        if !matches!(self.s.get(self.i), Some(':') | Some('=')) {
                            self.fail("expected ':'");
                        }
                        self.i += 1;
                        let v = self.value();
                        // A repeated name: Gson keeps the last one.
                        members.retain(|(n, _): &(String, JJson)| *n != k);
                        members.push((k, v));
                        self.ws();
                        match self.s.get(self.i) {
                            Some(',') | Some(';') => self.i += 1,
                            Some('}') => {
                                self.i += 1;
                                return JJson::Obj(members);
                            }
                            _ => self.fail("expected ',' or '}'"),
                        }
                    }
                }
                Some('[') => {
                    self.i += 1;
                    let mut items = Vec::new();
                    self.ws();
                    if self.s.get(self.i) == Some(&']') {
                        self.i += 1;
                        return JJson::Arr(items);
                    }
                    loop {
                        items.push(self.value());
                        self.ws();
                        match self.s.get(self.i) {
                            Some(',') | Some(';') => self.i += 1,
                            Some(']') => {
                                self.i += 1;
                                return JJson::Arr(items);
                            }
                            _ => self.fail("expected ',' or ']'"),
                        }
                    }
                }
                Some('"') | Some('\'') => JJson::Str(self.string()),
                Some(_) => {
                    let word = self.bare();
                    match word.as_str() {
                        "true" => JJson::Bool(true),
                        "false" => JJson::Bool(false),
                        "null" => JJson::Null,
                        w if w.parse::<f64>().is_ok() => JJson::Num(w.to_string()),
                        // Gson is lenient: an unquoted word is a string.
                        w => JJson::Str(w.to_string()),
                    }
                }
                None => self.fail("end of input"),
            }
        }
        fn bare(&mut self) -> String {
            let start = self.i;
            while self.i < self.s.len() && !matches!(self.s[self.i], ',' | ':' | '=' | ';' | '}' | ']' | '{' | '[' | '"' | '\'') && !self.s[self.i].is_whitespace() {
                self.i += 1;
            }
            if start == self.i {
                self.fail("expected a value");
            }
            self.s[start..self.i].iter().collect()
        }
        fn string(&mut self) -> String {
            let q = self.s[self.i];
            self.i += 1;
            let mut out = String::new();
            loop {
                let Some(&c) = self.s.get(self.i) else { self.fail("unterminated string") };
                self.i += 1;
                match c {
                    c if c == q => return out,
                    '\\' => {
                        let Some(&e) = self.s.get(self.i) else { self.fail("unterminated string") };
                        self.i += 1;
                        match e {
                            'n' => out.push('\n'),
                            't' => out.push('\t'),
                            'r' => out.push('\r'),
                            'b' => out.push('\u{8}'),
                            'f' => out.push('\u{c}'),
                            'u' => {
                                let hex: String = self.s[self.i..(self.i + 4).min(self.s.len())].iter().collect();
                                self.i += 4;
                                let unit = u16::from_str_radix(&hex, 16).unwrap_or_else(|_| self.fail("bad \\u escape"));
                                // A surrogate pair: two escapes make one char.
                                if (0xD800..0xDC00).contains(&unit) && self.s.get(self.i) == Some(&'\\') && self.s.get(self.i + 1) == Some(&'u') {
                                    let hex2: String = self.s[self.i + 2..(self.i + 6).min(self.s.len())].iter().collect();
                                    if let Ok(low) = u16::from_str_radix(&hex2, 16) {
                                        self.i += 6;
                                        out.extend(char::decode_utf16([unit, low]).map(|r| r.unwrap_or('\u{FFFD}')));
                                        continue;
                                    }
                                }
                                out.push(char::from_u32(unit as u32).unwrap_or('\u{FFFD}'));
                            }
                            other => out.push(other),
                        }
                    }
                    c => out.push(c),
                }
            }
        }
    }

    impl JJson {
        /// JsonParser.parseString: panics (Java throws JsonSyntaxException) on bad JSON.
        pub fn parse(s: &str) -> JJson {
            let chars: Vec<char> = s.chars().collect();
            let mut r = JJsonReader { s: &chars, i: 0 };
            let v = r.value();
            r.ws();
            if r.i != chars.len() {
                r.fail("more after the value");
            }
            v
        }
        pub fn object() -> JJson {
            JJson::Obj(Vec::new())
        }
        pub fn array() -> JJson {
            JJson::Arr(Vec::new())
        }
        pub fn int(v: i64) -> JJson {
            JJson::Num(v.to_string())
        }
        pub fn float(v: f32) -> JJson {
            JJson::Num(j_java_num(v as f64, true))
        }
        pub fn double(v: f64) -> JJson {
            JJson::Num(j_java_num(v, false))
        }
        pub fn str(v: &str) -> JJson {
            JJson::Str(v.to_string())
        }
        pub fn is_json_object(&self) -> bool {
            matches!(self, JJson::Obj(_))
        }
        pub fn is_json_array(&self) -> bool {
            matches!(self, JJson::Arr(_))
        }
        pub fn is_json_null(&self) -> bool {
            matches!(self, JJson::Null)
        }
        pub fn is_json_primitive(&self) -> bool {
            matches!(self, JJson::Bool(_) | JJson::Num(_) | JJson::Str(_))
        }
        pub fn is_string(&self) -> bool {
            matches!(self, JJson::Str(_))
        }
        pub fn is_number(&self) -> bool {
            matches!(self, JJson::Num(_))
        }
        pub fn is_boolean(&self) -> bool {
            matches!(self, JJson::Bool(_))
        }
        /// getAsJsonObject() / getAsJsonArray(): Java throws IllegalStateException on the wrong kind.
        pub fn as_object(&self) -> JJson {
            assert!(self.is_json_object(), "Not a JSON Object: {self}");
            self.clone()
        }
        pub fn as_array(&self) -> JJson {
            assert!(self.is_json_array(), "Not a JSON Array: {self}");
            self.clone()
        }
        fn members(&self) -> &Vec<(String, JJson)> {
            match self {
                JJson::Obj(m) => m,
                _ => panic!("Not a JSON Object: {self}"),
            }
        }
        /// The (name, value) pairs of an object, as entrySet() walks them.
        pub fn entries(&self) -> impl Iterator<Item = (&String, &JJson)> {
            self.members().iter().map(|(k, v)| (k, v))
        }
        pub fn keys(&self) -> impl Iterator<Item = &String> {
            self.members().iter().map(|(k, _)| k)
        }
        pub fn elements(&self) -> impl Iterator<Item = &JJson> {
            match self {
                JJson::Arr(a) => a.iter(),
                _ => panic!("Not a JSON Array: {self}"),
            }
        }
        pub fn has(&self, k: &str) -> bool {
            self.members().iter().any(|(n, _)| n == k)
        }
        /// JsonObject.get: None (null) when absent.
        pub fn get(&self, k: &str) -> Option<JJson> {
            self.members().iter().find(|(n, _)| n == k).map(|(_, v)| v.clone())
        }
        /// JsonObject.getAsJsonObject(name) / getAsJsonArray(name): null when absent, a cast that throws on the wrong kind.
        pub fn member_object(&self, k: &str) -> Option<JJson> {
            self.get(k).map(|v| v.as_object())
        }
        pub fn member_array(&self, k: &str) -> Option<JJson> {
            self.get(k).map(|v| v.as_array())
        }
        /// JsonArray.get(i).
        pub fn at(&self, i: i32) -> JJson {
            match self {
                JJson::Arr(a) => a.get(i as usize).cloned().unwrap_or_else(|| panic!("Index {i} out of bounds for length {}", a.len())),
                _ => panic!("Not a JSON Array: {self}"),
            }
        }
        pub fn size(&self) -> i32 {
            match self {
                JJson::Arr(a) => a.len() as i32,
                JJson::Obj(m) => m.len() as i32,
                _ => panic!("size() of a JSON primitive"),
            }
        }
        pub fn is_empty(&self) -> bool {
            self.size() == 0
        }
        /// The single value of a one-element array, as Gson's JsonArray.getAsX does.
        fn single(&self) -> &JJson {
            match self {
                JJson::Arr(a) if a.len() == 1 => &a[0],
                JJson::Arr(_) => panic!("Array must have size 1"),
                other => other,
            }
        }
        pub fn as_string(&self) -> String {
            match self.single() {
                JJson::Str(s) => s.clone(),
                JJson::Num(n) => n.clone(),
                JJson::Bool(b) => b.to_string(),
                other => panic!("UnsupportedOperationException: {other} as a string"),
            }
        }
        fn number_text(&self) -> String {
            match self.single() {
                JJson::Num(n) | JJson::Str(n) => n.trim().to_string(),
                other => panic!("UnsupportedOperationException: {other} as a number"),
            }
        }
        pub fn as_f64(&self) -> f64 {
            let t = self.number_text();
            t.parse().unwrap_or_else(|_| panic!("NumberFormatException: {t}"))
        }
        pub fn as_float(&self) -> f32 {
            self.as_f64() as f32
        }
        pub fn as_double(&self) -> f64 {
            self.as_f64()
        }
        /// getAsInt / getAsLong: a whole number, else the number cut to one.
        pub fn as_long(&self) -> i64 {
            let t = self.number_text();
            t.parse::<i64>().unwrap_or_else(|_| t.parse::<f64>().map(|f| f as i64).unwrap_or_else(|_| panic!("NumberFormatException: {t}")))
        }
        pub fn as_int(&self) -> i32 {
            self.as_long() as i32
        }
        pub fn as_bool(&self) -> bool {
            match self.single() {
                JJson::Bool(b) => *b,
                // Gson: Boolean.parseBoolean of the text
                other => other.as_string().eq_ignore_ascii_case("true"),
            }
        }
        pub fn add(&mut self, k: &str, v: JJson) {
            match self {
                JJson::Obj(m) => {
                    m.retain(|(n, _)| n != k);
                    m.push((k.to_string(), v));
                }
                _ => panic!("Not a JSON Object: {self}"),
            }
        }
        pub fn remove(&mut self, k: &str) -> Option<JJson> {
            match self {
                JJson::Obj(m) => {
                    let i = m.iter().position(|(n, _)| n == k)?;
                    Some(m.remove(i).1)
                }
                _ => panic!("Not a JSON Object: {self}"),
            }
        }
        pub fn push(&mut self, v: JJson) {
            match self {
                JJson::Arr(a) => a.push(v),
                _ => panic!("Not a JSON Array: {self}"),
            }
        }
        fn write(&self, out: &mut String, pretty: bool, html: bool, depth: usize) {
            let nl = |out: &mut String, d: usize| {
                if pretty {
                    out.push('\n');
                    out.push_str(&"  ".repeat(d));
                }
            };
            match self {
                JJson::Null => out.push_str("null"),
                JJson::Bool(b) => out.push_str(if *b { "true" } else { "false" }),
                JJson::Num(n) => out.push_str(n),
                JJson::Str(s) => j_json_quote(s, html, out),
                JJson::Arr(a) => {
                    out.push('[');
                    for (i, v) in a.iter().enumerate() {
                        if i > 0 {
                            out.push(',');
                        }
                        nl(out, depth + 1);
                        v.write(out, pretty, html, depth + 1);
                    }
                    if !a.is_empty() {
                        nl(out, depth);
                    }
                    out.push(']');
                }
                JJson::Obj(m) => {
                    out.push('{');
                    for (i, (k, v)) in m.iter().enumerate() {
                        if i > 0 {
                            out.push(',');
                        }
                        nl(out, depth + 1);
                        j_json_quote(k, html, out);
                        out.push(':');
                        if pretty {
                            out.push(' ');
                        }
                        v.write(out, pretty, html, depth + 1);
                    }
                    if !m.is_empty() {
                        nl(out, depth);
                    }
                    out.push('}');
                }
            }
        }
    }

    fn j_json_quote(s: &str, html: bool, out: &mut String) {
        out.push('"');
        for c in s.chars() {
            match c {
                '"' => out.push_str("\\\""),
                '\\' => out.push_str("\\\\"),
                '\n' => out.push_str("\\n"),
                '\r' => out.push_str("\\r"),
                '\t' => out.push_str("\\t"),
                '\u{8}' => out.push_str("\\b"),
                '\u{c}' => out.push_str("\\f"),
                '<' | '>' | '&' | '=' | '\'' if html => out.push_str(&format!("\\u{:04x}", c as u32)),
                '\u{2028}' | '\u{2029}' => out.push_str(&format!("\\u{:04x}", c as u32)),
                c if (c as u32) < 0x20 => out.push_str(&format!("\\u{:04x}", c as u32)),
                c => out.push(c),
            }
        }
        out.push('"');
    }

    /// JsonElement.toString: compact, without Gson's HTML escaping.
    impl std::fmt::Display for JJson {
        fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
            let mut out = String::new();
            self.write(&mut out, false, false, 0);
            f.write_str(&out)
        }
    }

    /// A Gson (from `new Gson()` or a GsonBuilder): how it writes.
    #[derive(Clone, Copy, Debug)]
    pub struct JGson {
        pub pretty: bool,
        pub html: bool,
        pub nulls: bool,
    }

    impl Default for JGson {
        fn default() -> Self {
            JGson { pretty: false, html: true, nulls: false }
        }
    }

    impl JGson {
        /// Gson.toJson.
        pub fn to_json(&self, v: &JJson) -> String {
            let mut out = String::new();
            self.strip(v).write(&mut out, self.pretty, self.html, 0);
            out
        }
        /// Without serializeNulls, Gson leaves out null fields of objects.
        fn strip(&self, v: &JJson) -> JJson {
            match v {
                JJson::Obj(m) => JJson::Obj(m.iter().filter(|(_, x)| self.nulls || !x.is_json_null()).map(|(k, x)| (k.clone(), self.strip(x))).collect()),
                JJson::Arr(a) => JJson::Arr(a.iter().map(|x| self.strip(x)).collect()),
                other => other.clone(),
            }
        }
    }

    #[cfg(test)]
    mod jjson_tests {
        use super::*;

        #[test]
        fn read_and_write() {
            let j = JJson::parse("{\"a\": 1, \"b\": [1.5, \"x\", true, null], \"c\": {\"d\": -2e3}}");
            assert!(j.has("a") && !j.has("z"));
            assert_eq!(j.get("a").unwrap().as_int(), 1);
            assert_eq!(j.member_array("b").unwrap().at(0).as_float(), 1.5);
            assert_eq!(j.member_array("b").unwrap().size(), 4);
            assert_eq!(j.member_object("c").unwrap().get("d").unwrap().as_double(), -2000.0);
            assert_eq!(j.get("z"), None);
            assert_eq!(j.to_string(), "{\"a\":1,\"b\":[1.5,\"x\",true,null],\"c\":{\"d\":-2e3}}");
            let g = JGson { pretty: true, ..JGson::default() };
            assert_eq!(g.to_json(&JJson::parse("{\"a\":[1,2],\"b\":{},\"n\":null,\"s\":\"<x>\"}")),
                       "{\n  \"a\": [\n    1,\n    2\n  ],\n  \"b\": {},\n  \"s\": \"\\u003cx\\u003e\"\n}");
        }

        #[test]
        fn java_numbers() {
            assert_eq!(j_java_num(1.0, true), "1.0");
            assert_eq!(j_java_num(0.1, true), "0.1");
            assert_eq!(j_java_num(1.0e-4, false), "1.0E-4");
            assert_eq!(j_java_num(12345678.0, false), "1.2345678E7");
            assert_eq!(j_java_num(-0.75, false), "-0.75");
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn names_are_set() {
        assert_eq!(ID, "origins_legacy");
        assert!(!NAME.is_empty());
        assert!(KEYS.iter().all(|[n, _, d]| !n.is_empty() && d.starts_with("key.")));
    }
}
