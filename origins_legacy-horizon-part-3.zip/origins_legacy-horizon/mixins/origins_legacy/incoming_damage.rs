// `origins:invulnerability`: Feline takes no fall damage, Blazeborn no fire damage.
fn origins_legacy_incoming_damage(entity: i32, kind: &str, damage_type: &str, canceled: &mut bool) {
    use horizon_core::noise::port_origins_legacy_core as oc;
    if kind != "minecraft:player" {
        return;
    }
    if let Some(origin) = oc::state::origin_of_entity(i64::from(entity)) {
        if oc::invulnerable_to(&origin, damage_type) {
            *canceled = true;
        }
    }
}
