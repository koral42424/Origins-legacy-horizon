// A player's `/origin ...`: parsed by `parse_command` (runtime.rs) and run by `run_origin_command` (game_side.rs).
fn origins_legacy_perform_command(
    game: &mut crate::game::Game<'_>,
    player: &horizon_client::mod_api::NativeServerPlayer,
    command: &str,
    ran: &mut bool,
) {
    use crate::game::port_origins_legacy as m;
    use horizon_core::noise::port_origins_legacy_core as oc;
    use crate::game::port_origins_legacy_game as g;
    let Some(parsed) = oc::parse_command(command) else {
        return;
    };
    *ran = true;
    let lines = match parsed {
        Err(usage) => vec![format!("\u{a7}c{usage}")],
        Ok(cmd) => {
            // Turned off in Options > Mods: the command answers, nothing else.
            if !game.native_on(m::ID) {
                vec!["\u{a7}cOrigins is turned off in Options > Mods.".to_owned()]
            } else {
                g::run_origin_command(game, player, &cmd)
            }
        }
    };
    for line in lines {
        game.native_feedback(horizon_client::text::Text::legacy(&line));
    }
}
