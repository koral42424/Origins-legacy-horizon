// Once a tick for every player: keeps the entity id -> origin table the id-only hooks read
// (breathing, damage) in step with each player's choice.
fn origins_legacy_player_tick(game: &mut crate::game::Game<'_>) {
    use crate::game::port_origins_legacy as m;
    use crate::game::port_origins_legacy_game as g;
    if !game.native_on(m::ID) {
        return;
    }
    let Some(player) = game.native_acting_player() else {
        return;
    };
    g::sync_entity(game, player.entity_id, player.uuid);
}
