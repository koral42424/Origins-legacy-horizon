// Not ported yet: the Java @Inject(TAIL) on Creeper.registerGoals (ScareCreepersMixin.addGoals).
// Why it's off: No Horizon function mapped for Creeper.registerGoals (run `match`, or map it in a --mappings file).
// horizon-mixins kind: RETURN
// Note: Horizon has no TAIL: RETURN runs at every exit, early ones too.
// Note: No Horizon function known for Creeper.registerGoals: run `match`.
//
// Game calls the Java code makes here, and what they are in Horizon:
//   EntitySelector.NO_CREATIVE_OR_SPECTATOR -> (not mapped yet)
//   AvoidEntityGoal.<init> -> (not mapped yet)
//   GoalSelector.addGoal -> (not mapped yet)
//   NearestAttackableTargetGoal.<init> -> (not mapped yet)
//   Creeper.registerGoals -> (not mapped yet)
//   Monster.<init> -> (not mapped yet)
//
// Decompiled Java, io/github/apace100/origins/mixin/ScareCreepersMixin.java:25:
// | @Inject(at = @At("TAIL"), method = "registerGoals")
// | private void addGoals(CallbackInfo info) {
// |    Goal goal = new AvoidEntityGoal(
// |       this, Player.class, OriginsPowerTypes.SCARE_CREEPERS::isActive, 6.0F, 1.0, 1.2, EntitySelector.NO_CREATIVE_OR_SPECTATOR::test
// |    );
// |    this.goalSelector.addGoal(3, goal);
// | }
