// Not ported yet: the Java @WrapOperation(INVOKE) on ConduitBlockEntity.applyEffects (ConduitOnLandMixin.allowConduitPowerOnLand).
// Why it's off: No Horizon function mapped for ConduitBlockEntity.applyEffects (run `match`, or map it in a --mappings file).
// horizon-mixins kind: WRAP_OPERATION
// Note: No Horizon function known for ConduitBlockEntity.applyEffects: run `match`.
// Note: The call it hooks (Player.isInWaterOrRain) isn't mapped to a Rust function yet.
//
// Game calls the Java code makes here, and what they are in Horizon:
//   Player.isInWaterOrRain -> (not mapped yet)
//   ConduitBlockEntity.applyEffects -> (not mapped yet)
//
// Decompiled Java, io/github/apace100/origins/mixin/ConduitOnLandMixin.java:13:
// | @WrapOperation(method = "applyEffects", at = @At(value = "INVOKE", target = "Lnet/minecraft/world/entity/player/Player;isInWaterOrRain()Z"))
// | private static boolean allowConduitPowerOnLand(Player playerEntity, Operation<Boolean> original) {
// |    return (Boolean)original.call(new Object[]{playerEntity}) || OriginsPowerTypes.CONDUIT_POWER_ON_LAND.isActive(playerEntity);
// | }
