// Not ported yet: the Java @Inject(HEAD) on ConnectScreen.connect (ServerCheckMixin.resetServerOriginsState).
// Why it's off: No Horizon function mapped for ConnectScreen.connect (run `match`, or map it in a --mappings file).
// horizon-mixins kind: HEAD
// Note: No Horizon function known for ConnectScreen.connect: run `match`.
//
// Game calls the Java code makes here, and what they are in Horizon:
//   ConnectScreen.connect -> (not mapped yet)
//
// Decompiled Java, io/github/apace100/origins/mixin/ServerCheckMixin.java:19:
// | @Inject(method = "connect", at = @At("HEAD"))
// | private void resetServerOriginsState(Minecraft minecraft, ServerAddress serverAddress, ServerData serverData, TransferState transferState, CallbackInfo ci) {
// |    OriginsClient.isServerRunningOrigins = false;
// | }
