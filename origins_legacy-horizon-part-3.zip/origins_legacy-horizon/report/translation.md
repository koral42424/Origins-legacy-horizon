# Java translated to Rust

Translated 16 of 401 methods (2 more are done another way in Horizon) and 26 of 96 static fields to Rust; 1 of 2 Fabric event handlers. It's in `runtime.rs`, under `pub mod java`; code that calls the game is in `game_side.rs`.

Each method is translated whole or not at all. A method that can't be (it uses Minecraft, a lambda, null...) is left out with its reason, and so is every method that calls it.

## Why methods were left out

| Cause | Methods | For example |
|---|---|---|
| Calls or uses other code that isn't translated | 319 | `Badge.getFactory(0)`: its class isn't translated (it's an interface) |
| Uses Minecraft classes (needs Horizon's game API) | 27 | `BadgeManager.sync(1)`: it uses Minecraft's `ServerPlayer` |
| Other Java this translator doesn't handle yet | 23 | `Badge.spriteId(0)`: it has no body |
| Uses other libraries | 9 | `BadgeManager.readCustomBadges(5)`: it uses `PowerType` (io.github.apace100.apoli.power) |
| Done another way in Horizon | 2 | `ModMenuIntegration.getModConfigScreenFactory(0)`: done another way in Horizon: the mod's page in Options > Mods (its settings buttons) |
| Uses Fabric API | 2 | `ModPackets.init(0)`: it calls Fabric's `PayloadTypeRegistry`.clientboundPlay |
| Uses Java collections other than List (Map, Set...) | 1 | `OriginRegistry.identifiers(0)`: it uses `Stream` (java.util.stream) |
| Uses lambdas or method references | 1 | `ModPacketsS2C.register(0)`: a method reference |
| Uses try/catch | 1 | `Origins.serializeConfig(0)`: a try/catch (SerializationException) |

## Fabric event handlers

| Handler | Hook | Result |
|---|---|---|
| io/github/apace100/origins/OriginsClient.java:30 | `tick` | not translated: `instanceof` |
| io/github/apace100/origins/Origins.java:60 | `init` | `on_init`, called from the hook, without: the call to `audit(..)`: it calls `MixinEnvironment` (org.spongepowered.asm.mixin).getCurrentEnvironment; the call to `ModPackets.init(..)`: it calls ModPackets.init, which isn't translated; the call to `ifPresent(..)`: a nullable object kept in a changing static; an assignment: it uses Origins.config, which isn't translated (it uses ServerConfig, which isn't translated (it implements `ConfigData` (me.shedaniel.autoconfig))); the call to `NamespaceAlias.addAlias(..)`: it calls `NamespaceAlias` (io.github.apace100.apoli.util).addAlias; the call to `NamespaceAlias.addAlias(..)`: it calls `NamespaceAlias` (io.github.apace100.apoli.util).addAlias; the call to `OriginsPowerTypes.register(..)`: it calls OriginsPowerTypes.register, which isn't translated; the call to `OriginsEntityConditions.register(..)`: it calls OriginsEntityConditions.register, which isn't translated; the call to `ModBlocks.register(..)`: it calls ModBlocks.register, which isn't translated; the call to `ModItems.register(..)`: it calls ModItems.register, which isn't translated; the call to `ModPacketsC2S.register(..)`: it calls ModPacketsC2S.register, which isn't translated; the call to `ModLoot.registerLootTables(..)`: it calls ModLoot.registerLootTables, which isn't translated; the call to `TRIGGER_TYPES.addAlias(..)`: it uses Minecraft's `BuiltInRegistries`.TRIGGER_TYPES |

## Every class


### `Badge`: it's an interface

- [ ] `Badge.spriteId(0)`: it has no body (io/github/apace100/origins/badge/Badge.java:19)
- [ ] `Badge.hasTooltip(0)`: it has no body (io/github/apace100/origins/badge/Badge.java:21)
- [ ] `Badge.getTooltipComponents(4)`: it has no body (io/github/apace100/origins/badge/Badge.java:23)
- [ ] `Badge.toData(1)`: it has no body (io/github/apace100/origins/badge/Badge.java:26)
- [ ] `Badge.getBadgeFactory(0)`: it has no body (io/github/apace100/origins/badge/Badge.java:28)
- [ ] `Badge.getFactory(0)`: its class isn't translated (it's an interface) (io/github/apace100/origins/badge/Badge.java:30)
- [ ] `Badge.writeBuf(1)`: its class isn't translated (it's an interface) (io/github/apace100/origins/badge/Badge.java:34)

### `BadgeFactories`

- [ ] `BadgeFactories.SPRITE`: it uses BadgeFactory, which isn't translated (it implements `DataObjectFactory` (io.github.apace100.calio.registry)) (io/github/apace100/origins/badge/BadgeFactories.java:8)
- [ ] `BadgeFactories.TOOLTIP`: it uses BadgeFactory, which isn't translated (it implements `DataObjectFactory` (io.github.apace100.calio.registry)) (io/github/apace100/origins/badge/BadgeFactories.java:11)
- [ ] `BadgeFactories.KEYBIND`: it uses BadgeFactory, which isn't translated (it implements `DataObjectFactory` (io.github.apace100.calio.registry)) (io/github/apace100/origins/badge/BadgeFactories.java:16)
- [ ] `BadgeFactories.CRAFTING_RECIPE`: it uses BadgeFactory, which isn't translated (it implements `DataObjectFactory` (io.github.apace100.calio.registry)) (io/github/apace100/origins/badge/BadgeFactories.java:21)

### `BadgeFactory`: it implements `DataObjectFactory` (io.github.apace100.calio.registry)

- [ ] `BadgeFactory.BadgeFactory(3)`: its class isn't translated (it implements `DataObjectFactory` (io.github.apace100.calio.registry)) (io/github/apace100/origins/badge/BadgeFactory.java:10)
- [ ] `BadgeFactory.getData(0)`: its class isn't translated (it implements `DataObjectFactory` (io.github.apace100.calio.registry)) (io/github/apace100/origins/badge/BadgeFactory.java:11)
- [ ] `BadgeFactory.fromData(1)`: its class isn't translated (it implements `DataObjectFactory` (io.github.apace100.calio.registry)) (io/github/apace100/origins/badge/BadgeFactory.java:15)
- [ ] `BadgeFactory.toData(1)`: its class isn't translated (it implements `DataObjectFactory` (io.github.apace100.calio.registry)) (io/github/apace100/origins/badge/BadgeFactory.java:19)
- [ ] `BadgeFactory.id(0)`: its class isn't translated (it implements `DataObjectFactory` (io.github.apace100.calio.registry)) (io/github/apace100/origins/badge/BadgeFactory.java:10)
- [ ] `BadgeFactory.data(0)`: its class isn't translated (it implements `DataObjectFactory` (io.github.apace100.calio.registry)) (io/github/apace100/origins/badge/BadgeFactory.java:10)
- [ ] `BadgeFactory.factory(0)`: its class isn't translated (it implements `DataObjectFactory` (io.github.apace100.calio.registry)) (io/github/apace100/origins/badge/BadgeFactory.java:10)

### `BadgeManager`

- [ ] `BadgeManager.REGISTRY`: it uses `DataObjectRegistry` (io.github.apace100.calio.registry) (io/github/apace100/origins/badge/BadgeManager.java:34)
- [ ] `BadgeManager.BADGES`: it uses Badge, which isn't translated (it's an interface) (io/github/apace100/origins/badge/BadgeManager.java:39)
- [x] `BadgeManager.TOGGLE_BADGE_SPRITE` (io/github/apace100/origins/badge/BadgeManager.java:40)
- [x] `BadgeManager.ACTIVE_BADGE_SPRITE` (io/github/apace100/origins/badge/BadgeManager.java:41)
- [x] `BadgeManager.RECIPE_BADGE_SPRITE` (io/github/apace100/origins/badge/BadgeManager.java:42)
- [x] `BadgeManager.TOGGLE_BADGE_ID` (io/github/apace100/origins/badge/BadgeManager.java:43)
- [x] `BadgeManager.ACTIVE_BADGE_ID` (io/github/apace100/origins/badge/BadgeManager.java:44)
- [ ] `BadgeManager.init(0)`: it calls BadgeManager.register, which isn't translated (io/github/apace100/origins/badge/BadgeManager.java:46)
- [ ] `BadgeManager.register(1)`: it uses BadgeFactory, which isn't translated (it implements `DataObjectFactory` (io.github.apace100.calio.registry)) (io/github/apace100/origins/badge/BadgeManager.java:57)
- [ ] `BadgeManager.putPowerBadge(2)`: it uses Badge, which isn't translated (it's an interface) (io/github/apace100/origins/badge/BadgeManager.java:61)
- [ ] `BadgeManager.getPowerBadges(1)`: it uses Badge, which isn't translated (it's an interface) (io/github/apace100/origins/badge/BadgeManager.java:66)
- [ ] `BadgeManager.clear(0)`: it uses BadgeManager.BADGES, which isn't translated (it uses Badge, which isn't translated (it's an interface)) (io/github/apace100/origins/badge/BadgeManager.java:70)
- [ ] `BadgeManager.sync(1)`: it uses Minecraft's `ServerPlayer` (io/github/apace100/origins/badge/BadgeManager.java:74)
- [ ] `BadgeManager.readCustomBadges(5)`: it uses `PowerType` (io.github.apace100.apoli.power) (io/github/apace100/origins/badge/BadgeManager.java:79)
- [ ] `BadgeManager.readAutoBadges(5)`: it uses `PowerType` (io.github.apace100.apoli.power) (io/github/apace100/origins/badge/BadgeManager.java:113)
- [ ] `BadgeManager.createAutoBadges(3)`: it uses `PowerType` (io.github.apace100.apoli.power) (io/github/apace100/origins/badge/BadgeManager.java:131)

### `CraftingRecipeBadge`: it implements `Badge`

- [ ] `CraftingRecipeBadge.CraftingRecipeBadge(4)`: its class isn't translated (it implements `Badge`) (io/github/apace100/origins/badge/CraftingRecipeBadge.java:26)
- [ ] `CraftingRecipeBadge.CraftingRecipeBadge(1)`: its class isn't translated (it implements `Badge`) (io/github/apace100/origins/badge/CraftingRecipeBadge.java:27)
- [ ] `CraftingRecipeBadge.hasTooltip(0)`: its class isn't translated (it implements `Badge`) (io/github/apace100/origins/badge/CraftingRecipeBadge.java:31)
- [ ] `CraftingRecipeBadge.peekInputs(1)`: its class isn't translated (it implements `Badge`) (io/github/apace100/origins/badge/CraftingRecipeBadge.java:36)
- [ ] `CraftingRecipeBadge.getTooltipComponents(4)`: its class isn't translated (it implements `Badge`) (io/github/apace100/origins/badge/CraftingRecipeBadge.java:51)
- [ ] `CraftingRecipeBadge.toData(1)`: its class isn't translated (it implements `Badge`) (io/github/apace100/origins/badge/CraftingRecipeBadge.java:93)
- [ ] `CraftingRecipeBadge.getBadgeFactory(0)`: its class isn't translated (it implements `Badge`) (io/github/apace100/origins/badge/CraftingRecipeBadge.java:102)
- [ ] `CraftingRecipeBadge.spriteId(0)`: its class isn't translated (it implements `Badge`) (io/github/apace100/origins/badge/CraftingRecipeBadge.java:26)
- [ ] `CraftingRecipeBadge.recipe(0)`: its class isn't translated (it implements `Badge`) (io/github/apace100/origins/badge/CraftingRecipeBadge.java:26)
- [ ] `CraftingRecipeBadge.prefix(0)`: its class isn't translated (it implements `Badge`) (io/github/apace100/origins/badge/CraftingRecipeBadge.java:26)
- [ ] `CraftingRecipeBadge.suffix(0)`: its class isn't translated (it implements `Badge`) (io/github/apace100/origins/badge/CraftingRecipeBadge.java:26)

### `KeybindBadge`: it implements `Badge`

- [ ] `KeybindBadge.KeybindBadge(2)`: its class isn't translated (it implements `Badge`) (io/github/apace100/origins/badge/KeybindBadge.java:17)
- [ ] `KeybindBadge.KeybindBadge(1)`: its class isn't translated (it implements `Badge`) (io/github/apace100/origins/badge/KeybindBadge.java:18)
- [ ] `KeybindBadge.hasTooltip(0)`: its class isn't translated (it implements `Badge`) (io/github/apace100/origins/badge/KeybindBadge.java:22)
- [ ] `KeybindBadge.addLines(4)`: it uses Minecraft's `ClientTooltipComponent` (io/github/apace100/origins/badge/KeybindBadge.java:27)
- [ ] `KeybindBadge.getTooltipComponents(4)`: its class isn't translated (it implements `Badge`) (io/github/apace100/origins/badge/KeybindBadge.java:37)
- [ ] `KeybindBadge.toData(1)`: its class isn't translated (it implements `Badge`) (io/github/apace100/origins/badge/KeybindBadge.java:47)
- [ ] `KeybindBadge.getBadgeFactory(0)`: its class isn't translated (it implements `Badge`) (io/github/apace100/origins/badge/KeybindBadge.java:54)
- [ ] `KeybindBadge.spriteId(0)`: its class isn't translated (it implements `Badge`) (io/github/apace100/origins/badge/KeybindBadge.java:17)
- [ ] `KeybindBadge.text(0)`: its class isn't translated (it implements `Badge`) (io/github/apace100/origins/badge/KeybindBadge.java:17)

### `SpriteBadge`: it implements `Badge`

- [ ] `SpriteBadge.SpriteBadge(1)`: its class isn't translated (it implements `Badge`) (io/github/apace100/origins/badge/SpriteBadge.java:12)
- [ ] `SpriteBadge.hasTooltip(0)`: its class isn't translated (it implements `Badge`) (io/github/apace100/origins/badge/SpriteBadge.java:16)
- [ ] `SpriteBadge.getTooltipComponents(4)`: its class isn't translated (it implements `Badge`) (io/github/apace100/origins/badge/SpriteBadge.java:21)
- [ ] `SpriteBadge.toData(1)`: its class isn't translated (it implements `Badge`) (io/github/apace100/origins/badge/SpriteBadge.java:26)
- [ ] `SpriteBadge.getBadgeFactory(0)`: its class isn't translated (it implements `Badge`) (io/github/apace100/origins/badge/SpriteBadge.java:32)
- [ ] `SpriteBadge.spriteId(0)`: its class isn't translated (it implements `Badge`) (io/github/apace100/origins/badge/SpriteBadge.java:11)

### `TooltipBadge`: it implements `Badge`

- [ ] `TooltipBadge.TooltipBadge(2)`: its class isn't translated (it implements `Badge`) (io/github/apace100/origins/badge/TooltipBadge.java:14)
- [ ] `TooltipBadge.TooltipBadge(1)`: its class isn't translated (it implements `Badge`) (io/github/apace100/origins/badge/TooltipBadge.java:15)
- [ ] `TooltipBadge.hasTooltip(0)`: its class isn't translated (it implements `Badge`) (io/github/apace100/origins/badge/TooltipBadge.java:19)
- [ ] `TooltipBadge.addLines(4)`: it uses Minecraft's `ClientTooltipComponent` (io/github/apace100/origins/badge/TooltipBadge.java:24)
- [ ] `TooltipBadge.getTooltipComponents(4)`: its class isn't translated (it implements `Badge`) (io/github/apace100/origins/badge/TooltipBadge.java:34)
- [ ] `TooltipBadge.toData(1)`: its class isn't translated (it implements `Badge`) (io/github/apace100/origins/badge/TooltipBadge.java:41)
- [ ] `TooltipBadge.getBadgeFactory(0)`: its class isn't translated (it implements `Badge`) (io/github/apace100/origins/badge/TooltipBadge.java:48)
- [ ] `TooltipBadge.spriteId(0)`: its class isn't translated (it implements `Badge`) (io/github/apace100/origins/badge/TooltipBadge.java:14)
- [ ] `TooltipBadge.text(0)`: its class isn't translated (it implements `Badge`) (io/github/apace100/origins/badge/TooltipBadge.java:14)

### `LayerArgumentType`: it implements Minecraft's `ArgumentType`

- [ ] `LayerArgumentType.LAYER_NOT_FOUND`: it uses Minecraft's `DynamicCommandExceptionType` (io/github/apace100/origins/command/LayerArgumentType.java:19)
- [ ] `LayerArgumentType.layer(0)`: it uses LayerArgumentType, which isn't translated (it implements Minecraft's `ArgumentType`) (io/github/apace100/origins/command/LayerArgumentType.java:23)
- [ ] `LayerArgumentType.parse(1)`: its class isn't translated (it implements Minecraft's `ArgumentType`) (io/github/apace100/origins/command/LayerArgumentType.java:27)
- [ ] `LayerArgumentType.getLayer(2)`: it uses OriginLayer, which isn't translated (it implements `Comparable`) (io/github/apace100/origins/command/LayerArgumentType.java:31)
- [ ] `LayerArgumentType.listSuggestions(2)`: it's generic (io/github/apace100/origins/command/LayerArgumentType.java:41)

### `OriginArgumentType`: it implements Minecraft's `ArgumentType`

- [ ] `OriginArgumentType.ORIGIN_NOT_FOUND`: it uses Minecraft's `DynamicCommandExceptionType` (io/github/apace100/origins/command/OriginArgumentType.java:23)
- [ ] `OriginArgumentType.origin(0)`: it uses OriginArgumentType, which isn't translated (it implements Minecraft's `ArgumentType`) (io/github/apace100/origins/command/OriginArgumentType.java:27)
- [ ] `OriginArgumentType.parse(1)`: its class isn't translated (it implements Minecraft's `ArgumentType`) (io/github/apace100/origins/command/OriginArgumentType.java:31)
- [ ] `OriginArgumentType.getOrigin(2)`: it uses Origin, which isn't translated (it uses `PowerType` (io.github.apace100.apoli.power)) (io/github/apace100/origins/command/OriginArgumentType.java:35)
- [ ] `OriginArgumentType.listSuggestions(2)`: it's generic (io/github/apace100/origins/command/OriginArgumentType.java:45)

### `OriginCommand`

- [ ] `OriginCommand.register(1)`: it uses Minecraft's `CommandDispatcher` (io/github/apace100/origins/command/OriginCommand.java:29)
- [ ] `OriginCommand.setOrigin(1)`: it uses Minecraft's `CommandContext` (io/github/apace100/origins/command/OriginCommand.java:83)
- [ ] `OriginCommand.hasOrigin(1)`: it uses Minecraft's `CommandContext` (io/github/apace100/origins/command/OriginCommand.java:131)
- [ ] `OriginCommand.getOrigin(1)`: it uses Minecraft's `CommandContext` (io/github/apace100/origins/command/OriginCommand.java:165)
- [ ] `OriginCommand.openSingleLayerScreen(1)`: it uses Minecraft's `CommandContext` (io/github/apace100/origins/command/OriginCommand.java:186)
- [ ] `OriginCommand.openMultipleLayerScreens(2)`: it uses Minecraft's `CommandContext` (io/github/apace100/origins/command/OriginCommand.java:201)
- [ ] `OriginCommand.randomizeOrigin(1)`: it uses Minecraft's `CommandContext` (io/github/apace100/origins/command/OriginCommand.java:223)
- [ ] `OriginCommand.randomizeOrigins(2)`: it uses Minecraft's `CommandContext` (io/github/apace100/origins/command/OriginCommand.java:263)
- [ ] `OriginCommand.openLayerScreen(2)`: it uses Minecraft's `ServerPlayer` (io/github/apace100/origins/command/OriginCommand.java:285)
- [ ] `OriginCommand.getRandomOrigin(2)`: it uses Origin, which isn't translated (it uses `PowerType` (io.github.apace100.apoli.power)) (io/github/apace100/origins/command/OriginCommand.java:296)

### `OriginCommand.TargetType`


### `OriginComponent`: it's an interface

- [ ] `OriginComponent.hasOrigin(1)`: it has no body (io/github/apace100/origins/component/OriginComponent.java:23)
- [ ] `OriginComponent.hasAllOrigins(0)`: it has no body (io/github/apace100/origins/component/OriginComponent.java:25)
- [ ] `OriginComponent.getOrigins(0)`: it has no body (io/github/apace100/origins/component/OriginComponent.java:27)
- [ ] `OriginComponent.getOrigin(1)`: it has no body (io/github/apace100/origins/component/OriginComponent.java:29)
- [ ] `OriginComponent.hadOriginBefore(0)`: it has no body (io/github/apace100/origins/component/OriginComponent.java:31)
- [ ] `OriginComponent.setOrigin(2)`: it has no body (io/github/apace100/origins/component/OriginComponent.java:33)
- [ ] `OriginComponent.sync(0)`: it has no body (io/github/apace100/origins/component/OriginComponent.java:35)
- [ ] `OriginComponent.onPowersRead(0)`: it has no body (io/github/apace100/origins/component/OriginComponent.java:37)
- [ ] `OriginComponent.sync(1)`: it uses ModComponents.ORIGIN, which isn't translated (it uses `ComponentKey` (org.ladysnake.cca.api.v3.component)) (io/github/apace100/origins/component/OriginComponent.java:40)
- [ ] `OriginComponent.onChosen(2)`: it uses `ModifyPlayerSpawnPower` (io.github.apace100.apoli.power).class (io/github/apace100/origins/component/OriginComponent.java:45)
- [ ] `OriginComponent.partialOnChosen(3)`: it uses Origin, which isn't translated (it uses `PowerType` (io.github.apace100.apoli.power)) (io/github/apace100/origins/component/OriginComponent.java:53)
- [ ] `OriginComponent.checkAutoChoosingLayers(2)`: its class isn't translated (it's an interface) (io/github/apace100/origins/component/OriginComponent.java:66)

### `OriginTargetsComponent`

- [ ] `OriginTargetsComponent.CODEC`: it uses Minecraft's `Codec` (io/github/apace100/origins/component/OriginTargetsComponent.java:14)
- [ ] `OriginTargetsComponent.STREAM_CODEC`: it uses Minecraft's `StreamCodec` (io/github/apace100/origins/component/OriginTargetsComponent.java:18)
- [ ] `OriginTargetsComponent.TYPE`: it uses Minecraft's `DataComponentType` (io/github/apace100/origins/component/OriginTargetsComponent.java:21)
- [x] `OriginTargetsComponent.OriginTargetsComponent(1)` (io/github/apace100/origins/component/OriginTargetsComponent.java:13)
- [x] `OriginTargetsComponent.targets(0)` (io/github/apace100/origins/component/OriginTargetsComponent.java:13)

### `OriginTargetsComponent.OriginTarget`

- [ ] `OriginTargetsComponent.OriginTarget.CODEC`: it uses Minecraft's `Codec` (io/github/apace100/origins/component/OriginTargetsComponent.java:24)
- [ ] `OriginTargetsComponent.OriginTarget.STREAM_CODEC`: it uses Minecraft's `StreamCodec` (io/github/apace100/origins/component/OriginTargetsComponent.java:31)
- [ ] `OriginTargetsComponent.OriginTarget.OriginTarget(2)`: an Optional parameter (io/github/apace100/origins/component/OriginTargetsComponent.java:23)
- [x] `OriginTargetsComponent.OriginTarget.layer(0)` (io/github/apace100/origins/component/OriginTargetsComponent.java:23)
- [x] `OriginTargetsComponent.OriginTarget.origin(0)` (io/github/apace100/origins/component/OriginTargetsComponent.java:23)

### `PlayerOriginComponent`: it implements `OriginComponent`

- [ ] `PlayerOriginComponent.PlayerOriginComponent(1)`: its class isn't translated (it implements `OriginComponent`) (io/github/apace100/origins/component/PlayerOriginComponent.java:27)
- [ ] `PlayerOriginComponent.hasAllOrigins(0)`: its class isn't translated (it implements `OriginComponent`) (io/github/apace100/origins/component/PlayerOriginComponent.java:31)
- [ ] `PlayerOriginComponent.getOrigins(0)`: its class isn't translated (it implements `OriginComponent`) (io/github/apace100/origins/component/PlayerOriginComponent.java:42)
- [ ] `PlayerOriginComponent.hasOrigin(1)`: its class isn't translated (it implements `OriginComponent`) (io/github/apace100/origins/component/PlayerOriginComponent.java:47)
- [ ] `PlayerOriginComponent.getOrigin(1)`: its class isn't translated (it implements `OriginComponent`) (io/github/apace100/origins/component/PlayerOriginComponent.java:52)
- [ ] `PlayerOriginComponent.hadOriginBefore(0)`: its class isn't translated (it implements `OriginComponent`) (io/github/apace100/origins/component/PlayerOriginComponent.java:57)
- [ ] `PlayerOriginComponent.setOrigin(2)`: its class isn't translated (it implements `OriginComponent`) (io/github/apace100/origins/component/PlayerOriginComponent.java:62)
- [ ] `PlayerOriginComponent.grantPowersFromOrigin(2)`: its class isn't translated (it implements `OriginComponent`) (io/github/apace100/origins/component/PlayerOriginComponent.java:83)
- [ ] `PlayerOriginComponent.revokeRemovedPowers(2)`: its class isn't translated (it implements `OriginComponent`) (io/github/apace100/origins/component/PlayerOriginComponent.java:93)
- [ ] `PlayerOriginComponent.readData(1)`: its class isn't translated (it implements `OriginComponent`) (io/github/apace100/origins/component/PlayerOriginComponent.java:99)
- [ ] `PlayerOriginComponent.onPowersRead(0)`: its class isn't translated (it implements `OriginComponent`) (io/github/apace100/origins/component/PlayerOriginComponent.java:222)
- [ ] `PlayerOriginComponent.writeData(1)`: its class isn't translated (it implements `OriginComponent`) (io/github/apace100/origins/component/PlayerOriginComponent.java:226)
- [ ] `PlayerOriginComponent.sync(0)`: its class isn't translated (it implements `OriginComponent`) (io/github/apace100/origins/component/PlayerOriginComponent.java:238)

### `OrbOfOriginItem`: it extends Minecraft's `Item`

- [ ] `OrbOfOriginItem.OrbOfOriginItem(0)`: its class isn't translated (it extends Minecraft's `Item`) (io/github/apace100/origins/content/OrbOfOriginItem.java:35)
- [ ] `OrbOfOriginItem.use(3)`: its class isn't translated (it extends Minecraft's `Item`) (io/github/apace100/origins/content/OrbOfOriginItem.java:39)
- [ ] `OrbOfOriginItem.appendHoverText(5)`: its class isn't translated (it extends Minecraft's `Item`) (io/github/apace100/origins/content/OrbOfOriginItem.java:68)
- [ ] `OrbOfOriginItem.getTargets(1)`: its class isn't translated (it extends Minecraft's `Item`) (io/github/apace100/origins/content/OrbOfOriginItem.java:89)

### `TemporaryCobwebBlock`: it extends Minecraft's `WebBlock`

- [ ] `TemporaryCobwebBlock.TemporaryCobwebBlock(1)`: its class isn't translated (it extends Minecraft's `WebBlock`) (io/github/apace100/origins/content/TemporaryCobwebBlock.java:19)
- [ ] `TemporaryCobwebBlock.tick(4)`: its class isn't translated (it extends Minecraft's `WebBlock`) (io/github/apace100/origins/content/TemporaryCobwebBlock.java:23)
- [ ] `TemporaryCobwebBlock.getShape(4)`: its class isn't translated (it extends Minecraft's `WebBlock`) (io/github/apace100/origins/content/TemporaryCobwebBlock.java:29)
- [ ] `TemporaryCobwebBlock.getCollisionShape(4)`: its class isn't translated (it extends Minecraft's `WebBlock`) (io/github/apace100/origins/content/TemporaryCobwebBlock.java:33)
- [ ] `TemporaryCobwebBlock.onPlace(5)`: its class isn't translated (it extends Minecraft's `WebBlock`) (io/github/apace100/origins/content/TemporaryCobwebBlock.java:37)
- [ ] `TemporaryCobwebBlock.entityInside(6)`: its class isn't translated (it extends Minecraft's `WebBlock`) (io/github/apace100/origins/content/TemporaryCobwebBlock.java:42)

### `CompatibilityDataTypes`

- [ ] `CompatibilityDataTypes.ITEM_OR_ITEM_STACK_TEMPLATE`: it uses `SerializableDataType` (io.github.apace100.calio.data) (io/github/apace100/origins/data/CompatibilityDataTypes.java:10)
- [ ] `CompatibilityDataTypes.ITEM_OR_ITEM_STACK`: it uses `SerializableDataType` (io.github.apace100.calio.data) (io/github/apace100/origins/data/CompatibilityDataTypes.java:23)

### `OriginsDataTypes`

- [ ] `OriginsDataTypes.IMPACT`: it uses `SerializableDataType` (io.github.apace100.calio.data) (io/github/apace100/origins/data/OriginsDataTypes.java:9)
- [ ] `OriginsDataTypes.UPGRADE`: it uses `SerializableDataType` (io.github.apace100.calio.data) (io/github/apace100/origins/data/OriginsDataTypes.java:10)
- [ ] `OriginsDataTypes.UPGRADES`: it uses `SerializableDataType` (io.github.apace100.calio.data) (io/github/apace100/origins/data/OriginsDataTypes.java:13)

### `EnderianPearlEntity`: it extends Minecraft's `ThrowableItemProjectile`

- [ ] `EnderianPearlEntity.EnderianPearlEntity(2)`: its class isn't translated (it extends Minecraft's `ThrowableItemProjectile`) (io/github/apace100/origins/entity/EnderianPearlEntity.java:23)
- [ ] `EnderianPearlEntity.EnderianPearlEntity(2)`: its class isn't translated (it extends Minecraft's `ThrowableItemProjectile`) (io/github/apace100/origins/entity/EnderianPearlEntity.java:27)
- [ ] `EnderianPearlEntity.EnderianPearlEntity(4)`: its class isn't translated (it extends Minecraft's `ThrowableItemProjectile`) (io/github/apace100/origins/entity/EnderianPearlEntity.java:32)
- [ ] `EnderianPearlEntity.getDefaultItem(0)`: its class isn't translated (it extends Minecraft's `ThrowableItemProjectile`) (io/github/apace100/origins/entity/EnderianPearlEntity.java:37)
- [ ] `EnderianPearlEntity.onHit(1)`: its class isn't translated (it extends Minecraft's `ThrowableItemProjectile`) (io/github/apace100/origins/entity/EnderianPearlEntity.java:41)
- [ ] `EnderianPearlEntity.tick(0)`: its class isn't translated (it extends Minecraft's `ThrowableItemProjectile`) (io/github/apace100/origins/entity/EnderianPearlEntity.java:77)
- [ ] `EnderianPearlEntity.teleport(1)`: its class isn't translated (it extends Minecraft's `ThrowableItemProjectile`) (io/github/apace100/origins/entity/EnderianPearlEntity.java:86)

### `AutoBadgeCallback`: it's an interface

- [ ] `AutoBadgeCallback.createAutoBadge(3)`: it has no body (io/github/apace100/origins/integration/AutoBadgeCallback.java:17)

### `ModMenuIntegration`: it implements `ModMenuApi` (com.terraformersmc.modmenu.api)

- [ ] `ModMenuIntegration.getModConfigScreenFactory(0)`: done another way in Horizon: the mod's page in Options > Mods (its settings buttons) (io/github/apace100/origins/integration/ModMenuIntegration.java:13)

### `OriginDataLoadedCallback`: it's an interface

- [ ] `OriginDataLoadedCallback.onDataLoaded(1)`: it has no body (io/github/apace100/origins/integration/OriginDataLoadedCallback.java:13)
- [ ] `ArgumentTypesMixin`: a Mixin class: its handlers are the injections, in the bundle's helpers (io/github/apace100/origins/integration/OriginDataLoadedCallback.java:18)
- [ ] `ConduitOnLandMixin`: a Mixin class: its handlers are the injections, in the bundle's helpers (io/github/apace100/origins/integration/OriginDataLoadedCallback.java:12)
- [ ] `DebugContextMixin`: a Mixin class: its handlers are the injections, in the bundle's helpers (io/github/apace100/origins/integration/OriginDataLoadedCallback.java:9)
- [ ] `LikeWaterMixin`: a Mixin class: its handlers are the injections, in the bundle's helpers (io/github/apace100/origins/integration/OriginDataLoadedCallback.java:15)
- [ ] `LoginMixin`: a Mixin class: its handlers are the injections, in the bundle's helpers (io/github/apace100/origins/integration/OriginDataLoadedCallback.java:32)
- [ ] `NoCobwebSlowdownMixin`: a Mixin class: its handlers are the injections, in the bundle's helpers (io/github/apace100/origins/integration/OriginDataLoadedCallback.java:18)
- [ ] `OriginUpgradeMixin`: a Mixin class: its handlers are the injections, in the bundle's helpers (io/github/apace100/origins/integration/OriginDataLoadedCallback.java:24)
- [ ] `ScareCreepersMixin`: a Mixin class: its handlers are the injections, in the bundle's helpers (io/github/apace100/origins/integration/OriginDataLoadedCallback.java:20)
- [ ] `SelectionInvulnerabilityMixin`: a Mixin class: its handlers are the injections, in the bundle's helpers (io/github/apace100/origins/integration/OriginDataLoadedCallback.java:15)
- [ ] `ServerCheckMixin`: a Mixin class: its handlers are the injections, in the bundle's helpers (io/github/apace100/origins/integration/OriginDataLoadedCallback.java:18)

### `WaterBreathingMixin`

- [ ] `WaterBreathingMixin.CanBreatheInWater`: a Mixin class: its handlers are the injections, in the bundle's helpers (io/github/apace100/origins/mixin/WaterBreathingMixin.java:23)
- [ ] `WaterBreathingMixin.UpdateAir`: a Mixin class: its handlers are the injections, in the bundle's helpers (io/github/apace100/origins/mixin/WaterBreathingMixin.java:37)
- [ ] `WaterVisibilityMixin`: a Mixin class: its handlers are the injections, in the bundle's helpers (io/github/apace100/origins/mixin/WaterBreathingMixin.java:17)

### `BadgeListPacket`: it implements Minecraft's `CustomPacketPayload`

- [ ] `BadgeListPacket.CODEC`: it uses Minecraft's `StreamCodec` (io/github/apace100/origins/networking/BadgeListPacket.java:15)
- [ ] `BadgeListPacket.BadgeListPacket(1)`: its class isn't translated (it implements Minecraft's `CustomPacketPayload`) (io/github/apace100/origins/networking/BadgeListPacket.java:14)
- [ ] `BadgeListPacket.type(0)`: its class isn't translated (it implements Minecraft's `CustomPacketPayload`) (io/github/apace100/origins/networking/BadgeListPacket.java:19)
- [ ] `BadgeListPacket.badges(0)`: its class isn't translated (it implements Minecraft's `CustomPacketPayload`) (io/github/apace100/origins/networking/BadgeListPacket.java:14)

### `ChooseOriginPacket`: it implements Minecraft's `CustomPacketPayload`

- [ ] `ChooseOriginPacket.CODEC`: it uses Minecraft's `StreamCodec` (io/github/apace100/origins/networking/ChooseOriginPacket.java:10)
- [ ] `ChooseOriginPacket.ChooseOriginPacket(2)`: its class isn't translated (it implements Minecraft's `CustomPacketPayload`) (io/github/apace100/origins/networking/ChooseOriginPacket.java:9)
- [ ] `ChooseOriginPacket.type(0)`: its class isn't translated (it implements Minecraft's `CustomPacketPayload`) (io/github/apace100/origins/networking/ChooseOriginPacket.java:14)
- [ ] `ChooseOriginPacket.originId(0)`: its class isn't translated (it implements Minecraft's `CustomPacketPayload`) (io/github/apace100/origins/networking/ChooseOriginPacket.java:9)
- [ ] `ChooseOriginPacket.layerId(0)`: its class isn't translated (it implements Minecraft's `CustomPacketPayload`) (io/github/apace100/origins/networking/ChooseOriginPacket.java:9)

### `ChooseRandomOriginPacket`: it implements Minecraft's `CustomPacketPayload`

- [ ] `ChooseRandomOriginPacket.CODEC`: it uses Minecraft's `StreamCodec` (io/github/apace100/origins/networking/ChooseRandomOriginPacket.java:10)
- [ ] `ChooseRandomOriginPacket.ChooseRandomOriginPacket(1)`: its class isn't translated (it implements Minecraft's `CustomPacketPayload`) (io/github/apace100/origins/networking/ChooseRandomOriginPacket.java:9)
- [ ] `ChooseRandomOriginPacket.type(0)`: its class isn't translated (it implements Minecraft's `CustomPacketPayload`) (io/github/apace100/origins/networking/ChooseRandomOriginPacket.java:14)
- [ ] `ChooseRandomOriginPacket.layerId(0)`: its class isn't translated (it implements Minecraft's `CustomPacketPayload`) (io/github/apace100/origins/networking/ChooseRandomOriginPacket.java:9)

### `ConfirmOriginPacket`: it implements Minecraft's `CustomPacketPayload`

- [ ] `ConfirmOriginPacket.CODEC`: it uses Minecraft's `StreamCodec` (io/github/apace100/origins/networking/ConfirmOriginPacket.java:10)
- [ ] `ConfirmOriginPacket.ConfirmOriginPacket(2)`: its class isn't translated (it implements Minecraft's `CustomPacketPayload`) (io/github/apace100/origins/networking/ConfirmOriginPacket.java:9)
- [ ] `ConfirmOriginPacket.type(0)`: its class isn't translated (it implements Minecraft's `CustomPacketPayload`) (io/github/apace100/origins/networking/ConfirmOriginPacket.java:14)
- [ ] `ConfirmOriginPacket.layerId(0)`: its class isn't translated (it implements Minecraft's `CustomPacketPayload`) (io/github/apace100/origins/networking/ConfirmOriginPacket.java:9)
- [ ] `ConfirmOriginPacket.originId(0)`: its class isn't translated (it implements Minecraft's `CustomPacketPayload`) (io/github/apace100/origins/networking/ConfirmOriginPacket.java:9)

### `LayerListPacket`: it implements Minecraft's `CustomPacketPayload`

- [ ] `LayerListPacket.CODEC`: it uses Minecraft's `StreamCodec` (io/github/apace100/origins/networking/LayerListPacket.java:12)
- [ ] `LayerListPacket.LayerListPacket(1)`: its class isn't translated (it implements Minecraft's `CustomPacketPayload`) (io/github/apace100/origins/networking/LayerListPacket.java:11)
- [ ] `LayerListPacket.type(0)`: its class isn't translated (it implements Minecraft's `CustomPacketPayload`) (io/github/apace100/origins/networking/LayerListPacket.java:16)
- [ ] `LayerListPacket.layers(0)`: its class isn't translated (it implements Minecraft's `CustomPacketPayload`) (io/github/apace100/origins/networking/LayerListPacket.java:11)

### `ModPackets`

- [x] `ModPackets.HANDSHAKE` (io/github/apace100/origins/networking/ModPackets.java:9)
- [ ] `ModPackets.OPEN_ORIGIN_SCREEN`: it uses Minecraft's `Type` (io/github/apace100/origins/networking/ModPackets.java:10)
- [ ] `ModPackets.CHOOSE_ORIGIN`: it uses Minecraft's `Type` (io/github/apace100/origins/networking/ModPackets.java:11)
- [ ] `ModPackets.ORIGIN_LIST`: it uses Minecraft's `Type` (io/github/apace100/origins/networking/ModPackets.java:12)
- [ ] `ModPackets.LAYER_LIST`: it uses Minecraft's `Type` (io/github/apace100/origins/networking/ModPackets.java:13)
- [ ] `ModPackets.CHOOSE_RANDOM_ORIGIN`: it uses Minecraft's `Type` (io/github/apace100/origins/networking/ModPackets.java:14)
- [ ] `ModPackets.CONFIRM_ORIGIN`: it uses Minecraft's `Type` (io/github/apace100/origins/networking/ModPackets.java:15)
- [ ] `ModPackets.BADGE_LIST`: it uses Minecraft's `Type` (io/github/apace100/origins/networking/ModPackets.java:16)
- [ ] `ModPackets.POWERS_AND_ORIGINS`: it uses Minecraft's `Type` (io/github/apace100/origins/networking/ModPackets.java:17)
- [ ] `ModPackets.init(0)`: it calls Fabric's `PayloadTypeRegistry`.clientboundPlay (io/github/apace100/origins/networking/ModPackets.java:19)

### `ModPacketsC2S`

- [ ] `ModPacketsC2S.register(0)`: it uses Origins.config, which isn't translated (it uses ServerConfig, which isn't translated (it implements `ConfigData` (me.shedaniel.autoconfig))) (io/github/apace100/origins/networking/ModPacketsC2S.java:28)
- [ ] `ModPacketsC2S.chooseOrigin(2)`: it uses ChooseOriginPacket, which isn't translated (it implements Minecraft's `CustomPacketPayload`) (io/github/apace100/origins/networking/ModPacketsC2S.java:38)
- [ ] `ModPacketsC2S.chooseRandomOrigin(2)`: it uses ChooseRandomOriginPacket, which isn't translated (it implements Minecraft's `CustomPacketPayload`) (io/github/apace100/origins/networking/ModPacketsC2S.java:88)
- [ ] `ModPacketsC2S.handleHandshakeReply(6)`: it uses Minecraft's `MinecraftServer` (io/github/apace100/origins/networking/ModPacketsC2S.java:143)
- [ ] `ModPacketsC2S.handshake(4)`: it uses Minecraft's `ServerLoginPacketListenerImpl` (io/github/apace100/origins/networking/ModPacketsC2S.java:180)
- [ ] `ModPacketsC2S.confirmOrigin(3)`: it uses Minecraft's `ServerPlayer` (io/github/apace100/origins/networking/ModPacketsC2S.java:189)

### `ModPacketsS2C`

- [ ] `ModPacketsS2C.register(0)`: a method reference (io/github/apace100/origins/networking/ModPacketsS2C.java:38)
- [ ] `ModPacketsS2C.receiveOriginConfirmation(2)`: it uses ConfirmOriginPacket, which isn't translated (it implements Minecraft's `CustomPacketPayload`) (io/github/apace100/origins/networking/ModPacketsS2C.java:55)
- [ ] `ModPacketsS2C.handleHandshake(4)`: it uses Minecraft's `FriendlyByteBuf` (io/github/apace100/origins/networking/ModPacketsS2C.java:68)
- [ ] `ModPacketsS2C.openOriginScreen(2)`: it uses OpenOriginScreenPacket, which isn't translated (it implements Minecraft's `CustomPacketPayload`) (io/github/apace100/origins/networking/ModPacketsS2C.java:86)
- [ ] `ModPacketsS2C.receiveOriginList(2)`: it uses OriginListPacket, which isn't translated (it implements Minecraft's `CustomPacketPayload`) (io/github/apace100/origins/networking/ModPacketsS2C.java:102)
- [ ] `ModPacketsS2C.receiveLayerList(2)`: it uses LayerListPacket, which isn't translated (it implements Minecraft's `CustomPacketPayload`) (io/github/apace100/origins/networking/ModPacketsS2C.java:115)
- [ ] `ModPacketsS2C.receiveBadgeList(2)`: it uses BadgeListPacket, which isn't translated (it implements Minecraft's `CustomPacketPayload`) (io/github/apace100/origins/networking/ModPacketsS2C.java:128)

### `OpenOriginScreenPacket`: it implements Minecraft's `CustomPacketPayload`

- [ ] `OpenOriginScreenPacket.CODEC`: it uses Minecraft's `StreamCodec` (io/github/apace100/origins/networking/OpenOriginScreenPacket.java:10)
- [ ] `OpenOriginScreenPacket.OpenOriginScreenPacket(1)`: its class isn't translated (it implements Minecraft's `CustomPacketPayload`) (io/github/apace100/origins/networking/OpenOriginScreenPacket.java:9)
- [ ] `OpenOriginScreenPacket.type(0)`: its class isn't translated (it implements Minecraft's `CustomPacketPayload`) (io/github/apace100/origins/networking/OpenOriginScreenPacket.java:14)
- [ ] `OpenOriginScreenPacket.showDirtBackground(0)`: its class isn't translated (it implements Minecraft's `CustomPacketPayload`) (io/github/apace100/origins/networking/OpenOriginScreenPacket.java:9)

### `OriginListPacket`: it implements Minecraft's `CustomPacketPayload`

- [ ] `OriginListPacket.CODEC`: it uses Minecraft's `StreamCodec` (io/github/apace100/origins/networking/OriginListPacket.java:15)
- [ ] `OriginListPacket.OriginListPacket(1)`: its class isn't translated (it implements Minecraft's `CustomPacketPayload`) (io/github/apace100/origins/networking/OriginListPacket.java:14)
- [ ] `OriginListPacket.fromOriginsMap(1)`: it uses OriginListPacket, which isn't translated (it implements Minecraft's `CustomPacketPayload`) (io/github/apace100/origins/networking/OriginListPacket.java:19)
- [ ] `OriginListPacket.type(0)`: its class isn't translated (it implements Minecraft's `CustomPacketPayload`) (io/github/apace100/origins/networking/OriginListPacket.java:41)
- [ ] `OriginListPacket.origins(0)`: its class isn't translated (it implements Minecraft's `CustomPacketPayload`) (io/github/apace100/origins/networking/OriginListPacket.java:14)

### `PowersAndOriginsPacket`: it implements Minecraft's `CustomPacketPayload`

- [ ] `PowersAndOriginsPacket.CODEC`: it uses Minecraft's `StreamCodec` (io/github/apace100/origins/networking/PowersAndOriginsPacket.java:10)
- [ ] `PowersAndOriginsPacket.PowersAndOriginsPacket(2)`: its class isn't translated (it implements Minecraft's `CustomPacketPayload`) (io/github/apace100/origins/networking/PowersAndOriginsPacket.java:9)
- [ ] `PowersAndOriginsPacket.type(0)`: its class isn't translated (it implements Minecraft's `CustomPacketPayload`) (io/github/apace100/origins/networking/PowersAndOriginsPacket.java:14)
- [ ] `PowersAndOriginsPacket.powers(0)`: its class isn't translated (it implements Minecraft's `CustomPacketPayload`) (io/github/apace100/origins/networking/PowersAndOriginsPacket.java:9)
- [ ] `PowersAndOriginsPacket.origins(0)`: its class isn't translated (it implements Minecraft's `CustomPacketPayload`) (io/github/apace100/origins/networking/PowersAndOriginsPacket.java:9)

### `Origins`: it implements Fabric's `ModInitializer`

- [x] `Origins.MODID` (io/github/apace100/origins/Origins.java:52)
- [x] `Origins.LEGACY_MODID` (io/github/apace100/origins/Origins.java:53)
- [x] `Origins.VERSION` (io/github/apace100/origins/Origins.java:54)
- [x] `Origins.SEMVER` (io/github/apace100/origins/Origins.java:55)
- [x] `Origins.LOGGER` (io/github/apace100/origins/Origins.java:56)
- [ ] `Origins.config`: it uses ServerConfig, which isn't translated (it implements `ConfigData` (me.shedaniel.autoconfig)) (io/github/apace100/origins/Origins.java:57)
- [ ] `Origins.configSerializer`: it uses `ConfigSerializer` (me.shedaniel.autoconfig.serializer) (io/github/apace100/origins/Origins.java:58)
- [ ] `Origins.onInitialize(0)`: its class isn't translated (it implements Fabric's `ModInitializer`) (io/github/apace100/origins/Origins.java:60)
- [ ] `Origins.serializeConfig(0)`: a try/catch (SerializationException) (io/github/apace100/origins/Origins.java:113)
- [x] `Origins.identifier(1)` (io/github/apace100/origins/Origins.java:121)
- [x] `Origins.legacy(1)` (io/github/apace100/origins/Origins.java:125)
- [ ] `Origins.registerResourceListeners(1)`: its class isn't translated (it implements Fabric's `ModInitializer`) (io/github/apace100/origins/Origins.java:129)

### `Origins.ServerConfig`: it implements `ConfigData` (me.shedaniel.autoconfig)

- [ ] `Origins.ServerConfig.isOriginDisabled(1)`: its class isn't translated (it implements `ConfigData` (me.shedaniel.autoconfig)) (io/github/apace100/origins/Origins.java:150)
- [ ] `Origins.ServerConfig.isPowerDisabled(2)`: its class isn't translated (it implements `ConfigData` (me.shedaniel.autoconfig)) (io/github/apace100/origins/Origins.java:159)
- [ ] `Origins.ServerConfig.addToConfig(1)`: its class isn't translated (it implements `ConfigData` (me.shedaniel.autoconfig)) (io/github/apace100/origins/Origins.java:169)

### `OriginsClient`: it implements Fabric's `ClientModInitializer`

- [ ] `OriginsClient.ORIGINS_CATEGORY`: done another way in Horizon: the mod's keys in Options > Mods, read through Horizon's key hook (io/github/apace100/origins/OriginsClient.java:24)
- [ ] `OriginsClient.usePrimaryActivePowerKeybind`: done another way in Horizon: the mod's keys in Options > Mods, read through Horizon's key hook (io/github/apace100/origins/OriginsClient.java:25)
- [ ] `OriginsClient.useSecondaryActivePowerKeybind`: done another way in Horizon: the mod's keys in Options > Mods, read through Horizon's key hook (io/github/apace100/origins/OriginsClient.java:26)
- [ ] `OriginsClient.viewCurrentOriginKeybind`: done another way in Horizon: the mod's keys in Options > Mods, read through Horizon's key hook (io/github/apace100/origins/OriginsClient.java:27)
- [x] `OriginsClient.isServerRunningOrigins` (io/github/apace100/origins/OriginsClient.java:28)
- [ ] `OriginsClient.onInitializeClient(0)`: done another way in Horizon: it runs as `on_init`, from Horizon's init hook (io/github/apace100/origins/OriginsClient.java:30)

### `Impact`: its constants carry values

- [ ] `Impact.STREAM_CODEC`: it uses Minecraft's `StreamCodec` (io/github/apace100/origins/origin/Impact.java:18)
- [ ] `Impact.Impact(3)`: its class isn't translated (its constants carry values) (io/github/apace100/origins/origin/Impact.java:25)
- [ ] `Impact.getImpactValue(0)`: its class isn't translated (its constants carry values) (io/github/apace100/origins/origin/Impact.java:31)
- [ ] `Impact.getTranslationKey(0)`: its class isn't translated (its constants carry values) (io/github/apace100/origins/origin/Impact.java:35)
- [ ] `Impact.getTextStyle(0)`: its class isn't translated (its constants carry values) (io/github/apace100/origins/origin/Impact.java:39)
- [ ] `Impact.getTextComponent(0)`: its class isn't translated (its constants carry values) (io/github/apace100/origins/origin/Impact.java:43)
- [ ] `Impact.getByValue(1)`: it uses Impact, which isn't translated (its constants carry values) (io/github/apace100/origins/origin/Impact.java:47)

### `Origin`: it uses `PowerType` (io.github.apace100.apoli.power)

- [ ] `Origin.STREAM_CODEC`: it uses Minecraft's `StreamCodec` (io/github/apace100/origins/origin/Origin.java:42)
- [ ] `Origin.DATA`: it uses `SerializableData` (io.github.apace100.calio.data) (io/github/apace100/origins/origin/Origin.java:65)
- [ ] `Origin.EMPTY`: it uses Origin, which isn't translated (it uses `PowerType` (io.github.apace100.apoli.power)) (io/github/apace100/origins/origin/Origin.java:75)
- [x] `Origin.init(0)` (io/github/apace100/origins/origin/Origin.java:92)
- [ ] `Origin.register(1)`: it uses Origin, which isn't translated (it uses `PowerType` (io.github.apace100.apoli.power)) (io/github/apace100/origins/origin/Origin.java:95)
- [ ] `Origin.get(1)`: it uses OriginLayer, which isn't translated (it implements `Comparable`) (io/github/apace100/origins/origin/Origin.java:99)
- [ ] `Origin.get(1)`: it uses OriginLayer, which isn't translated (it implements `Comparable`) (io/github/apace100/origins/origin/Origin.java:103)
- [ ] `Origin.Origin(5)`: its class isn't translated (it uses `PowerType` (io.github.apace100.apoli.power)) (io/github/apace100/origins/origin/Origin.java:107)
- [ ] `Origin.Origin(5)`: its class isn't translated (it uses `PowerType` (io.github.apace100.apoli.power)) (io/github/apace100/origins/origin/Origin.java:111)
- [ ] `Origin.Origin(10)`: its class isn't translated (it uses `PowerType` (io.github.apace100.apoli.power)) (io/github/apace100/origins/origin/Origin.java:120)
- [ ] `Origin.Origin(10)`: its class isn't translated (it uses `PowerType` (io.github.apace100.apoli.power)) (io/github/apace100/origins/origin/Origin.java:135)
- [ ] `Origin.addUpgrade(1)`: its class isn't translated (it uses `PowerType` (io.github.apace100.apoli.power)) (io/github/apace100/origins/origin/Origin.java:162)
- [ ] `Origin.hasUpgrade(0)`: its class isn't translated (it uses `PowerType` (io.github.apace100.apoli.power)) (io/github/apace100/origins/origin/Origin.java:167)
- [ ] `Origin.getUpgrade(1)`: its class isn't translated (it uses `PowerType` (io.github.apace100.apoli.power)) (io/github/apace100/origins/origin/Origin.java:171)
- [ ] `Origin.getIdentifier(0)`: its class isn't translated (it uses `PowerType` (io.github.apace100.apoli.power)) (io/github/apace100/origins/origin/Origin.java:181)
- [ ] `Origin.add(1)`: its class isn't translated (it uses `PowerType` (io.github.apace100.apoli.power)) (io/github/apace100/origins/origin/Origin.java:185)
- [ ] `Origin.removePowerType(1)`: its class isn't translated (it uses `PowerType` (io.github.apace100.apoli.power)) (io/github/apace100/origins/origin/Origin.java:190)
- [ ] `Origin.setUnchoosable(0)`: its class isn't translated (it uses `PowerType` (io.github.apace100.apoli.power)) (io/github/apace100/origins/origin/Origin.java:194)
- [ ] `Origin.setSpecial(0)`: its class isn't translated (it uses `PowerType` (io.github.apace100.apoli.power)) (io/github/apace100/origins/origin/Origin.java:199)
- [ ] `Origin.setName(1)`: its class isn't translated (it uses `PowerType` (io.github.apace100.apoli.power)) (io/github/apace100/origins/origin/Origin.java:204)
- [ ] `Origin.setDescription(1)`: its class isn't translated (it uses `PowerType` (io.github.apace100.apoli.power)) (io/github/apace100/origins/origin/Origin.java:209)
- [ ] `Origin.hasPowerType(1)`: its class isn't translated (it uses `PowerType` (io.github.apace100.apoli.power)) (io/github/apace100/origins/origin/Origin.java:214)
- [ ] `Origin.getLoadingPriority(0)`: its class isn't translated (it uses `PowerType` (io.github.apace100.apoli.power)) (io/github/apace100/origins/origin/Origin.java:232)
- [ ] `Origin.isSpecial(0)`: its class isn't translated (it uses `PowerType` (io.github.apace100.apoli.power)) (io/github/apace100/origins/origin/Origin.java:236)
- [ ] `Origin.isChoosable(0)`: its class isn't translated (it uses `PowerType` (io.github.apace100.apoli.power)) (io/github/apace100/origins/origin/Origin.java:240)
- [ ] `Origin.getPowerTypes(0)`: its class isn't translated (it uses `PowerType` (io.github.apace100.apoli.power)) (io/github/apace100/origins/origin/Origin.java:244)
- [ ] `Origin.getPowerIds(0)`: its class isn't translated (it uses `PowerType` (io.github.apace100.apoli.power)) (io/github/apace100/origins/origin/Origin.java:248)
- [ ] `Origin.getUpgrades(0)`: its class isn't translated (it uses `PowerType` (io.github.apace100.apoli.power)) (io/github/apace100/origins/origin/Origin.java:252)
- [ ] `Origin.getImpact(0)`: its class isn't translated (it uses `PowerType` (io.github.apace100.apoli.power)) (io/github/apace100/origins/origin/Origin.java:256)
- [ ] `Origin.getDisplayItem(0)`: its class isn't translated (it uses `PowerType` (io.github.apace100.apoli.power)) (io/github/apace100/origins/origin/Origin.java:260)
- [ ] `Origin.getOrCreateNameTranslationKey(0)`: its class isn't translated (it uses `PowerType` (io.github.apace100.apoli.power)) (io/github/apace100/origins/origin/Origin.java:264)
- [ ] `Origin.getName(0)`: its class isn't translated (it uses `PowerType` (io.github.apace100.apoli.power)) (io/github/apace100/origins/origin/Origin.java:272)
- [ ] `Origin.getOrCreateDescriptionTranslationKey(0)`: its class isn't translated (it uses `PowerType` (io.github.apace100.apoli.power)) (io/github/apace100/origins/origin/Origin.java:276)
- [ ] `Origin.getDescription(0)`: its class isn't translated (it uses `PowerType` (io.github.apace100.apoli.power)) (io/github/apace100/origins/origin/Origin.java:284)
- [ ] `Origin.getOrder(0)`: its class isn't translated (it uses `PowerType` (io.github.apace100.apoli.power)) (io/github/apace100/origins/origin/Origin.java:288)
- [ ] `Origin.write(1)`: its class isn't translated (it uses `PowerType` (io.github.apace100.apoli.power)) (io/github/apace100/origins/origin/Origin.java:292)
- [ ] `Origin.createFromData(2)`: it uses Origin, which isn't translated (it uses `PowerType` (io.github.apace100.apoli.power)) (io/github/apace100/origins/origin/Origin.java:308)
- [ ] `Origin.read(1)`: it uses Origin, which isn't translated (it uses `PowerType` (io.github.apace100.apoli.power)) (io/github/apace100/origins/origin/Origin.java:331)
- [ ] `Origin.fromJson(3)`: it uses Origin, which isn't translated (it uses `PowerType` (io.github.apace100.apoli.power)) (io/github/apace100/origins/origin/Origin.java:337)
- [ ] `Origin.toString(0)`: its class isn't translated (it uses `PowerType` (io.github.apace100.apoli.power)) (io/github/apace100/origins/origin/Origin.java:341)
- [ ] `Origin.hashCode(0)`: its class isn't translated (it uses `PowerType` (io.github.apace100.apoli.power)) (io/github/apace100/origins/origin/Origin.java:353)
- [ ] `Origin.equals(1)`: its class isn't translated (it uses `PowerType` (io.github.apace100.apoli.power)) (io/github/apace100/origins/origin/Origin.java:358)

### `OriginHolder`: it uses Minecraft's `ItemStack`

- [ ] `OriginHolder.STREAM_CODEC`: it uses Minecraft's `StreamCodec` (io/github/apace100/origins/origin/OriginHolder.java:24)
- [ ] `OriginHolder.OriginHolder(10)`: its class isn't translated (it uses Minecraft's `ItemStack`) (io/github/apace100/origins/origin/OriginHolder.java:12)
- [ ] `OriginHolder.asOrigin(0)`: its class isn't translated (it uses Minecraft's `ItemStack`) (io/github/apace100/origins/origin/OriginHolder.java:48)
- [ ] `OriginHolder.id(0)`: its class isn't translated (it uses Minecraft's `ItemStack`) (io/github/apace100/origins/origin/OriginHolder.java:12)
- [ ] `OriginHolder.icon(0)`: its class isn't translated (it uses Minecraft's `ItemStack`) (io/github/apace100/origins/origin/OriginHolder.java:12)
- [ ] `OriginHolder.impact(0)`: its class isn't translated (it uses Minecraft's `ItemStack`) (io/github/apace100/origins/origin/OriginHolder.java:12)
- [ ] `OriginHolder.order(0)`: its class isn't translated (it uses Minecraft's `ItemStack`) (io/github/apace100/origins/origin/OriginHolder.java:12)
- [ ] `OriginHolder.loadingPriority(0)`: its class isn't translated (it uses Minecraft's `ItemStack`) (io/github/apace100/origins/origin/OriginHolder.java:12)
- [ ] `OriginHolder.choosable(0)`: its class isn't translated (it uses Minecraft's `ItemStack`) (io/github/apace100/origins/origin/OriginHolder.java:12)
- [ ] `OriginHolder.powerIds(0)`: its class isn't translated (it uses Minecraft's `ItemStack`) (io/github/apace100/origins/origin/OriginHolder.java:12)
- [ ] `OriginHolder.name(0)`: its class isn't translated (it uses Minecraft's `ItemStack`) (io/github/apace100/origins/origin/OriginHolder.java:12)
- [ ] `OriginHolder.description(0)`: its class isn't translated (it uses Minecraft's `ItemStack`) (io/github/apace100/origins/origin/OriginHolder.java:12)
- [ ] `OriginHolder.upgrades(0)`: its class isn't translated (it uses Minecraft's `ItemStack`) (io/github/apace100/origins/origin/OriginHolder.java:12)

### `OriginLayer`: it implements `Comparable`

- [ ] `OriginLayer.STREAM_CODEC`: it uses Minecraft's `StreamCodec` (io/github/apace100/origins/origin/OriginLayer.java:30)
- [ ] `OriginLayer.getOrCreateTranslationKey(0)`: its class isn't translated (it implements `Comparable`) (io/github/apace100/origins/origin/OriginLayer.java:49)
- [ ] `OriginLayer.getTranslationKey(0)`: its class isn't translated (it implements `Comparable`) (io/github/apace100/origins/origin/OriginLayer.java:57)
- [ ] `OriginLayer.getMissingOriginNameTranslationKey(0)`: its class isn't translated (it implements `Comparable`) (io/github/apace100/origins/origin/OriginLayer.java:61)
- [ ] `OriginLayer.getTitleViewOriginTranslationKey(0)`: its class isn't translated (it implements `Comparable`) (io/github/apace100/origins/origin/OriginLayer.java:69)
- [ ] `OriginLayer.shouldOverrideViewOriginTitle(0)`: its class isn't translated (it implements `Comparable`) (io/github/apace100/origins/origin/OriginLayer.java:77)
- [ ] `OriginLayer.getTitleChooseOriginTranslationKey(0)`: its class isn't translated (it implements `Comparable`) (io/github/apace100/origins/origin/OriginLayer.java:81)
- [ ] `OriginLayer.shouldOverrideChooseOriginTitle(0)`: its class isn't translated (it implements `Comparable`) (io/github/apace100/origins/origin/OriginLayer.java:89)
- [ ] `OriginLayer.getMissingOriginDescriptionTranslationKey(0)`: its class isn't translated (it implements `Comparable`) (io/github/apace100/origins/origin/OriginLayer.java:93)
- [ ] `OriginLayer.getIdentifier(0)`: its class isn't translated (it implements `Comparable`) (io/github/apace100/origins/origin/OriginLayer.java:105)
- [ ] `OriginLayer.isEnabled(0)`: its class isn't translated (it implements `Comparable`) (io/github/apace100/origins/origin/OriginLayer.java:109)
- [ ] `OriginLayer.hasDefaultOrigin(0)`: its class isn't translated (it implements `Comparable`) (io/github/apace100/origins/origin/OriginLayer.java:113)
- [ ] `OriginLayer.getDefaultOrigin(0)`: its class isn't translated (it implements `Comparable`) (io/github/apace100/origins/origin/OriginLayer.java:117)
- [ ] `OriginLayer.shouldAutoChoose(0)`: its class isn't translated (it implements `Comparable`) (io/github/apace100/origins/origin/OriginLayer.java:121)
- [ ] `OriginLayer.getOrigins(0)`: its class isn't translated (it implements `Comparable`) (io/github/apace100/origins/origin/OriginLayer.java:125)
- [ ] `OriginLayer.getOrigins(1)`: its class isn't translated (it implements `Comparable`) (io/github/apace100/origins/origin/OriginLayer.java:129)
- [ ] `OriginLayer.getOriginOptionCount(1)`: its class isn't translated (it implements `Comparable`) (io/github/apace100/origins/origin/OriginLayer.java:138)
- [ ] `OriginLayer.contains(1)`: its class isn't translated (it implements `Comparable`) (io/github/apace100/origins/origin/OriginLayer.java:147)
- [ ] `OriginLayer.contains(2)`: its class isn't translated (it implements `Comparable`) (io/github/apace100/origins/origin/OriginLayer.java:151)
- [ ] `OriginLayer.isRandomAllowed(0)`: its class isn't translated (it implements `Comparable`) (io/github/apace100/origins/origin/OriginLayer.java:158)
- [ ] `OriginLayer.isHidden(0)`: its class isn't translated (it implements `Comparable`) (io/github/apace100/origins/origin/OriginLayer.java:162)
- [ ] `OriginLayer.getRandomOrigins(1)`: its class isn't translated (it implements `Comparable`) (io/github/apace100/origins/origin/OriginLayer.java:166)
- [ ] `OriginLayer.merge(2)`: its class isn't translated (it implements `Comparable`) (io/github/apace100/origins/origin/OriginLayer.java:177)
- [ ] `OriginLayer.hashCode(0)`: its class isn't translated (it implements `Comparable`) (io/github/apace100/origins/origin/OriginLayer.java:247)
- [ ] `OriginLayer.equals(1)`: its class isn't translated (it implements `Comparable`) (io/github/apace100/origins/origin/OriginLayer.java:252)
- [ ] `OriginLayer.compareTo(1)`: its class isn't translated (it implements `Comparable`) (io/github/apace100/origins/origin/OriginLayer.java:261)
- [ ] `OriginLayer.write(1)`: its class isn't translated (it implements `Comparable`) (io/github/apace100/origins/origin/OriginLayer.java:265)
- [ ] `OriginLayer.read(1)`: it uses OriginLayer, which isn't translated (it implements `Comparable`) (io/github/apace100/origins/origin/OriginLayer.java:294)
- [ ] `OriginLayer.fromJson(3)`: it uses OriginLayer, which isn't translated (it implements `Comparable`) (io/github/apace100/origins/origin/OriginLayer.java:333)

### `OriginLayer.ConditionedOrigin`: it uses `Instance` (io.github.apace100.calio.data.SerializableData)

- [ ] `OriginLayer.ConditionedOrigin.conditionedOriginObjectData`: it uses `SerializableData` (io.github.apace100.calio.data) (io/github/apace100/origins/origin/OriginLayer.java:384)
- [ ] `OriginLayer.ConditionedOrigin.ConditionedOrigin(2)`: its class isn't translated (it uses `Instance` (io.github.apace100.calio.data.SerializableData)) (io/github/apace100/origins/origin/OriginLayer.java:388)
- [ ] `OriginLayer.ConditionedOrigin.isConditionFulfilled(1)`: its class isn't translated (it uses `Instance` (io.github.apace100.calio.data.SerializableData)) (io/github/apace100/origins/origin/OriginLayer.java:393)
- [ ] `OriginLayer.ConditionedOrigin.getOrigins(0)`: its class isn't translated (it uses `Instance` (io.github.apace100.calio.data.SerializableData)) (io/github/apace100/origins/origin/OriginLayer.java:397)
- [ ] `OriginLayer.ConditionedOrigin.write(1)`: its class isn't translated (it uses `Instance` (io.github.apace100.calio.data.SerializableData)) (io/github/apace100/origins/origin/OriginLayer.java:401)
- [ ] `OriginLayer.ConditionedOrigin.read(1)`: it uses ConditionedOrigin, which isn't translated (it uses `Instance` (io.github.apace100.calio.data.SerializableData)) (io/github/apace100/origins/origin/OriginLayer.java:411)
- [ ] `OriginLayer.ConditionedOrigin.read(2)`: it uses ConditionedOrigin, which isn't translated (it uses `Instance` (io.github.apace100.calio.data.SerializableData)) (io/github/apace100/origins/origin/OriginLayer.java:428)

### `OriginLayers`: it extends `MultiJsonDataLoader` (io.github.apace100.calio.data)

- [ ] `OriginLayers.layers`: it uses OriginLayer, which isn't translated (it implements `Comparable`) (io/github/apace100/origins/origin/OriginLayers.java:27)
- [x] `OriginLayers.minLayerPriority` (io/github/apace100/origins/origin/OriginLayers.java:28)
- [x] `OriginLayers.GSON` (io/github/apace100/origins/origin/OriginLayers.java:29)
- [ ] `OriginLayers.OriginLayers(0)`: its class isn't translated (it extends `MultiJsonDataLoader` (io.github.apace100.calio.data)) (io/github/apace100/origins/origin/OriginLayers.java:32)
- [ ] `OriginLayers.prepareSharedState(1)`: its class isn't translated (it extends `MultiJsonDataLoader` (io.github.apace100.calio.data)) (io/github/apace100/origins/origin/OriginLayers.java:36)
- [ ] `OriginLayers.apply(3)`: its class isn't translated (it extends `MultiJsonDataLoader` (io.github.apace100.calio.data)) (io/github/apace100/origins/origin/OriginLayers.java:41)
- [ ] `OriginLayers.getLayer(1)`: it uses OriginLayer, which isn't translated (it implements `Comparable`) (io/github/apace100/origins/origin/OriginLayers.java:90)
- [ ] `OriginLayers.getLayers(0)`: it uses OriginLayer, which isn't translated (it implements `Comparable`) (io/github/apace100/origins/origin/OriginLayers.java:98)
- [ ] `OriginLayers.size(0)`: it uses OriginLayers.layers, which isn't translated (it uses OriginLayer, which isn't translated (it implements `Comparable`)) (io/github/apace100/origins/origin/OriginLayers.java:102)
- [ ] `OriginLayers.clear(0)`: it uses OriginLayers.layers, which isn't translated (it uses OriginLayer, which isn't translated (it implements `Comparable`)) (io/github/apace100/origins/origin/OriginLayers.java:106)
- [ ] `OriginLayers.add(1)`: it uses OriginLayer, which isn't translated (it implements `Comparable`) (io/github/apace100/origins/origin/OriginLayers.java:110)

### `OriginManager`: it extends `MultiJsonDataLoader` (io.github.apace100.calio.data)

- [x] `OriginManager.GSON` (io/github/apace100/origins/origin/OriginManager.java:22)
- [ ] `OriginManager.OriginManager(0)`: its class isn't translated (it extends `MultiJsonDataLoader` (io.github.apace100.calio.data)) (io/github/apace100/origins/origin/OriginManager.java:25)
- [ ] `OriginManager.prepareSharedState(1)`: its class isn't translated (it extends `MultiJsonDataLoader` (io.github.apace100.calio.data)) (io/github/apace100/origins/origin/OriginManager.java:29)
- [ ] `OriginManager.apply(3)`: its class isn't translated (it extends `MultiJsonDataLoader` (io.github.apace100.calio.data)) (io/github/apace100/origins/origin/OriginManager.java:34)

### `OriginRegistry`

- [ ] `OriginRegistry.idToOrigin`: it uses Origin, which isn't translated (it uses `PowerType` (io.github.apace100.apoli.power)) (io/github/apace100/origins/origin/OriginRegistry.java:10)
- [ ] `OriginRegistry.register(1)`: it uses Origin, which isn't translated (it uses `PowerType` (io.github.apace100.apoli.power)) (io/github/apace100/origins/origin/OriginRegistry.java:12)
- [ ] `OriginRegistry.register(2)`: it uses Origin, which isn't translated (it uses `PowerType` (io.github.apace100.apoli.power)) (io/github/apace100/origins/origin/OriginRegistry.java:16)
- [ ] `OriginRegistry.register(2)`: it uses Origin, which isn't translated (it uses `PowerType` (io.github.apace100.apoli.power)) (io/github/apace100/origins/origin/OriginRegistry.java:20)
- [ ] `OriginRegistry.update(2)`: it uses Origin, which isn't translated (it uses `PowerType` (io.github.apace100.apoli.power)) (io/github/apace100/origins/origin/OriginRegistry.java:29)
- [ ] `OriginRegistry.size(0)`: it uses OriginRegistry.idToOrigin, which isn't translated (it uses Origin, which isn't translated (it uses `PowerType` (io.github.apace100.apoli.power))) (io/github/apace100/origins/origin/OriginRegistry.java:38)
- [ ] `OriginRegistry.identifiers(0)`: it uses `Stream` (java.util.stream) (io/github/apace100/origins/origin/OriginRegistry.java:42)
- [ ] `OriginRegistry.entries(0)`: it uses Origin, which isn't translated (it uses `PowerType` (io.github.apace100.apoli.power)) (io/github/apace100/origins/origin/OriginRegistry.java:46)
- [ ] `OriginRegistry.values(0)`: it uses Origin, which isn't translated (it uses `PowerType` (io.github.apace100.apoli.power)) (io/github/apace100/origins/origin/OriginRegistry.java:50)
- [ ] `OriginRegistry.get(0)`: it uses Origin, which isn't translated (it uses `PowerType` (io.github.apace100.apoli.power)) (io/github/apace100/origins/origin/OriginRegistry.java:54)
- [ ] `OriginRegistry.get(1)`: it uses Origin, which isn't translated (it uses `PowerType` (io.github.apace100.apoli.power)) (io/github/apace100/origins/origin/OriginRegistry.java:58)
- [ ] `OriginRegistry.contains(1)`: it's overloaded with the same number of parameters (io/github/apace100/origins/origin/OriginRegistry.java:66)
- [ ] `OriginRegistry.contains(1)`: it's overloaded with the same number of parameters (io/github/apace100/origins/origin/OriginRegistry.java:70)
- [ ] `OriginRegistry.clear(0)`: it uses OriginRegistry.idToOrigin, which isn't translated (it uses Origin, which isn't translated (it uses `PowerType` (io.github.apace100.apoli.power))) (io/github/apace100/origins/origin/OriginRegistry.java:74)
- [ ] `OriginRegistry.reset(0)`: it calls OriginRegistry.clear, which isn't translated (io/github/apace100/origins/origin/OriginRegistry.java:78)
- [ ] `OriginRegistry.remove(1)`: it uses OriginRegistry.idToOrigin, which isn't translated (it uses Origin, which isn't translated (it uses `PowerType` (io.github.apace100.apoli.power))) (io/github/apace100/origins/origin/OriginRegistry.java:83)

### `OriginUpgrade`

- [x] `OriginUpgrade.OriginUpgrade(3)` (io/github/apace100/origins/origin/OriginUpgrade.java:14)
- [x] `OriginUpgrade.getAdvancementCondition(0)` (io/github/apace100/origins/origin/OriginUpgrade.java:20)
- [x] `OriginUpgrade.getUpgradeToOrigin(0)` (io/github/apace100/origins/origin/OriginUpgrade.java:24)
- [x] `OriginUpgrade.getAnnouncement(0)` (io/github/apace100/origins/origin/OriginUpgrade.java:28)
- [ ] `OriginUpgrade.write(1)`: it uses Minecraft's `FriendlyByteBuf` (io/github/apace100/origins/origin/OriginUpgrade.java:32)
- [ ] `OriginUpgrade.read(1)`: it uses Minecraft's `FriendlyByteBuf` (io/github/apace100/origins/origin/OriginUpgrade.java:38)
- [ ] `OriginUpgrade.fromJson(1)`: an assignment inside an expression (io/github/apace100/origins/origin/OriginUpgrade.java:45)

### `OriginsCallbackPower`: it extends `ActionOnCallbackPower` (io.github.apace100.apoli.power)

- [ ] `OriginsCallbackPower.OriginsCallbackPower(9)`: its class isn't translated (it extends `ActionOnCallbackPower` (io.github.apace100.apoli.power)) (io/github/apace100/origins/power/OriginsCallbackPower.java:13)
- [ ] `OriginsCallbackPower.onChosen(1)`: its class isn't translated (it extends `ActionOnCallbackPower` (io.github.apace100.apoli.power)) (io/github/apace100/origins/power/OriginsCallbackPower.java:29)

### `OriginsEntityConditions`

- [ ] `OriginsEntityConditions.register(0)`: it uses `ConditionFactory` (io.github.apace100.apoli.power.factory.condition) (io/github/apace100/origins/power/OriginsEntityConditions.java:19)
- [ ] `OriginsEntityConditions.register(1)`: it uses `ConditionFactory` (io.github.apace100.apoli.power.factory.condition) (io/github/apace100/origins/power/OriginsEntityConditions.java:48)

### `OriginsPowerTypes`

- [ ] `OriginsPowerTypes.LIKE_WATER`: it uses `PowerType` (io.github.apace100.apoli.power) (io/github/apace100/origins/power/OriginsPowerTypes.java:15)
- [ ] `OriginsPowerTypes.WATER_BREATHING`: it uses `PowerType` (io.github.apace100.apoli.power) (io/github/apace100/origins/power/OriginsPowerTypes.java:16)
- [ ] `OriginsPowerTypes.SCARE_CREEPERS`: it uses `PowerType` (io.github.apace100.apoli.power) (io/github/apace100/origins/power/OriginsPowerTypes.java:17)
- [ ] `OriginsPowerTypes.WATER_VISION`: it uses `PowerType` (io.github.apace100.apoli.power) (io/github/apace100/origins/power/OriginsPowerTypes.java:18)
- [ ] `OriginsPowerTypes.NO_COBWEB_SLOWDOWN`: it uses `PowerType` (io.github.apace100.apoli.power) (io/github/apace100/origins/power/OriginsPowerTypes.java:19)
- [ ] `OriginsPowerTypes.MASTER_OF_WEBS_NO_SLOWDOWN`: it uses `PowerType` (io.github.apace100.apoli.power) (io/github/apace100/origins/power/OriginsPowerTypes.java:20)
- [ ] `OriginsPowerTypes.CONDUIT_POWER_ON_LAND`: it uses `PowerType` (io.github.apace100.apoli.power) (io/github/apace100/origins/power/OriginsPowerTypes.java:21)
- [ ] `OriginsPowerTypes.register(0)`: it uses `PowerFactory` (io.github.apace100.apoli.power.factory) (io/github/apace100/origins/power/OriginsPowerTypes.java:23)
- [ ] `OriginsPowerTypes.register(1)`: it uses `PowerFactory` (io.github.apace100.apoli.power.factory) (io/github/apace100/origins/power/OriginsPowerTypes.java:51)

### `ModBlocks`

- [ ] `ModBlocks.TEMPORARY_COBWEB`: it uses Minecraft's `Block` (io/github/apace100/origins/registry/ModBlocks.java:16)
- [ ] `ModBlocks.register(0)`: it calls ModBlocks.register, which isn't translated (io/github/apace100/origins/registry/ModBlocks.java:26)
- [ ] `ModBlocks.register(2)`: it uses Minecraft's `Block` (io/github/apace100/origins/registry/ModBlocks.java:30)
- [ ] `ModBlocks.register(3)`: it uses Minecraft's `Block` (io/github/apace100/origins/registry/ModBlocks.java:34)

### `ModComponents`: it implements `EntityComponentInitializer` (org.ladysnake.cca.api.v3.entity)

- [ ] `ModComponents.ORIGIN`: it uses `ComponentKey` (org.ladysnake.cca.api.v3.component) (io/github/apace100/origins/registry/ModComponents.java:15)
- [ ] `ModComponents.registerEntityComponentFactories(1)`: its class isn't translated (it implements `EntityComponentInitializer` (org.ladysnake.cca.api.v3.entity)) (io/github/apace100/origins/registry/ModComponents.java:19)

### `ModDamageSources`

- [ ] `ModDamageSources.NO_WATER_FOR_GILLS`: it uses Minecraft's `ResourceKey` (io/github/apace100/origins/registry/ModDamageSources.java:11)
- [ ] `ModDamageSources.getSource(2)`: it uses Minecraft's `DamageSource` (io/github/apace100/origins/registry/ModDamageSources.java:13)

### `ModEnchantments`

- [ ] `ModEnchantments.WATER_PROTECTION`: it uses Minecraft's `ResourceKey` (io/github/apace100/origins/registry/ModEnchantments.java:9)
- [x] `ModEnchantments.register(0)` (io/github/apace100/origins/registry/ModEnchantments.java:11)

### `ModEntities`

- [ ] `ModEntities.ENDERIAN_PEARL`: it uses Minecraft's `EntityType` (io/github/apace100/origins/registry/ModEntities.java:14)
- [x] `ModEntities.register(0)` (io/github/apace100/origins/registry/ModEntities.java:24)

### `ModItems`

- [ ] `ModItems.ORB_OF_ORIGIN`: it uses Minecraft's `Item` (io/github/apace100/origins/registry/ModItems.java:10)
- [ ] `ModItems.register(0)`: it uses Minecraft's `BuiltInRegistries`.ITEM (io/github/apace100/origins/registry/ModItems.java:12)

### `ModLoot`

- [x] `ModLoot.DUNGEON_LOOT` (io/github/apace100/origins/registry/ModLoot.java:22)
- [x] `ModLoot.STRONGHOLD_LIBRARY` (io/github/apace100/origins/registry/ModLoot.java:23)
- [x] `ModLoot.MINESHAFT` (io/github/apace100/origins/registry/ModLoot.java:24)
- [x] `ModLoot.WATER_RUIN` (io/github/apace100/origins/registry/ModLoot.java:25)
- [ ] `ModLoot.ORIGIN_LOOT_CONDITION`: it uses Minecraft's `MapCodec` (io/github/apace100/origins/registry/ModLoot.java:26)
- [ ] `ModLoot.registerLootCondition(2)`: it uses Minecraft's `MapCodec` (io/github/apace100/origins/registry/ModLoot.java:28)
- [ ] `ModLoot.registerLootTables(0)`: it uses Fabric's `LootTableEvents`.MODIFY (io/github/apace100/origins/registry/ModLoot.java:32)

### `ModTags`

- [ ] `ModTags.MEAT`: it uses Minecraft's `TagKey` (io/github/apace100/origins/registry/ModTags.java:10)
- [ ] `ModTags.UNPHASABLE`: it uses Minecraft's `TagKey` (io/github/apace100/origins/registry/ModTags.java:11)
- [ ] `ModTags.NATURAL_STONE`: it uses Minecraft's `TagKey` (io/github/apace100/origins/registry/ModTags.java:12)
- [ ] `ModTags.RANGED_WEAPONS`: it uses Minecraft's `TagKey` (io/github/apace100/origins/registry/ModTags.java:13)
- [x] `ModTags.register(0)` (io/github/apace100/origins/registry/ModTags.java:15)

### `ChooseOriginScreen`: it extends `OriginDisplayScreen`

- [ ] `ChooseOriginScreen.ChooseOriginScreen(3)`: its class isn't translated (it extends `OriginDisplayScreen`) (io/github/apace100/origins/screen/ChooseOriginScreen.java:35)
- [ ] `ChooseOriginScreen.openNextLayerScreen(0)`: its class isn't translated (it extends `OriginDisplayScreen`) (io/github/apace100/origins/screen/ChooseOriginScreen.java:71)
- [ ] `ChooseOriginScreen.shouldCloseOnEsc(0)`: its class isn't translated (it extends `OriginDisplayScreen`) (io/github/apace100/origins/screen/ChooseOriginScreen.java:75)
- [ ] `ChooseOriginScreen.init(0)`: its class isn't translated (it extends `OriginDisplayScreen`) (io/github/apace100/origins/screen/ChooseOriginScreen.java:79)
- [ ] `ChooseOriginScreen.getTitleText(0)`: its class isn't translated (it extends `OriginDisplayScreen`) (io/github/apace100/origins/screen/ChooseOriginScreen.java:115)
- [ ] `ChooseOriginScreen.getCurrentOriginInternal(0)`: its class isn't translated (it extends `OriginDisplayScreen`) (io/github/apace100/origins/screen/ChooseOriginScreen.java:122)
- [ ] `ChooseOriginScreen.initRandomOrigin(0)`: its class isn't translated (it extends `OriginDisplayScreen`) (io/github/apace100/origins/screen/ChooseOriginScreen.java:134)
- [ ] `ChooseOriginScreen.extractRenderState(4)`: its class isn't translated (it extends `OriginDisplayScreen`) (io/github/apace100/origins/screen/ChooseOriginScreen.java:153)

### `OriginDisplayScreen`: it extends Minecraft's `Screen`

- [x] `OriginDisplayScreen.WINDOW` (io/github/apace100/origins/screen/OriginDisplayScreen.java:28)
- [x] `OriginDisplayScreen.windowWidth` (io/github/apace100/origins/screen/OriginDisplayScreen.java:33)
- [x] `OriginDisplayScreen.windowHeight` (io/github/apace100/origins/screen/OriginDisplayScreen.java:34)
- [ ] `OriginDisplayScreen.OriginDisplayScreen(2)`: its class isn't translated (it extends Minecraft's `Screen`) (io/github/apace100/origins/screen/OriginDisplayScreen.java:46)
- [ ] `OriginDisplayScreen.showOrigin(3)`: its class isn't translated (it extends Minecraft's `Screen`) (io/github/apace100/origins/screen/OriginDisplayScreen.java:51)
- [ ] `OriginDisplayScreen.setRandomOriginText(1)`: its class isn't translated (it extends Minecraft's `Screen`) (io/github/apace100/origins/screen/OriginDisplayScreen.java:59)
- [ ] `OriginDisplayScreen.init(0)`: its class isn't translated (it extends Minecraft's `Screen`) (io/github/apace100/origins/screen/OriginDisplayScreen.java:63)
- [ ] `OriginDisplayScreen.getCurrentOrigin(0)`: its class isn't translated (it extends Minecraft's `Screen`) (io/github/apace100/origins/screen/OriginDisplayScreen.java:69)
- [ ] `OriginDisplayScreen.getCurrentLayer(0)`: its class isn't translated (it extends Minecraft's `Screen`) (io/github/apace100/origins/screen/OriginDisplayScreen.java:73)
- [ ] `OriginDisplayScreen.extractBackground(4)`: its class isn't translated (it extends Minecraft's `Screen`) (io/github/apace100/origins/screen/OriginDisplayScreen.java:77)
- [ ] `OriginDisplayScreen.extractRenderState(4)`: its class isn't translated (it extends Minecraft's `Screen`) (io/github/apace100/origins/screen/OriginDisplayScreen.java:87)
- [ ] `OriginDisplayScreen.renderScrollbar(3)`: its class isn't translated (it extends Minecraft's `Screen`) (io/github/apace100/origins/screen/OriginDisplayScreen.java:98)
- [ ] `OriginDisplayScreen.canScroll(0)`: its class isn't translated (it extends Minecraft's `Screen`) (io/github/apace100/origins/screen/OriginDisplayScreen.java:119)
- [ ] `OriginDisplayScreen.mouseReleased(1)`: its class isn't translated (it extends Minecraft's `Screen`) (io/github/apace100/origins/screen/OriginDisplayScreen.java:123)
- [ ] `OriginDisplayScreen.mouseClicked(2)`: its class isn't translated (it extends Minecraft's `Screen`) (io/github/apace100/origins/screen/OriginDisplayScreen.java:128)
- [ ] `OriginDisplayScreen.mouseDragged(3)`: its class isn't translated (it extends Minecraft's `Screen`) (io/github/apace100/origins/screen/OriginDisplayScreen.java:149)
- [ ] `OriginDisplayScreen.renderBadgeTooltip(3)`: its class isn't translated (it extends Minecraft's `Screen`) (io/github/apace100/origins/screen/OriginDisplayScreen.java:160)
- [ ] `OriginDisplayScreen.getTitleText(0)`: its class isn't translated (it extends Minecraft's `Screen`) (io/github/apace100/origins/screen/OriginDisplayScreen.java:169)
- [ ] `OriginDisplayScreen.renderOriginWindow(3)`: its class isn't translated (it extends Minecraft's `Screen`) (io/github/apace100/origins/screen/OriginDisplayScreen.java:173)
- [ ] `OriginDisplayScreen.renderOriginImpact(3)`: its class isn't translated (it extends Minecraft's `Screen`) (io/github/apace100/origins/screen/OriginDisplayScreen.java:191)
- [ ] `OriginDisplayScreen.renderOriginName(1)`: its class isn't translated (it extends Minecraft's `Screen`) (io/github/apace100/origins/screen/OriginDisplayScreen.java:210)
- [ ] `OriginDisplayScreen.renderWindowBackground(3)`: its class isn't translated (it extends Minecraft's `Screen`) (io/github/apace100/origins/screen/OriginDisplayScreen.java:217)
- [ ] `OriginDisplayScreen.mouseScrolled(4)`: its class isn't translated (it extends Minecraft's `Screen`) (io/github/apace100/origins/screen/OriginDisplayScreen.java:229)
- [ ] `OriginDisplayScreen.renderOriginContent(3)`: its class isn't translated (it extends Minecraft's `Screen`) (io/github/apace100/origins/screen/OriginDisplayScreen.java:236)

### `OriginDisplayScreen.RenderedBadge`: it uses `PowerType` (io.github.apace100.apoli.power)

- [ ] `OriginDisplayScreen.RenderedBadge.RenderedBadge(4)`: its class isn't translated (it uses `PowerType` (io.github.apace100.apoli.power)) (io/github/apace100/origins/screen/OriginDisplayScreen.java:310)
- [ ] `OriginDisplayScreen.RenderedBadge.hasTooltip(0)`: its class isn't translated (it uses `PowerType` (io.github.apace100.apoli.power)) (io/github/apace100/origins/screen/OriginDisplayScreen.java:317)
- [ ] `OriginDisplayScreen.RenderedBadge.getTooltipComponents(2)`: its class isn't translated (it uses `PowerType` (io.github.apace100.apoli.power)) (io/github/apace100/origins/screen/OriginDisplayScreen.java:321)

### `CraftingRecipeTooltipComponent`: it implements Minecraft's `ClientTooltipComponent`

- [x] `CraftingRecipeTooltipComponent.TEXTURE` (io/github/apace100/origins/screen/tooltip/CraftingRecipeTooltipComponent.java:16)
- [ ] `CraftingRecipeTooltipComponent.CraftingRecipeTooltipComponent(3)`: its class isn't translated (it implements Minecraft's `ClientTooltipComponent`) (io/github/apace100/origins/screen/tooltip/CraftingRecipeTooltipComponent.java:18)
- [ ] `CraftingRecipeTooltipComponent.getHeight(1)`: its class isn't translated (it implements Minecraft's `ClientTooltipComponent`) (io/github/apace100/origins/screen/tooltip/CraftingRecipeTooltipComponent.java:24)
- [ ] `CraftingRecipeTooltipComponent.getWidth(1)`: its class isn't translated (it implements Minecraft's `ClientTooltipComponent`) (io/github/apace100/origins/screen/tooltip/CraftingRecipeTooltipComponent.java:28)
- [ ] `CraftingRecipeTooltipComponent.extractImage(6)`: its class isn't translated (it implements Minecraft's `ClientTooltipComponent`) (io/github/apace100/origins/screen/tooltip/CraftingRecipeTooltipComponent.java:32)
- [ ] `CraftingRecipeTooltipComponent.drawBackground(5)`: its class isn't translated (it implements Minecraft's `ClientTooltipComponent`) (io/github/apace100/origins/screen/tooltip/CraftingRecipeTooltipComponent.java:50)

### `ViewOriginScreen`: it extends `OriginDisplayScreen`

- [ ] `ViewOriginScreen.ViewOriginScreen(0)`: its class isn't translated (it extends `OriginDisplayScreen`) (io/github/apace100/origins/screen/ViewOriginScreen.java:28)
- [ ] `ViewOriginScreen.shouldCloseOnEsc(0)`: its class isn't translated (it extends `OriginDisplayScreen`) (io/github/apace100/origins/screen/ViewOriginScreen.java:52)
- [ ] `ViewOriginScreen.init(0)`: its class isn't translated (it extends `OriginDisplayScreen`) (io/github/apace100/origins/screen/ViewOriginScreen.java:56)
- [ ] `ViewOriginScreen.extractRenderState(4)`: its class isn't translated (it extends `OriginDisplayScreen`) (io/github/apace100/origins/screen/ViewOriginScreen.java:116)
- [ ] `ViewOriginScreen.getTitleText(0)`: its class isn't translated (it extends `OriginDisplayScreen`) (io/github/apace100/origins/screen/ViewOriginScreen.java:128)

### `WaitForNextLayerScreen`: it extends Minecraft's `Screen`

- [ ] `WaitForNextLayerScreen.WaitForNextLayerScreen(3)`: its class isn't translated (it extends Minecraft's `Screen`) (io/github/apace100/origins/screen/WaitForNextLayerScreen.java:19)
- [ ] `WaitForNextLayerScreen.openSelection(0)`: its class isn't translated (it extends Minecraft's `Screen`) (io/github/apace100/origins/screen/WaitForNextLayerScreen.java:29)
- [ ] `WaitForNextLayerScreen.extractRenderState(4)`: its class isn't translated (it extends Minecraft's `Screen`) (io/github/apace100/origins/screen/WaitForNextLayerScreen.java:46)
- [ ] `WaitForNextLayerScreen.extractBackground(4)`: its class isn't translated (it extends Minecraft's `Screen`) (io/github/apace100/origins/screen/WaitForNextLayerScreen.java:54)

### `ByteBufUtils`

- [ ] `ByteBufUtils.composite(21)`: its body couldn't be read: an anonymous class (io/github/apace100/origins/util/ByteBufUtils.java:8)

### `ChoseOriginCriterion`: it extends Minecraft's `SimpleCriterionTrigger`

- [ ] `ChoseOriginCriterion.CODEC`: it uses Minecraft's `Codec` (io/github/apace100/origins/util/ChoseOriginCriterion.java:15)
- [ ] `ChoseOriginCriterion.INSTANCE`: it uses ChoseOriginCriterion, which isn't translated (it extends Minecraft's `SimpleCriterionTrigger`) (io/github/apace100/origins/util/ChoseOriginCriterion.java:22)
- [x] `ChoseOriginCriterion.ID` (io/github/apace100/origins/util/ChoseOriginCriterion.java:23)
- [ ] `ChoseOriginCriterion.trigger(2)`: its class isn't translated (it extends Minecraft's `SimpleCriterionTrigger`) (io/github/apace100/origins/util/ChoseOriginCriterion.java:25)
- [ ] `ChoseOriginCriterion.codec(0)`: its class isn't translated (it extends Minecraft's `SimpleCriterionTrigger`) (io/github/apace100/origins/util/ChoseOriginCriterion.java:29)

### `ChoseOriginCriterion.Conditions`: it implements Minecraft's `SimpleInstance`

- [ ] `ChoseOriginCriterion.Conditions.Conditions(2)`: its class isn't translated (it implements Minecraft's `SimpleInstance`) (io/github/apace100/origins/util/ChoseOriginCriterion.java:37)
- [ ] `ChoseOriginCriterion.Conditions.matches(1)`: its class isn't translated (it implements Minecraft's `SimpleInstance`) (io/github/apace100/origins/util/ChoseOriginCriterion.java:42)
- [ ] `ChoseOriginCriterion.Conditions.player(0)`: its class isn't translated (it implements Minecraft's `SimpleInstance`) (io/github/apace100/origins/util/ChoseOriginCriterion.java:46)

### `Constants`

- [x] `Constants.LIGHT_ARMOR_MAX_PROTECTION` (io/github/apace100/origins/util/Constants.java:4)

### `DebugInfo`

- [ ] `DebugInfo.printRegistrySizes(1)`: it calls OriginRegistry.size, which isn't translated (io/github/apace100/origins/util/DebugInfo.java:9)
- [x] `DebugInfo.printInfo(1)` (io/github/apace100/origins/util/DebugInfo.java:15)

### `InventoryType`: its constants carry values

- [ ] `InventoryType.InventoryType(1)`: its class isn't translated (its constants carry values) (io/github/apace100/origins/util/InventoryType.java:16)
- [ ] `InventoryType.getType(0)`: its class isn't translated (its constants carry values) (io/github/apace100/origins/util/InventoryType.java:20)

### `OriginLootCondition`: it implements Minecraft's `LootItemCondition`

- [ ] `OriginLootCondition.CODEC`: it uses Minecraft's `MapCodec` (io/github/apace100/origins/util/OriginLootCondition.java:19)
- [ ] `OriginLootCondition.OriginLootCondition(1)`: its class isn't translated (it implements Minecraft's `LootItemCondition`) (io/github/apace100/origins/util/OriginLootCondition.java:28)
- [ ] `OriginLootCondition.OriginLootCondition(2)`: its class isn't translated (it implements Minecraft's `LootItemCondition`) (io/github/apace100/origins/util/OriginLootCondition.java:33)
- [ ] `OriginLootCondition.codec(0)`: its class isn't translated (it implements Minecraft's `LootItemCondition`) (io/github/apace100/origins/util/OriginLootCondition.java:38)
- [ ] `OriginLootCondition.test(1)`: its class isn't translated (it implements Minecraft's `LootItemCondition`) (io/github/apace100/origins/util/OriginLootCondition.java:42)
- [ ] `OriginLootCondition.builder(1)`: it uses Minecraft's `Builder` (io/github/apace100/origins/util/OriginLootCondition.java:67)
- [ ] `OriginLootCondition.builder(1)`: it uses Minecraft's `Builder` (io/github/apace100/origins/util/OriginLootCondition.java:71)
- [ ] `OriginLootCondition.builder(2)`: it uses Minecraft's `Builder` (io/github/apace100/origins/util/OriginLootCondition.java:75)
- [ ] `OriginLootCondition.builder(2)`: it uses Minecraft's `Builder` (io/github/apace100/origins/util/OriginLootCondition.java:79)

### `OriginsConfigSerializer`: it's generic

- [ ] `OriginsConfigSerializer.OriginsConfigSerializer(3)`: its class isn't translated (it's generic) (io/github/apace100/origins/util/OriginsConfigSerializer.java:14)
- [ ] `OriginsConfigSerializer.OriginsConfigSerializer(2)`: its class isn't translated (it's generic) (io/github/apace100/origins/util/OriginsConfigSerializer.java:19)
- [ ] `OriginsConfigSerializer.getConfigPath(0)`: its class isn't translated (it's generic) (io/github/apace100/origins/util/OriginsConfigSerializer.java:24)
- [ ] `OriginsConfigSerializer.deserialize(0)`: its class isn't translated (it's generic) (io/github/apace100/origins/util/OriginsConfigSerializer.java:28)

### `OriginsJsonConfigSerializer`: it's generic

- [ ] `OriginsJsonConfigSerializer.OriginsJsonConfigSerializer(3)`: its class isn't translated (it's generic) (io/github/apace100/origins/util/OriginsJsonConfigSerializer.java:16)
- [ ] `OriginsJsonConfigSerializer.OriginsJsonConfigSerializer(2)`: its class isn't translated (it's generic) (io/github/apace100/origins/util/OriginsJsonConfigSerializer.java:22)
- [ ] `OriginsJsonConfigSerializer.OriginsJsonConfigSerializer(3)`: its class isn't translated (it's generic) (io/github/apace100/origins/util/OriginsJsonConfigSerializer.java:28)
- [ ] `OriginsJsonConfigSerializer.deserialize(0)`: its class isn't translated (it's generic) (io/github/apace100/origins/util/OriginsJsonConfigSerializer.java:34)

### `PowerKeyManager`

- [x] `PowerKeyManager.KEY_CACHE` (io/github/apace100/origins/util/PowerKeyManager.java:12)
- [x] `PowerKeyManager.clearCache(0)` (io/github/apace100/origins/util/PowerKeyManager.java:14)
- [ ] `PowerKeyManager.getKeyIdentifier(1)`: it calls PowerKeyManager.getKeyFromPower, which isn't translated (io/github/apace100/origins/util/PowerKeyManager.java:18)
- [ ] `PowerKeyManager.getKeyFromPower(1)`: it calls `PowerTypeRegistry` (io.github.apace100.apoli.power).contains (io/github/apace100/origins/util/PowerKeyManager.java:28)

### `Scheduler`: it uses `Int2ObjectMap` (it.unimi.dsi.fastutil.ints)

- [ ] `Scheduler.Scheduler(0)`: its class isn't translated (it uses `Int2ObjectMap` (it.unimi.dsi.fastutil.ints)) (io/github/apace100/origins/util/Scheduler.java:17)
- [ ] `Scheduler.queue(2)`: its class isn't translated (it uses `Int2ObjectMap` (it.unimi.dsi.fastutil.ints)) (io/github/apace100/origins/util/Scheduler.java:33)
- [ ] `Scheduler.repeating(3)`: its class isn't translated (it uses `Int2ObjectMap` (it.unimi.dsi.fastutil.ints)) (io/github/apace100/origins/util/Scheduler.java:37)
- [ ] `Scheduler.repeatWhile(4)`: its class isn't translated (it uses `Int2ObjectMap` (it.unimi.dsi.fastutil.ints)) (io/github/apace100/origins/util/Scheduler.java:41)
- [ ] `Scheduler.repeatN(4)`: its body couldn't be read: an anonymous class (io/github/apace100/origins/util/Scheduler.java:45)

### `Scheduler.Repeating`: it implements `Consumer` (java.util.function)

- [ ] `Scheduler.Repeating.Repeating(3)`: its class isn't translated (it implements `Consumer` (java.util.function)) (io/github/apace100/origins/util/Scheduler.java:61)
- [ ] `Scheduler.Repeating.shouldQueue(1)`: its class isn't translated (it implements `Consumer` (java.util.function)) (io/github/apace100/origins/util/Scheduler.java:67)
- [ ] `Scheduler.Repeating.accept(1)`: its class isn't translated (it implements `Consumer` (java.util.function)) (io/github/apace100/origins/util/Scheduler.java:71)
